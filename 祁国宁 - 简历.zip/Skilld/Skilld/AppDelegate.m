//
//  AppDelegate.m
//  Skilld
//
//  Created by SecondSpeed on 2022/11/18.
//

#import "AppDelegate.h"
#import "AppDelegate+CYLTabBar.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.

    [self setupRootController];
    
    [self setupIQKeyBoardManager];

    return YES;
}

- (void)setupIQKeyBoardManager {
    
    IQKeyboardManager *keyBoardManager = [IQKeyboardManager sharedManager];
    keyBoardManager.enable = YES;
    keyBoardManager.shouldToolbarUsesTextFieldTintColor = YES;
    keyBoardManager.toolbarManageBehaviour = IQAutoToolbarBySubviews;
    keyBoardManager.enableAutoToolbar = NO;
    keyBoardManager.shouldShowToolbarPlaceholder = NO;
    keyBoardManager.keyboardDistanceFromTextField = 0;
    keyBoardManager.shouldResignOnTouchOutside = YES;
}

+ (AppDelegate *)getAppDelegate {
    
    AppDelegate *app = (AppDelegate *)[UIApplication sharedApplication].delegate;
    
    return app;
}

@end
