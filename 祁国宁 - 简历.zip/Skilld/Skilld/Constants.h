//
//  Constants.h
//  Skilld
//
//  Created by Speed on 2022/11/18.
//

#ifndef Constants_h
#define Constants_h

#define k_product_id1 @"com.remuse.cv.des.year.trial"
#define k_product_id2 @"com.remuse.cv.des.month"


#define k_app_id @"1658498701"

#define k_purchase_status @"k_purchase_status"

#define k_privacy_policy @"https://sites.google.com/view/geniusresumecreator-servicepp/home"
#define k_terms_of_user @"https://sites.google.com/view/geniusresumecreator-servicetou/home"

#define Resume_Tablename @"Resume_Tablename"
#define ResumeSaveSuccessNotification @"ResumeSaveSuccessNotification"

#define S_Screen_W  [UIScreen mainScreen].bounds.size.width
#define S_Screen_H  [UIScreen mainScreen].bounds.size.height

#define S_PHONE_X \
({BOOL isPhoneX = NO;\
if (@available(iOS 11.0, *)) {\
isPhoneX = [[UIApplication sharedApplication] delegate].window.safeAreaInsets.bottom > 0.0;\
}\
(isPhoneX);})

#define STATUSBAR_HEIGHT \
^(){\
if (@available(iOS 13.0, *)) {\
    UIStatusBarManager *statusBarManager = [UIApplication sharedApplication].windows.firstObject.windowScene.statusBarManager;\
    return statusBarManager.statusBarFrame.size.height;\
} else {\
    return [UIApplication sharedApplication].statusBarFrame.size.height;\
}\
}()

/// MARK: Rect
#define S_NavigationBarHeight (S_PHONE_X ? 88 : 64)

#define S_NoStatusBarNavigationBarHeight (44)

#define S_TabbarHeight (S_PHONE_X ? 83 : 49)

#define S_SafeAreaBottomHeight (S_PHONE_X ? 34 : 0)

#define S_AdaptNaviHeight (S_PHONE_X ? 44 : 20)

#define S_ScaleWidth(size) (S_Screen_W / 375.0 * size)

#define kMargin_15 S_ScaleWidth(15)


/// MARK: Color
#define rgba(r,g,b,a)       [UIColor colorWithRed:(r)/255.f \
                            green:(g)/255.f \
                            blue:(b)/255.f \
                            alpha:(a)]

#define kColor_theme        rgba(239, 245, 249, 1)


/// MARK: Font
#define Verson [UIDevice currentDevice].systemVersion

#define FONT(x) [UIFont systemFontOfSize:S_ScaleWidth(x)]

#define FONTR(x)  (Verson.doubleValue >= 10.0 ? [UIFont fontWithName:@"PingFangSC-Regular" size:S_ScaleWidth(x)] : FONT(x))
#define FONTB(x)  (Verson.doubleValue >= 10.0 ? [UIFont fontWithName:@"PingFangSC-Semibold" size:S_ScaleWidth(x)] : FONT(x))
#define FONTM(x)  (Verson.doubleValue >= 10.0 ? [UIFont fontWithName:@"PingFangSC-Medium" size:S_ScaleWidth(x)] : FONT(x))

#define HMFONTR(x)  (Verson.doubleValue >= 10.0 ? [UIFont fontWithName:@"HarmonyOS_Sans_Regular" size:S_ScaleWidth(x)] : FONT(x))
#define HMFONTB(x)  (Verson.doubleValue >= 10.0 ? [UIFont fontWithName:@"HarmonyOS_Sans_Bold" size:S_ScaleWidth(x)] : FONT(x))
#define HMFONTM(x)  (Verson.doubleValue >= 10.0 ? [UIFont fontWithName:@"HarmonyOS_Sans_Medium" size:S_ScaleWidth(x)] : FONT(x))
#define HMFONTBLACK(x)  (Verson.doubleValue >= 10.0 ? [UIFont fontWithName:@"HarmonyOS_Sans_Black" size:S_ScaleWidth(x)] : FONT(x))

/// MARK: Log
#ifdef DEBUG
#define SLog(...) printf("[%s] %s [row:%d]: %s\n", __TIME__ ,__PRETTY_FUNCTION__ ,__LINE__, [[NSString stringWithFormat:__VA_ARGS__] UTF8String])
#else
#define SLog(...)
#endif


#endif /* Constants_h */
