//
//  AppDelegate+CYLTabBar.m
//  Skilld
//
//  Created by Speed on 2022/11/18.
//

#import "AppDelegate+CYLTabBar.h"
#import <CYLTabBarController.h>
#import "SHomeViewController.h"
#import "SMeViewController.h"
#import "SCYLPlusButton.h"

@interface AppDelegate () <CYLTabBarControllerDelegate>

@end

@implementation AppDelegate (CYLTabBar)

- (void)setupRootController {
        
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    
    [SCYLPlusButton registerPlusButton];
    
    CYLTabBarController *tabBarController = [CYLTabBarController tabBarControllerWithViewControllers:[self viewControllers] tabBarItemsAttributes:[self tabBarItemsAttributes]];
    tabBarController.delegate = self;
    self.window.rootViewController = tabBarController;
    
    if (@available(iOS 13.0, *)) {
        [UITabBar appearance].tintColor = rgba(20, 23, 34, 1);
        [UITabBar appearance].unselectedItemTintColor = rgba(138, 148, 160, 1);
    } else {
        UITabBarItem *item = [UITabBarItem appearance];
        [item setTitleTextAttributes:@{NSForegroundColorAttributeName:rgba(138, 148, 160, 1)} forState:UIControlStateNormal];
        [item setTitleTextAttributes:@{NSForegroundColorAttributeName:rgba(20, 23, 34, 1)} forState:UIControlStateSelected];
    }

    UIView *bgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, S_Screen_W, S_TabbarHeight)];
    bgView.backgroundColor = [UIColor whiteColor];
    [bgView cornerByRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight cornerRadius:10];
    [tabBarController.tabBar insertSubview:bgView atIndex:0];

}

- (NSArray *)viewControllers {
    
    SHomeViewController *homeVC = [[SHomeViewController alloc] init];
    SNavigationController *homeNC = [[SNavigationController alloc] initWithRootViewController:homeVC];
    [homeNC cyl_setHideNavigationBarSeparator:YES];
    
    SMeViewController *meVC = [[SMeViewController alloc] init];
    SNavigationController *accountNC = [[SNavigationController alloc] initWithRootViewController:meVC];
    [accountNC cyl_setHideNavigationBarSeparator:YES];
    
    NSArray *viewControllersArray = @[homeNC, accountNC];
    return viewControllersArray;

}

- (NSArray *)tabBarItemsAttributes {
    
    NSDictionary *homeTabBarItemsAttributes = @{
        CYLTabBarItemTitle: @"Home",
        CYLTabBarItemImage: @"home_normal",
        CYLTabBarItemSelectedImage: @"home_highlight",
    };
    NSDictionary *meTabBarItemsAttributes = @{
        CYLTabBarItemTitle: @"Me",
        CYLTabBarItemImage: @"me_normal",
        CYLTabBarItemSelectedImage: @"me_highlight",
    };
    
    NSArray *tabBarItemsAttributes = @[
        homeTabBarItemsAttributes,
        meTabBarItemsAttributes,
    ];
    return tabBarItemsAttributes;

}

@end
