//
//  UIScrollView+Extension.m
//  XYD
//
//  Created by Second on 2022/10/7.
//

#import "UIScrollView+Extension.h"

@implementation UIScrollView (Extension)

- (void)contentInsetScrollView {
    
    self.showsVerticalScrollIndicator = NO;
    
    if (@available(iOS 11.0, *)) {
        if ([self isKindOfClass:[UITableView class]]) {
            UITableView *tableView = (UITableView *)self;
            tableView.estimatedRowHeight = 0;
            
            tableView.estimatedSectionHeaderHeight = 0;
            if (tableView.style == UITableViewStyleGrouped) {
                
                tableView.estimatedSectionFooterHeight = 0.1;
            } else {
                tableView.estimatedSectionFooterHeight = 0;
            }
            
            if (@available(iOS 15.0, *)) {
                tableView.sectionHeaderTopPadding = 0;
            } 
            
        }
        self.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        //        UIScrollViewContentInsetAdjustmentNever
        //        UIScrollViewContentInsetAdjustmentAutomatic
    } else {
        
    }
}

@end
