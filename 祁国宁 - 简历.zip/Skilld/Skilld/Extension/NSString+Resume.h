//
//  NSString+Resume.h
//  Skilld
//
//  Created by Speed on 2022/11/19.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (Resume)

- (CGSize)sizeWithFont:(UIFont *)font maxH:(CGFloat)maxH;

- (CGSize)sizeWithFont:(UIFont *)font maxW:(CGFloat)maxW;

@end

NS_ASSUME_NONNULL_END
