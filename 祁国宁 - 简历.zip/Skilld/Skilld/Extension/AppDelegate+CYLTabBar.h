//
//  AppDelegate+CYLTabBar.h
//  Skilld
//
//  Created by Speed on 2022/11/18.
//

#import "AppDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface AppDelegate (CYLTabBar)

- (void)setupRootController;

@end

NS_ASSUME_NONNULL_END
