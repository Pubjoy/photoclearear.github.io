//
//  UIScrollView+Extension.h
//  XYD
//
//  Created by Second on 2022/10/7.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIScrollView (Extension)

- (void)contentInsetScrollView;

@end

NS_ASSUME_NONNULL_END
