//
//  UIButton+LXMImagePosition.h
//  Demo_ButtonImageTitleEdgeInsets
//
//  Created by luxiaoming on 16/1/15.
//  Copyright © 2016年 luxiaoming. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, LXMImagePosition) {
    LXMImagePositionLeft = 0,
    LXMImagePositionRight = 1,
    LXMImagePositionTop = 2,
    LXMImagePositionBottom = 3,
    LXMImagePositionReset,
};

@interface UIButton (LXMImagePosition)

- (void)setImagePosition:(LXMImagePosition)postion spacing:(CGFloat)spacing;

@end
