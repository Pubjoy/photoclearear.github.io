//
//  SNavigationController.m
//  Skilld
//
//  Created by Speed on 2022/11/19.
//

#import "SNavigationController.h"

@interface SNavigationController ()

@end

@implementation SNavigationController

+ (void)load{
    
    UIBarButtonItem *item = [UIBarButtonItem appearance];
    
    UIColor *ty_navigationFont = [UIColor whiteColor];
    UIColor *ty_navigationBatTint = [UIColor whiteColor];
    
    NSMutableDictionary *textAttrs = [NSMutableDictionary dictionary];
    textAttrs[NSForegroundColorAttributeName] = ty_navigationFont;
    textAttrs[NSFontAttributeName] = FONTR(17);
    [item setTitleTextAttributes:textAttrs forState:UIControlStateNormal];
    

    if (@available(iOS 15.0, *)) {
        
           UINavigationBarAppearance *barApp = [UINavigationBarAppearance new];
           barApp.backgroundColor = ty_navigationBatTint;
           barApp.shadowColor = ty_navigationBatTint;
           barApp.titleTextAttributes = textAttrs;
           
           UINavigationBar *navigationBar = [UINavigationBar appearance];
           navigationBar.scrollEdgeAppearance = barApp;
           navigationBar.standardAppearance = barApp;
        
    }else{
        
        // 设置高亮状态
        NSMutableDictionary *disableTextAttrs = [NSMutableDictionary dictionary];
        disableTextAttrs[NSForegroundColorAttributeName] = ty_navigationFont;
        disableTextAttrs[NSFontAttributeName] = FONTR(17);
        [item setTitleTextAttributes:disableTextAttrs forState:UIControlStateHighlighted];
        
        
        
        UINavigationBar *navigationBar = [UINavigationBar appearance];
        navigationBar.barTintColor = ty_navigationBatTint;
        NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:ty_navigationFont,NSForegroundColorAttributeName,FONTR(17),NSFontAttributeName,nil];
        navigationBar.titleTextAttributes = dict;
        
        [navigationBar setShadowImage:[[UIImage alloc] init]];
    }
    
}

- (void)viewDidLoad {
    
    [super viewDidLoad];
   
    //透明度为NO
    self.navigationBar.translucent = NO;
}

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    if (self.viewControllers.count) { //
       
        viewController.hidesBottomBarWhenPushed = YES;
    }
    
    [super pushViewController:viewController animated:animated];
}


- (void)presentViewController:(UIViewController *)viewControllerToPresent animated:(BOOL)flag completion:(void (^)(void))completion{
    
    [super presentViewController:viewControllerToPresent animated:flag completion:completion];
    
}

- (void)back{
    
    [self popViewControllerAnimated:YES];
}


- (void)dealloc {
    SLog(@"----%@释放了", self);
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end
