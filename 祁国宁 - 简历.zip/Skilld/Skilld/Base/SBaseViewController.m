//
//  SBaseViewController.m
//  Skilld
//
//  Created by Speed on 2022/11/18.
//

#import "SBaseViewController.h"

@interface SBaseViewController ()

@end

@implementation SBaseViewController

- (BOOL)fd_prefersNavigationBarHidden {
    return YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = kColor_theme;
}

@end
