//
//  SResumeEditBaseController.m
//  Skilld
//
//  Created by Speed on 2022/11/19.
//

#import "SResumeEditBaseController.h"

@interface SResumeEditBaseController ()

@end

@implementation SResumeEditBaseController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self.view cornerByRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight cornerRadius:S_ScaleWidth(20)];
    self.view.backgroundColor = [UIColor whiteColor];
}


#pragma mark - <JXCategoryListContentViewDelegate>
- (UIView *)listView {
    return self.view;
}

#pragma mark - <UITextFieldDelegate>
- (void)textFieldDidBeginEditing:(SResumeField *)textField {
    
    [textField updateFieldShaowStauts:YES];
}

- (void)textFieldDidEndEditing:(SResumeField *)textField {
    [textField updateFieldShaowStauts:NO];
}


- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}


@end
