//
//  SResumeEditBaseController.h
//  Skilld
//
//  Created by Speed on 2022/11/19.
//

#import "SBaseViewController.h"
#import "JXCategoryView.h"

NS_ASSUME_NONNULL_BEGIN

@interface SResumeEditBaseController : SBaseViewController <JXCategoryListContentViewDelegate, UITextFieldDelegate>

@property (nonatomic, strong) SResumeModel *resumeModel;

@end

NS_ASSUME_NONNULL_END
