//
//  SRoute.m
//  Skilld
//
//  Created by Speed on 2022/11/18.
//

#import "SRoute.h"
#import <SafariServices/SafariServices.h>
#import "SVIPViewController.h"

@implementation SRoute


+ (void)aboutMe {
    SLog(@"About Me");
    
    NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    
    UIAlertController * alert = [UIAlertController alertControllerWithTitle:@"About Me" message:version preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction * actionConfirm = [UIAlertAction actionWithTitle:@"Done" style:UIAlertActionStyleDefault handler:nil];
    [alert addAction:actionConfirm];
    [[self getCurrentVC] presentViewController:alert animated:YES completion:nil];
}

+ (void)pricacyAgreement {
    
    SLog(@"Pricacy Agreement");
    
    SFSafariViewController *sarariVc = [[SFSafariViewController alloc] initWithURL:[NSURL URLWithString:k_privacy_policy]];

    [[self getCurrentVC] presentViewController:sarariVc animated:YES completion:nil];

}

+ (void)serviceAgreement {
    
    SLog(@"service Agreement");
    
    SFSafariViewController *sarariVc = [[SFSafariViewController alloc] initWithURL:[NSURL URLWithString:k_terms_of_user]];

    [[self getCurrentVC] presentViewController:sarariVc animated:YES completion:nil];

}

+ (void)share {
    
    SLog(@"Share");
    
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"itms-apps://itunes.apple.com/app/id%@", k_app_id]] options:@{UIApplicationOpenURLOptionsSourceApplicationKey : @YES} completionHandler:^(BOOL success) {
        
    }];
}

+ (void)vip {
    SVIPViewController *vc = [[SVIPViewController alloc] init];
    vc.modalPresentationStyle = UIModalPresentationFullScreen;
    [[self getCurrentVC] presentViewController:vc animated:YES completion:nil];
}

+ (UIViewController *)getCurrentVC {
    
    UIViewController* vc = [UIApplication sharedApplication].keyWindow.rootViewController;
    
    while (1)
    {

        if ([vc isKindOfClass:[UITabBarController class]]) {
            vc = ((UITabBarController*)vc).selectedViewController;
        }
        if ([vc isKindOfClass:[UINavigationController class]]) {
            vc = ((UINavigationController*)vc).visibleViewController;
        }
        if (vc.presentedViewController) {
            vc = vc.presentedViewController;
        }else{
            break;
        }
    }

    return vc;
}


+ (UIImage *)snapshotWithView:(UIView *)view {
    UIGraphicsBeginImageContextWithOptions(view.bounds.size, NO, [UIScreen mainScreen].scale);
    [view.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

+ (UIImage *)snapshotWithScrollView:(UIScrollView *)scrollView {
    
    CGPoint savedContentOffset = scrollView.contentOffset;
    CGRect savedFrame = scrollView.frame;
    
    scrollView.contentOffset = CGPointZero;
    scrollView.frame = CGRectMake(0, 0, scrollView.contentSize.width, scrollView.contentSize.height);

    UIGraphicsBeginImageContextWithOptions(scrollView.contentSize, NO, [UIScreen mainScreen].scale);
    [scrollView.layer renderInContext: UIGraphicsGetCurrentContext()];
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();

    scrollView.contentOffset = savedContentOffset;
    scrollView.frame = savedFrame;
    
    return image;
}

+ (NSString *)creatPdfPathWithScrollView:(UIScrollView *)scrollView {
    
    NSMutableData *pdfData = [NSMutableData data];
    
    UIGraphicsBeginPDFContextToData(pdfData, (CGRect){0,0, scrollView.contentSize}, nil);
    
    UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, scrollView.contentSize.width,scrollView.contentSize.height), nil);
    
    CGContextRef pdfContext = UIGraphicsGetCurrentContext();
    
    CGRect origSize = scrollView.frame;
    
    CGRect newSize = origSize;
    
    newSize.size = scrollView.contentSize;
    
    [scrollView setFrame:newSize];
    
    [scrollView.layer renderInContext:pdfContext];
    
    [scrollView setFrame:origSize];
 
    UIGraphicsEndPDFContext();
    
    NSArray *documentPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    NSString *documentPath = [documentPaths objectAtIndex:0];

    NSString *fileName = [NSString stringWithFormat:@"%ld.pdf", (long)[NSDate timeIntervalSinceReferenceDate]];
  
    NSString *filePath = [documentPath stringByAppendingPathComponent:fileName];

    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    [fileManager createFileAtPath:filePath contents:pdfData attributes:nil];
    
    return filePath;
}


+ (void)shareWithImage:(UIImage *)image target:(UIViewController *)target complete:(void (^)(BOOL isSuccess, UIActivityType type))complete {

    UIImage *shareImage = image;
    NSArray *activityItemsArray = @[shareImage];

    UIActivityViewController *activityVC = [[UIActivityViewController alloc] initWithActivityItems:activityItemsArray applicationActivities:nil];
    activityVC.modalInPopover = YES;
    activityVC.completionWithItemsHandler = ^(UIActivityType  _Nullable activityType, BOOL completed, NSArray * _Nullable returnedItems, NSError * _Nullable activityError) {
        if (complete) {
            complete(completed, activityType);
        }
    };
    [target presentViewController:activityVC animated:YES completion:nil];
}

+ (void)sharePDFWithFilePath:(NSString *)filePath target:(UIViewController *)target complete:(void (^)(BOOL isSuccess, UIActivityType type))complete {
    
    NSURL *url = [NSURL fileURLWithPath:filePath];
    
    NSArray *activityItemsArray = @[url];

    UIActivityViewController *activityVC = [[UIActivityViewController alloc] initWithActivityItems:activityItemsArray applicationActivities:nil];
    activityVC.modalInPopover = YES;
    activityVC.completionWithItemsHandler = ^(UIActivityType  _Nullable activityType, BOOL completed, NSArray * _Nullable returnedItems, NSError * _Nullable activityError) {
        if (complete) {
            complete(completed, activityType);
        }
    };
    [target presentViewController:activityVC animated:YES completion:nil];

}
    
@end
