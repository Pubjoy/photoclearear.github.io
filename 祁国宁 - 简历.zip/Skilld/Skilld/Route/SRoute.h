//
//  SRoute.h
//  Skilld
//
//  Created by Speed on 2022/11/18.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SRoute : NSObject


+ (void)aboutMe;

+ (void)pricacyAgreement;

+ (void)serviceAgreement;

+ (void)share;

+ (void)vip;

+ (UIViewController *)getCurrentVC;

+ (UIImage *)snapshotWithView:(UIView *)view;

+ (UIImage *)snapshotWithScrollView:(UIScrollView *)scrollView;

+ (NSString *)creatPdfPathWithScrollView:(UIScrollView *)scrollView;

+ (void)shareWithImage:(UIImage *)image target:(UIViewController *)target complete:(void (^)(BOOL isSuccess, UIActivityType type))complete;

+ (void)sharePDFWithFilePath:(NSString *)filePath target:(UIViewController *)target complete:(void (^)(BOOL isSuccess, UIActivityType type))complete;
@end

NS_ASSUME_NONNULL_END
