//
//  SVIPViewController.h
//  Skilld
//
//  Created by Speed on 2023/1/5.
//

#import "SBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface SVIPViewController : SBaseViewController

@end

NS_ASSUME_NONNULL_END
