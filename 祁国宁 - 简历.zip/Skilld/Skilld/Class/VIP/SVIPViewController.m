//
//  SVIPViewController.m
//  Skilld
//
//  Created by Speed on 2023/1/5.
//

#import "SVIPViewController.h"

@interface SVIPViewController ()

@property (nonatomic, weak) UIButton *productBtn;

@property (nonatomic, weak) UIButton *productBtn1;

@property (nonatomic, copy) NSString *productIdentifier;

@end

@implementation SVIPViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.productIdentifier = k_product_id1;
    
    [self initView];
}

- (void)initView {
    
    UIScrollView *scrollView = [[UIScrollView alloc] init];
    [scrollView contentInsetScrollView];
    scrollView.showsVerticalScrollIndicator = NO;
    scrollView.showsHorizontalScrollIndicator = NO;
    [self.view addSubview:scrollView];
    [scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.bottom.mas_equalTo(0);
    }];
    
    UIImageView *backView = [[UIImageView alloc] init];
    backView.image = [UIImage imageNamed:@"vip_bg"];
    [scrollView addSubview:backView];
    [backView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.mas_equalTo(0);
        make.width.mas_equalTo(S_Screen_W);
        make.height.mas_equalTo(S_ScaleWidth(812));
    }];
    
    UIButton *restoreBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    restoreBtn.frame = CGRectMake(0, 0, S_ScaleWidth(82), S_ScaleWidth(63));
    [restoreBtn setImage:[UIImage imageNamed:@"vip_restore"] forState:UIControlStateNormal];
    [restoreBtn setTitle:@"Restore" forState:UIControlStateNormal];
    [restoreBtn setTitleColor:rgba(185, 185, 185, 1) forState:UIControlStateNormal];
    restoreBtn.titleLabel.font = HMFONTR(12);
    [restoreBtn setImagePosition:LXMImagePositionTop spacing:0];
    [restoreBtn addTarget:self action:@selector(restoreAction) forControlEvents:UIControlEventTouchUpInside];
    [scrollView addSubview:restoreBtn];
    [restoreBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_AdaptNaviHeight);
        make.left.mas_equalTo(0);
        make.width.mas_equalTo(S_ScaleWidth(82));
        make.height.mas_equalTo(S_ScaleWidth(63));
    }];
    
    UIButton *cancelBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [cancelBtn setImage:[UIImage imageNamed:@"vip_cancel"] forState:UIControlStateNormal];
    [cancelBtn addTarget:self action:@selector(cancelAction) forControlEvents:UIControlEventTouchUpInside];
    [scrollView addSubview:cancelBtn];
    [cancelBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_AdaptNaviHeight);
        make.left.mas_equalTo(S_Screen_W - 60);
        make.width.mas_equalTo(S_ScaleWidth(60));
        make.height.mas_equalTo(S_ScaleWidth(46));
    }];
    
    UIView *container = [[UIView alloc] init];
    container.backgroundColor = [UIColor whiteColor];
    [scrollView addSubview:container];
    [container mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_AdaptNaviHeight + S_ScaleWidth(263));
        make.left.mas_equalTo(0);
        make.width.mas_equalTo(S_Screen_W);
        make.bottom.equalTo(backView);
    }];
    
    [container.superview layoutIfNeeded];
    [container cornerByRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight cornerRadius:S_ScaleWidth(20)];


    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.text = @"Resume Builder";
    titleLabel.textColor = rgba(14, 23, 46, 1);
    titleLabel.font = HMFONTBLACK(24);
    [container addSubview:titleLabel];
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_ScaleWidth(15));
        make.left.mas_equalTo(S_ScaleWidth(20));
        make.height.mas_equalTo(S_ScaleWidth(34));
    }];
    
    UIImageView *proView = [[UIImageView alloc] init];
    proView.image = [UIImage imageNamed:@"vip_pro"];
    [container addSubview:proView];
    [proView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(titleLabel);
        make.left.equalTo(titleLabel.mas_right).offset(S_ScaleWidth(10));
        make.width.mas_equalTo(S_ScaleWidth(38));
        make.height.mas_equalTo(S_ScaleWidth(23));
    }];
    
    UILabel *descLabel = [[UILabel alloc] init];
    descLabel.text = @"Unlock all advanced functions immediately, experience new editing functions, without any restrictions";
    descLabel.textColor = rgba(126, 134, 150, 1);
    descLabel.font = HMFONTR(12);
    descLabel.numberOfLines = 0;
    [container addSubview:descLabel];
    [descLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_ScaleWidth(59));
        make.left.mas_equalTo(S_ScaleWidth(20));
        make.right.mas_equalTo(-S_ScaleWidth(27));
    }];

    UIButton *productBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.productBtn = productBtn;
    [productBtn setTitle:@"Try 3 days, then subscribe" forState:UIControlStateNormal];
    [productBtn setTitleColor:rgba(255, 255, 255, 1) forState:UIControlStateNormal];
    productBtn.backgroundColor = rgba(56, 94, 239, 1);
    productBtn.titleLabel.font = HMFONTB(16);
    productBtn.layer.cornerRadius = S_ScaleWidth(24);
    productBtn.layer.borderColor = rgba(56, 94, 239, 1).CGColor;
    productBtn.layer.borderWidth = 1;
    productBtn.clipsToBounds = YES;
    [productBtn addTarget:self action:@selector(productAction:) forControlEvents:UIControlEventTouchUpInside];
    [container addSubview:productBtn];
    [productBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(descLabel.mas_bottom).offset(S_ScaleWidth(16));
        make.left.mas_equalTo(S_ScaleWidth(20));
        make.right.mas_equalTo(-S_ScaleWidth(20));
        make.height.mas_equalTo(S_ScaleWidth(48));
    }];
    
    
    UIButton *productBtn1 = [UIButton buttonWithType:UIButtonTypeCustom];
    self.productBtn1 = productBtn1;
    [productBtn1 setTitle:@"$7.99/month" forState:UIControlStateNormal];
    [productBtn1 setTitleColor:rgba(56, 94, 239, 1) forState:UIControlStateNormal];
    productBtn1.backgroundColor = rgba(255, 255, 255, 1);
    productBtn1.titleLabel.font = HMFONTB(16);
    productBtn1.layer.cornerRadius = S_ScaleWidth(24);
    productBtn1.layer.borderColor = rgba(224, 223, 227, 1).CGColor;
    productBtn1.layer.borderWidth = 1;
    productBtn1.clipsToBounds = YES;
    [productBtn1 addTarget:self action:@selector(productAction:) forControlEvents:UIControlEventTouchUpInside];
    [container addSubview:productBtn1];
    [productBtn1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(productBtn.mas_bottom).offset(S_ScaleWidth(15));
        make.left.mas_equalTo(S_ScaleWidth(20));
        make.right.mas_equalTo(-S_ScaleWidth(20));
        make.height.mas_equalTo(S_ScaleWidth(48));
    }];
    
    UILabel *productLabel = [[UILabel alloc] init];
    productLabel.text = @"$39.99/year($3.33/month)";
    productLabel.textColor = rgba(126, 134, 150, 1);
    productLabel.font = HMFONTR(12);
    [container addSubview:productLabel];
    [productLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(productBtn1.mas_bottom).offset(S_ScaleWidth(10));
        make.centerX.equalTo(productBtn1);
    }];
    
    NSArray *icons = @[@"vip_1", @"vip_2", @"vip_3", @"vip_4"];
    NSArray *titles = @[@"Unlimited mumber of resume", @"Easily change of template", @"No advertising at all", @"Unlimited print resume"];
        
    for (int i = 0; i < icons.count; i++) {
        
        UIImageView *iconView = [[UIImageView alloc] init];
        iconView.image = [UIImage imageNamed:icons[i]];
        [container addSubview:iconView];
        [iconView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(productBtn1.mas_bottom).offset(S_ScaleWidth(42) + S_ScaleWidth(40) * i);
            make.left.mas_equalTo(S_ScaleWidth(20));
            make.size.mas_equalTo(S_ScaleWidth(36));
        }];
                
        UILabel *label = [[UILabel alloc] init];
        label.text = titles[i];
        label.textColor = rgba(19, 19, 19, 1);
        label.font = HMFONTB(14);
        [container addSubview:label];
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(iconView.mas_right).offset(S_ScaleWidth(20));
            make.centerY.equalTo(iconView);
        }];
    }
    
    UILabel *tipsLabel = [[UILabel alloc] init];
    tipsLabel.text = @"No commitment, Cancel Anytime";
    tipsLabel.textColor = rgba(185, 191, 205, 1);
    tipsLabel.font = HMFONTR(12);
    [container addSubview:tipsLabel];
    [tipsLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(productBtn1.mas_bottom).offset(S_ScaleWidth(207));
        make.centerX.mas_equalTo(0);
        make.height.mas_equalTo(S_ScaleWidth(17));
    }];
    
    CGFloat width = (S_Screen_W - S_ScaleWidth(30)) * 0.5;
    
    UILabel *termsLabel = [[UILabel alloc] init];
    termsLabel.text = @"Terms of Use";
    termsLabel.textColor = rgba(126, 134, 150, 1);
    termsLabel.font = HMFONTR(12);
    termsLabel.textAlignment = NSTextAlignmentRight;
    [termsLabel addTouchUpInsideTarget:self action:@selector(termsAction)];
    [container addSubview:termsLabel];
    [termsLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(tipsLabel.mas_bottom);
        make.left.mas_equalTo(0);
        make.width.mas_equalTo(width);
        make.height.mas_equalTo(S_ScaleWidth(27));
    }];

    UILabel *privacyLabel = [[UILabel alloc] init];
    privacyLabel.text = @"Privacy Polocy";
    privacyLabel.textColor = rgba(126, 134, 150, 1);
    privacyLabel.font = HMFONTR(12);
    [privacyLabel addTouchUpInsideTarget:self action:@selector(privacyAction)];
    [container addSubview:privacyLabel];
    [privacyLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(termsLabel);
        make.left.mas_equalTo(width + S_ScaleWidth(30));
        make.width.mas_equalTo(width);
        make.height.mas_equalTo(S_ScaleWidth(27));
    }];

        
    [scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(backView.mas_bottom);
    }];
}

#pragma mark - Action

- (void)cancelAction {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)restoreAction {
    [[KTLoadingAnimationTool sharedInstance] startLodingAnimation];

    [[XYStore defaultStore] restoreTransactionsOnSuccess:^(NSArray *transactions) {
        
        [[KTLoadingAnimationTool sharedInstance] stopLodingAnimation];
        if (transactions.count == 0) {
            
            [KTTipsTool showTipsString:@"Restore purchase failed"];
            return ;
        }
        
        NSUserDefaults *defa = [NSUserDefaults standardUserDefaults];
        
        [defa setBool:YES forKey:k_purchase_status];
        
        [defa synchronize];
        
        [KTTipsTool showTipsString:@"Restore purchase succeeded"];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:@"PurchaseSuccess" object:nil];

                
    } failure:^(NSError *error) {
        
        [[KTLoadingAnimationTool sharedInstance] stopLodingAnimation];

        [KTTipsTool showTipsString:@"Restore purchase failed"];

    }];
}

- (void)termsAction {
    
    [SRoute serviceAgreement];
}

- (void)privacyAction {
 
    [SRoute pricacyAgreement];
}


- (void)productAction:(UIButton *)sender {
    
    if (sender == self.productBtn) {
        self.productIdentifier = k_product_id1;
        self.productBtn.backgroundColor = rgba(56, 94, 239, 1);
        [self.productBtn setTitleColor:rgba(255, 255, 255, 1) forState:UIControlStateNormal];
        self.productBtn.layer.borderColor = rgba(56, 94, 239, 1).CGColor;
        
        self.productBtn1.backgroundColor = rgba(255, 255, 255, 1);
        [self.productBtn1 setTitleColor:rgba(56, 94, 239, 1) forState:UIControlStateNormal];
        self.productBtn1.layer.borderColor = rgba(224, 223, 227, 1).CGColor;
    }else {
        self.productIdentifier = k_product_id2;
        self.productBtn.backgroundColor = rgba(255, 255, 255, 1);
        [self.productBtn setTitleColor:rgba(56, 94, 239, 1) forState:UIControlStateNormal];
        self.productBtn.layer.borderColor = rgba(224, 223, 227, 1).CGColor;
        
        self.productBtn1.backgroundColor = rgba(56, 94, 239, 1);
        [self.productBtn1 setTitleColor:rgba(255, 255, 255, 1) forState:UIControlStateNormal];
        self.productBtn1.layer.borderColor = rgba(56, 94, 239, 1).CGColor;
    }
    
    [self purchase];
}

- (void)purchase {
        
    [[KTLoadingAnimationTool sharedInstance] startLodingAnimation];
    
    [[XYStore defaultStore] addPayment:self.productIdentifier success:^(SKPaymentTransaction *transaction) {
        
        [KTTipsTool showTipsString:@"Subscription succeeded"];

        NSUserDefaults *defa = [NSUserDefaults standardUserDefaults];

        [defa setBool:YES forKey:k_purchase_status];

        [defa synchronize];
                
        dispatch_time_t delayTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC));

        dispatch_after(delayTime, dispatch_get_main_queue(), ^{

            [self dismissViewControllerAnimated:YES completion:nil];

        });

    } failure:^(SKPaymentTransaction *transaction, NSError *error) {

        [[KTLoadingAnimationTool sharedInstance] stopLodingAnimation];

        [KTTipsTool showTipsString:@"Subscription failed"];

    }];
}


@end
