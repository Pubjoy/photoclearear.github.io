//
//  SHomeItemCell.m
//  Skilld
//
//  Created by Speed on 2022/11/18.
//

#import "SHomeItemCell.h"

@interface SHomeItemCell ()
/// <#Description#>
@property (nonatomic, strong) UIImageView *resumeImageView;

@end

@implementation SHomeItemCell

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    return self;
}

- (void)setModel:(SResumeViewerModel *)model {
    _model = model;
    
    self.resumeImageView.image = model.resumeImage;
}

- (void)initView {
    
    UIImageView *resumeImageView = [[UIImageView alloc] initWithFrame:self.contentView.bounds];
    self.resumeImageView = resumeImageView;
    resumeImageView.clipsToBounds = YES;
    [self.contentView addSubview:resumeImageView];
}


@end
