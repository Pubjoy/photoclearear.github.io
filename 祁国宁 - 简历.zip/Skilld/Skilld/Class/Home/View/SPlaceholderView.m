//
//  SPlaceholderView.m
//  Skilld
//
//  Created by Speed on 2022/11/18.
//

#import "SPlaceholderView.h"

@implementation SPlaceholderView

- (instancetype)initWithFrame:(CGRect)frame {
    
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    return self;
}

- (void)initView {
    
    UIImageView *iconView = [[UIImageView alloc] init];
    iconView.image = [UIImage imageNamed:@"placeholder"];
    [self addSubview:iconView];
    [iconView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_ScaleWidth(48));
        make.centerX.mas_equalTo(0);
        make.width.mas_equalTo(S_ScaleWidth(341));
        make.height.mas_equalTo(S_ScaleWidth(362));
    }];
    
    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.text = @"No Resume";
    titleLabel.textColor = rgba(56, 58, 70, 1);
    titleLabel.font = FONTB(26);
    [titleLabel sizeToFit];
    [self addSubview:titleLabel];
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(0);
        make.top.equalTo(iconView.mas_bottom).offset(S_ScaleWidth(36));
    }];
    
    UILabel *subTitleLabel = [[UILabel alloc] init];
    subTitleLabel.text = @"You haven’t created your resume yet , please click below to create your frist resume";
    subTitleLabel.textColor = rgba(138, 148, 160, 1);
    subTitleLabel.font = FONTR(14);
    subTitleLabel.numberOfLines = 2;
    subTitleLabel.textAlignment = NSTextAlignmentCenter;
    [subTitleLabel sizeToFit];
    [self addSubview:subTitleLabel];
    [subTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(0);
        make.top.equalTo(titleLabel.mas_bottom).offset(S_ScaleWidth(10));
        make.width.mas_equalTo(S_ScaleWidth(321));
    }];

}

@end
