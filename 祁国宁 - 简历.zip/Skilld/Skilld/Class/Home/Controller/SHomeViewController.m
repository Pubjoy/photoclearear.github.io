//
//  SHomeViewController.m
//  Skilld
//
//  Created by Speed on 2022/11/18.
//

#import "SHomeViewController.h"
#import "SPlaceholderView.h"
#import "SHomeItemCell.h"
#import "SViewerController.h"

@interface SHomeViewController () <UICollectionViewDataSource, UICollectionViewDelegate>
/// <#Description#>
@property (nonatomic, strong) NSMutableArray *dataList;
/// <#Description#>
@property (nonatomic, strong) SPlaceholderView *emptyView;
/// <#Description#>
@property (nonatomic, strong) UICollectionView *collectionView;


@end

@implementation SHomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self initView];
    
    [self getData];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getData) name:ResumeSaveSuccessNotification object:nil];
}

- (void)initView {
    
    self.view.backgroundColor = rgba(239, 245, 249, 1);
    
    UIView *navigationView = [[UIView alloc] initWithFrame:CGRectMake(0, S_AdaptNaviHeight, S_Screen_W, S_NoStatusBarNavigationBarHeight)];
    [self.view addSubview:navigationView];

    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.text = @"Resume builder";
    titleLabel.font = HMFONTB(20);
    titleLabel.textColor = rgba(20, 23, 34, 1);
    [titleLabel sizeToFit];
    [navigationView addSubview:titleLabel];
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.mas_equalTo(0);
    }];
    
    [self.view addSubview:self.collectionView];
    
    [self.view addSubview:self.emptyView];
}

#pragma mark - <UICollectionViewDataSource, UICollectionViewDelegate>
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    return self.dataList.count;
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    SHomeItemCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([SHomeItemCell class]) forIndexPath:indexPath];
    
    cell.model = self.dataList[indexPath.item];
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    SResumeViewerModel *model = self.dataList[indexPath.item];

    SViewerController *vc = [[SViewerController alloc] init];
    vc.viewerModel = model;
    vc.canEdit = YES;
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - Data
- (void)getData {
    
    [self.dataList removeAllObjects];
    
    NSArray *reslut = [SResumeViewerModel bg_find:Resume_Tablename limit:0 orderBy:@"bg_id" desc:YES];

    if (reslut.count) {
        [self.dataList addObjectsFromArray:reslut];
        self.emptyView.hidden = YES;
    }else {
        self.emptyView.hidden = NO;
    }
    [self.collectionView reloadData];
}


- (NSMutableArray *)dataList {
    if (!_dataList) {
        _dataList = [[NSMutableArray alloc] init];
    }
    return _dataList;
}

- (SPlaceholderView *)emptyView {
    if (!_emptyView) {
        _emptyView = [[SPlaceholderView alloc] initWithFrame:CGRectMake(0, S_NavigationBarHeight, S_Screen_W, self.view.height - S_NavigationBarHeight)];
        _emptyView.hidden = YES;
    }
    return _emptyView;
}

- (UICollectionView *)collectionView {
    if (!_collectionView) {
        
        CGFloat margin_20 = S_ScaleWidth(20);
        CGFloat itemWidth = (S_Screen_W - margin_20 * 3) * 0.5 - 0.5;
        CGFloat itemHeight = S_ScaleWidth(223);
        CGFloat minimumLineSpacing = margin_20;
        CGFloat minimumInteritemSpacing = margin_20;
        
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        layout.minimumLineSpacing = minimumLineSpacing;
        layout.minimumInteritemSpacing = minimumInteritemSpacing;
        layout.itemSize = CGSizeMake(itemWidth, itemHeight);
        
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, S_NavigationBarHeight, S_Screen_W, self.view.height - S_NavigationBarHeight) collectionViewLayout:layout];
        _collectionView.backgroundColor = [UIColor clearColor];
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        _collectionView.contentInset = UIEdgeInsetsMake(margin_20, margin_20, margin_20, margin_20);
        [_collectionView registerClass:[SHomeItemCell class] forCellWithReuseIdentifier:NSStringFromClass([SHomeItemCell class])];
    }
    return _collectionView;
}

@end
