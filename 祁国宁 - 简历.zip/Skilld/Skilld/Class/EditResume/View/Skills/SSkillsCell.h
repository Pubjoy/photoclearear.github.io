//
//  SSkillsCell.h
//  Skilld
//
//  Created by Speed on 2022/11/20.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SSkillsCell : UITableViewCell

@property (nonatomic, assign) NSInteger index;

@property (nonatomic, strong) SResumeSkillsModel *skill;

@property (nonatomic, copy) void(^editBlock)(void);

@property (nonatomic, copy) void(^deleteBlock)(void);

@end

NS_ASSUME_NONNULL_END
