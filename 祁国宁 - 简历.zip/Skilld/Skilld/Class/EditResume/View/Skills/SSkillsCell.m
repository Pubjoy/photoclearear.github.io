//
//  SSkillsCell.m
//  Skilld
//
//  Created by Speed on 2022/11/20.
//

#import "SSkillsCell.h"

@interface SSkillsCell ()

@property (nonatomic, weak) UILabel *titleLabel;

@property (nonatomic, weak) UILabel *skillLabel;

@end

@implementation SSkillsCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self initView];
    }
    return self;
}

- (void)setIndex:(NSInteger)index {
    _index = index;
    self.titleLabel.text = [NSString stringWithFormat:@"Work experience (%ld)", index];
}

- (void)setSkill:(SResumeSkillsModel *)skill {
    _skill = skill;
    
    self.skillLabel.text = skill.skill;
}

- (void)deleteClick {
    
    if (self.deleteBlock) {
        self.deleteBlock();
    }
}

- (void)editClick {
    if (self.editBlock) {
        self.editBlock();
    }
}

- (void)initView {
    
    CGFloat margin_10 = S_ScaleWidth(10);
    CGFloat margin_12 = S_ScaleWidth(12);
    CGFloat margin_15 = S_ScaleWidth(15);
    CGFloat margin_20 = S_ScaleWidth(20);
    
    UIView *topContainer = [[UIView alloc] init];
    [self.contentView addSubview:topContainer];
    [topContainer mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.mas_equalTo(0);
        make.height.mas_equalTo(S_ScaleWidth(46));
    }];
    
    UILabel *titleLabel = [[UILabel alloc] init];
    self.titleLabel = titleLabel;
    titleLabel.textColor = rgba(20, 23, 34, 1);
    titleLabel.font = HMFONTM(15);
    [titleLabel sizeToFit];
    [topContainer addSubview:titleLabel];
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(margin_20);
        make.bottom.mas_equalTo(-margin_12);
    }];

    UIButton *deleteButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [deleteButton setImage:[UIImage imageNamed:@"delete_icon"] forState:UIControlStateNormal];
    [deleteButton addTarget:self action:@selector(deleteClick) forControlEvents:UIControlEventTouchUpInside];
    [topContainer addSubview:deleteButton];
    [deleteButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(0);
        make.right.mas_equalTo(-margin_10);
        make.size.mas_equalTo(S_ScaleWidth(44));
    }];
    
    UIButton *editButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [editButton setImage:[UIImage imageNamed:@"edit_icon"] forState:UIControlStateNormal];
    [editButton addTarget:self action:@selector(editClick) forControlEvents:UIControlEventTouchUpInside];
    [topContainer addSubview:editButton];
    [editButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(0);
        make.right.equalTo(deleteButton.mas_left);
        make.size.mas_equalTo(S_ScaleWidth(44));
    }];
    
    UIView *container = [[UIView alloc] init];
    container.backgroundColor = rgba(239, 245, 249, 1);
    container.layer.cornerRadius = margin_10;
    container.clipsToBounds = YES;
    [self.contentView addSubview:container];
    [container mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(topContainer.mas_bottom);
        make.left.mas_equalTo(margin_20);
        make.right.mas_equalTo(-margin_20);
        make.bottom.mas_equalTo(-margin_10);
    }];
    
    UILabel *skillLabel = [[UILabel alloc] init];
    self.skillLabel = skillLabel;
    skillLabel.textColor = rgba(20, 23, 34, 1);
    skillLabel.font = HMFONTB(15);
    [container addSubview:skillLabel];
    [skillLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(0);
        make.left.mas_equalTo(margin_10);
        make.right.mas_equalTo(-margin_15);
    }];
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
