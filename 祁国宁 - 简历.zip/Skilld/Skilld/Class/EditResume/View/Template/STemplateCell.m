//
//  STemplateCell.m
//  Skilld
//
//  Created by Speed on 2022/12/2.
//

#import "STemplateCell.h"

@interface STemplateCell ()
/// <#Description#>
@property (nonatomic, weak) UIImageView *imageView;

@end

@implementation STemplateCell

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    return self;
}

- (void)setStyle:(NSInteger)style {
    _style = style;
    self.imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"resume_style_small_%ld", style]];
}

- (void)setIsCheck:(BOOL)isCheck {
    _isCheck = isCheck;
    if (isCheck) {
        self.imageView.layer.borderColor = rgba(56, 94, 239, 1).CGColor;
    }else {
        self.imageView.layer.borderColor = [UIColor clearColor].CGColor;
    }
}

- (void)initView {
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:self.contentView.bounds];
    self.imageView = imageView;
    imageView.layer.cornerRadius = S_ScaleWidth(4);
    imageView.layer.borderColor = [UIColor clearColor].CGColor;
    imageView.layer.borderWidth = 1;
    imageView.clipsToBounds = YES;
    [self.contentView addSubview:imageView];
}

@end
