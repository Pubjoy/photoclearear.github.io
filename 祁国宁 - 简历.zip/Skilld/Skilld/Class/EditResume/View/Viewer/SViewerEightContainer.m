//
//  SViewerEightContainer.m
//  Skilld
//
//  Created by Speed on 2022/12/5.
//

#import "SViewerEightContainer.h"

@interface SViewerEightContainer ()
@property (nonatomic, strong) SResumeModel *resume;
@end

@implementation SViewerEightContainer

- (instancetype)initWithFrame:(CGRect)frame resume:(SResumeModel *)resume {
    
    if (self = [super initWithFrame:frame]) {
        
        self.resume = resume;
        
        [self initView];
    }
    return self;
}

- (void)initView {
        
    self.backgroundColor = rgba(255, 255, 255, 1);
    
    self.scrollView.frame = self.bounds;
    [self addSubview:self.scrollView];
        
    if (self.resume.basicInfo.firstName.length || self.resume.basicInfo.lastName.length) {
        self.userNameLabel.text = [NSString stringWithFormat:@"%@\n%@", self.resume.basicInfo.firstName, self.resume.basicInfo.lastName];
        self.userNameLabel.font = HMFONTB(24);
        [self.scrollView addSubview:self.userNameLabel];
        [self.userNameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(S_ScaleWidth(16));
            make.left.mas_equalTo(S_ScaleWidth(37));
        }];
    }
    
    UIView *leftView = [[UIView alloc] init];
    leftView.backgroundColor = rgba(22, 49, 135, 1);
    [self.scrollView addSubview:leftView];
    [leftView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_ScaleWidth(15));
        make.left.mas_equalTo(0);
        make.width.mas_equalTo(S_ScaleWidth(13));
        make.height.mas_equalTo(S_ScaleWidth(67));
    }];
    
    UILabel *subTitleLabel = [[UILabel alloc] init];
    subTitleLabel.text = self.resume.goal.jobPosition;
    subTitleLabel.textColor = rgba(0, 8, 18, 1);
    subTitleLabel.font = HMFONTM(10);
    [self.scrollView addSubview:subTitleLabel];
    [subTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_ScaleWidth(73));
        make.left.mas_equalTo(S_ScaleWidth(38));
        make.height.mas_equalTo(S_ScaleWidth(8));
    }];
    
    UIView *lineView = [[UIView alloc] init];
    lineView.backgroundColor = rgba(80, 105, 175, 1);
    [self.scrollView addSubview:lineView];
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(subTitleLabel);
        make.right.equalTo(subTitleLabel.mas_left);
        make.width.mas_equalTo(1);
        make.height.mas_equalTo(S_ScaleWidth(13));
    }];
    
    UIView *basicInfoContainer = [[UIView alloc] init];
    basicInfoContainer.backgroundColor = rgba(22, 49, 135, 1);
    [self.scrollView addSubview:basicInfoContainer];
    [basicInfoContainer mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_ScaleWidth(15));
        make.left.mas_equalTo(S_ScaleWidth(194));
        make.width.mas_equalTo(S_ScaleWidth(106));
    }];

    // Phone
    self.phoneImageView.image = [UIImage imageNamed:@"viewer_phone_3"];
    [self.scrollView addSubview:self.phoneImageView];
    [self.phoneImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_ScaleWidth(20));
        make.left.mas_equalTo(S_ScaleWidth(201));
        make.size.mas_equalTo(S_ScaleWidth(12));
    }];
    
    self.phoneLabel.textColor = rgba(255, 255, 255, 1);
    self.phoneLabel.text = self.resume.basicInfo.phone;
    [self.scrollView addSubview:self.phoneLabel];
    [self.phoneLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.phoneImageView.mas_right).offset(S_ScaleWidth(2));
        make.centerY.equalTo(self.phoneImageView);
    }];
    
    
    // Email
    self.emailImageView.image = [UIImage imageNamed:@"viewer_email_3"];
    [self.scrollView addSubview:self.emailImageView];
    [self.emailImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.phoneImageView.mas_bottom).offset(S_ScaleWidth(2));
        make.left.equalTo(self.phoneImageView);
        make.size.equalTo(self.phoneImageView);
    }];
    
    self.emailLabel.textColor = rgba(255, 255, 255, 1);
    self.emailLabel.text = self.resume.basicInfo.email;
    [self.scrollView addSubview:self.emailLabel];
    [self.emailLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.emailImageView.mas_right).offset(S_ScaleWidth(2));
        make.centerY.equalTo(self.emailImageView);
    }];
    
    
    // Blog
    self.blogImageView.image = [UIImage imageNamed:@"viewer_blogs_3"];
    [self.scrollView addSubview:self.blogImageView];
    [self.blogImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.emailImageView.mas_bottom).offset(S_ScaleWidth(2));
        make.left.equalTo(self.emailImageView);
        make.size.equalTo(self.emailImageView);
    }];
    
    self.blogLabel.textColor = rgba(255, 255, 255, 1);
    self.blogLabel.text = self.resume.basicInfo.blogs;
    [self.scrollView addSubview:self.blogLabel];
    [self.blogLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.blogImageView.mas_right).offset(S_ScaleWidth(2));
        make.centerY.equalTo(self.blogImageView);
    }];

    
    // Address
    self.addressImageView.image = [UIImage imageNamed:@"viewer_address_3"];
    [self.scrollView addSubview:self.addressImageView];
    [self.addressImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.blogImageView.mas_bottom).offset(S_ScaleWidth(2));
        make.left.equalTo(self.blogImageView);
        make.size.equalTo(self.blogImageView);
    }];
    
    self.addressLabel.textColor = rgba(255, 255, 255, 1);
    self.addressLabel.text = self.resume.basicInfo.address;
    [self.scrollView addSubview:self.addressLabel];
    [self.addressLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.addressImageView.mas_right).offset(S_ScaleWidth(2));
        make.centerY.equalTo(self.addressImageView);
        make.width.mas_equalTo(S_ScaleWidth(73));
    }];
    
    [basicInfoContainer mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.addressLabel.mas_bottom).offset(S_ScaleWidth(7));
    }];
    
    // Goal
    self.goalTitleLabel.text = @"GOAL";
    self.goalTitleLabel.font = HMFONTB(10);
    self.goalTitleLabel.textColor = rgba(0, 8, 18, 1);
    [self.scrollView addSubview:self.goalTitleLabel];
    [self.goalTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(leftView.mas_bottom).offset(S_ScaleWidth(26));
        make.left.mas_equalTo(S_ScaleWidth(12));
    }];
        
    self.goalJobLabel.font = HMFONTB(8);
    self.goalJobLabel.text = self.resume.goal.jobPosition;
    [self.scrollView addSubview:self.goalJobLabel];
    [self.goalJobLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.goalTitleLabel.mas_bottom).offset(S_ScaleWidth(4));
        make.left.equalTo(self.goalTitleLabel);
        make.width.mas_equalTo(S_ScaleWidth(94));
    }];

    self.goalContentLabel.textColor = rgba(40, 46, 54, 1);
    self.goalContentLabel.text = self.resume.goal.content;
    [self.scrollView addSubview:self.goalContentLabel];
    [self.goalContentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.goalJobLabel.mas_bottom).offset(S_ScaleWidth(4));
        make.left.equalTo(self.goalTitleLabel);
        make.width.mas_equalTo(S_ScaleWidth(94));
    }];
    
    
    // Summary
    self.summaryTitleLabel.text = @"SUMMARY";
    self.summaryTitleLabel.font = HMFONTB(10);
    self.summaryTitleLabel.textColor = rgba(0, 8, 18, 1);
    [self.scrollView addSubview:self.summaryTitleLabel];
    [self.summaryTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.goalContentLabel.mas_bottom).offset(S_ScaleWidth(17));
        make.left.mas_equalTo(S_ScaleWidth(12));
    }];
        
    self.summaryDescLabel.textColor = rgba(40, 46, 54, 1);
    self.summaryDescLabel.text = self.resume.summary.summary;
    [self.scrollView addSubview:self.summaryDescLabel];
    [self.summaryDescLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.summaryTitleLabel.mas_bottom).offset(S_ScaleWidth(4));
        make.left.equalTo(self.summaryTitleLabel);
        make.width.mas_equalTo(S_ScaleWidth(94));
    }];
    
    // Skills
    self.skillTitleLabel.text = @"SKILLS";
    self.skillTitleLabel.font = HMFONTB(10);
    self.skillTitleLabel.textColor = rgba(0, 8, 18, 1);
    [self.scrollView addSubview:self.skillTitleLabel];
    [self.skillTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.summaryDescLabel.mas_bottom).offset(S_ScaleWidth(17));
        make.left.mas_equalTo(S_ScaleWidth(12));
    }];
    
    UILabel *lastSkillLabel = self.skillTitleLabel;
    for (int i = 0; i < self.resume.skills.count; i++) {
        
        SResumeSkillsModel *skill = self.resume.skills[i];
        
        UILabel *skillLabel = [[UILabel alloc] init];
        skillLabel.text = skill.skill;
        skillLabel.textColor = rgba(0, 0, 0, 1);
        skillLabel.font = HMFONTB(8);
        [self.scrollView addSubview:skillLabel];
        [skillLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            if (i== 0) {
                make.top.equalTo(self.skillTitleLabel.mas_bottom).offset(S_ScaleWidth(10));

            } else {
                make.top.equalTo(lastSkillLabel.mas_bottom).offset(S_ScaleWidth(3));
            }
            make.left.equalTo(self.skillTitleLabel).offset(S_ScaleWidth(6));
            make.width.mas_equalTo(S_ScaleWidth(88));
        }];
        lastSkillLabel = skillLabel;
        
        UIView *pointView = [[UIView alloc] init];
        pointView.backgroundColor = rgba(22, 49, 135, 1);
        [self.scrollView addSubview:pointView];
        [pointView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(skillLabel.mas_left).offset(-S_ScaleWidth(4));
            make.centerY.equalTo(skillLabel);
            make.size.mas_equalTo(2);
        }];
    }
    
    
    // Work Experience
    self.workTitleLabel.text = @"WORK EXPERIENCE";
    self.workTitleLabel.font = HMFONTB(10);
    self.workTitleLabel.textColor = rgba(0, 8, 18, 1);
    [self.scrollView addSubview:self.workTitleLabel];
    [self.workTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.goalTitleLabel);
        make.left.mas_equalTo(S_ScaleWidth(121));
    }];
    
    UILabel *lastWorkLabel = self.workTitleLabel;
    for (int i = 0 ; i < self.resume.works.count; i++) {
        
        SResumeExperienceModel *experience = self.resume.works[i];
        
        UILabel *employLabel = [[UILabel alloc] init];
        employLabel.text = experience.employ;
        employLabel.textColor = rgba(0, 0, 0, 1);
        employLabel.font = HMFONTB(8);
        [self.scrollView addSubview:employLabel];
        [employLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            if (i== 0) {
                make.top.equalTo(self.workTitleLabel.mas_bottom).offset(S_ScaleWidth(2));

            } else {
                make.top.equalTo(lastWorkLabel.mas_bottom).offset(S_ScaleWidth(5));
            }
            make.left.equalTo(self.workTitleLabel).offset(S_ScaleWidth(5));
            make.width.mas_equalTo(S_ScaleWidth(163));
        }];
        
        UIView *pointView = [[UIView alloc] init];
        pointView.backgroundColor = rgba(22, 49, 135, 1);
        [self.scrollView addSubview:pointView];
        [pointView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(employLabel.mas_left).offset(-S_ScaleWidth(3));
            make.centerY.equalTo(employLabel);
            make.size.mas_equalTo(2);
        }];
        
        UILabel *jobTitleLabel = [[UILabel alloc] init];
        jobTitleLabel.text = experience.jobTitle;
        jobTitleLabel.textColor = rgba(0, 0, 0, 1);
        jobTitleLabel.font = HMFONTM(5);
        [self.scrollView addSubview:jobTitleLabel];
        [jobTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(employLabel.mas_bottom).offset(S_ScaleWidth(4));
            make.left.width.equalTo(employLabel);
        }];
        
        UILabel *cityLabel = [[UILabel alloc] init];
        cityLabel.text = experience.city;
        cityLabel.textColor = rgba(0, 0, 0, 1);
        cityLabel.font = HMFONTM(5);
        [self.scrollView addSubview:cityLabel];
        [cityLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(jobTitleLabel.mas_bottom).offset(S_ScaleWidth(3));
            make.left.width.equalTo(jobTitleLabel);
        }];
        
        UILabel *dateLabel = [[UILabel alloc] init];
        dateLabel.text = [NSString stringWithFormat:@"%@ - %@", experience.startDate, experience.endDate];
        dateLabel.textColor = rgba(80, 80, 80, 1);
        dateLabel.font = FONTR(5);
        [self.scrollView addSubview:dateLabel];
        [dateLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(employLabel);
            make.centerY.equalTo(jobTitleLabel);
        }];

        UILabel *descLabel = [[UILabel alloc] init];
        descLabel.text = experience.jobDesc;
        descLabel.textColor = rgba(80, 80, 80, 1);
        descLabel.font = FONTR(5);
        descLabel.numberOfLines = 0;
        [self.scrollView addSubview:descLabel];
        [descLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(cityLabel.mas_bottom).offset(S_ScaleWidth(3));
            make.left.equalTo(cityLabel);
            make.width.mas_equalTo(S_ScaleWidth(163));
        }];
        
        lastWorkLabel = descLabel;
    }

    UIView *lineView2 = [[UIView alloc] init];
    lineView2.backgroundColor = rgba(22, 49, 135, 1);
    [self.scrollView addSubview:lineView2];
    [lineView2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.workTitleLabel);
        make.bottom.equalTo(lastWorkLabel);
        make.width.mas_equalTo(1);
        make.right.equalTo(self.workTitleLabel.mas_left).offset(-S_ScaleWidth(7));
    }];

    // Education
    self.educationTitleLabel.text = @"EDUCATION";
    self.educationTitleLabel.font = HMFONTB(10);
    self.educationTitleLabel.textColor = rgba(0, 8, 18, 1);
    [self.scrollView addSubview:self.educationTitleLabel];
    [self.educationTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(lastWorkLabel.mas_bottom).offset(S_ScaleWidth(10));
        make.left.equalTo(self.workTitleLabel);
    }];
    
    
    CGFloat containerHeight = S_ScaleWidth(30);
    CGFloat containerWidth = S_ScaleWidth(78);
    UIView *lastView;
    for (int i = 0; i < self.resume.educations.count; i++) {
        
        NSInteger row = i / 2;
        NSInteger col = i % 2;
        
        UIView *educationContainer = [[UIView alloc] init];
        [self.scrollView addSubview:educationContainer];
        [educationContainer mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.educationTitleLabel.mas_bottom).offset(S_ScaleWidth(5) + (containerHeight + S_ScaleWidth(5)) * row);
            make.left.equalTo(self.educationTitleLabel).offset((containerWidth + S_ScaleWidth(12)) * col);
            make.width.mas_equalTo(containerWidth);
            make.height.mas_equalTo(containerHeight);
        }];
        
        lastView = educationContainer;
        
        SResumeEducationModel *education = self.resume.educations[i];
        
        UILabel *schoolLabel = [[UILabel alloc] init];
        schoolLabel.text = education.school;
        schoolLabel.textColor = rgba(0, 0, 0, 1);
        schoolLabel.font = HMFONTB(8);
        [educationContainer addSubview:schoolLabel];
        [schoolLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(0);
            make.left.right.mas_equalTo(0);
        }];
        
        UILabel *majorLabel = [[UILabel alloc] init];
        majorLabel.text = education.major;
        majorLabel.textColor = rgba(0, 0, 0, 1);
        majorLabel.font = FONTR(5);
        [educationContainer addSubview:majorLabel];
        [majorLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(schoolLabel.mas_bottom).offset(S_ScaleWidth(4));
            make.left.right.mas_equalTo(0);
        }];
        
        UILabel *dateLabel = [[UILabel alloc] init];
        dateLabel.text = [NSString stringWithFormat:@"%@ - %@", education.startDate, education.endDate];
        dateLabel.textColor = rgba(0, 0, 0, 1);
        dateLabel.font = FONTR(5);
        [educationContainer addSubview:dateLabel];
        [dateLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(majorLabel.mas_bottom).offset(S_ScaleWidth(3));
            make.left.right.mas_equalTo(0);
        }];
    }
    
    
    [lastSkillLabel.superview layoutIfNeeded];
    
    if (lastView) {
        
        if (lastSkillLabel.bottom < lastView.bottom) {
            
            if (lastView.bottom > self.scrollView.bottom) {
                self.scrollView.contentSize = CGSizeMake(self.width, lastView.bottom + S_ScaleWidth(15));
            }
        }else {
            if (lastSkillLabel.bottom > self.scrollView.bottom) {
                self.scrollView.contentSize = CGSizeMake(self.width, lastSkillLabel.bottom + S_ScaleWidth(15));
            }
        }
        
    }else {
        
        if (lastSkillLabel.bottom < self.educationTitleLabel.bottom) {
            
            if (self.educationTitleLabel.bottom > self.scrollView.bottom) {
                self.scrollView.contentSize = CGSizeMake(self.width, self.educationTitleLabel.bottom + S_ScaleWidth(15));
            }else {
                self.scrollView.contentSize = self.scrollView.bounds.size;
            }
        }else {
            if (lastSkillLabel.bottom > self.scrollView.bottom) {
                self.scrollView.contentSize = CGSizeMake(self.width, lastSkillLabel.bottom + S_ScaleWidth(15));
            }else {
                self.scrollView.contentSize = self.scrollView.bounds.size;
            }
        }
    }
}

@end
