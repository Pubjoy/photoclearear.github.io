//
//  SViewerFirstContainer.h
//  Skilld
//
//  Created by Speed on 2022/11/24.
//

#import "SViewerBaseContainer.h"

NS_ASSUME_NONNULL_BEGIN

@interface SViewerFirstContainer : SViewerBaseContainer

- (instancetype)initWithFrame:(CGRect)frame resume:(SResumeModel *)resume;

@end

NS_ASSUME_NONNULL_END
