//
//  SViewerSevenContainer.h
//  Skilld
//
//  Created by Speed on 2022/12/5.
//

#import "SViewerBaseContainer.h"

NS_ASSUME_NONNULL_BEGIN

@interface SViewerSevenContainer : SViewerBaseContainer
- (instancetype)initWithFrame:(CGRect)frame resume:(SResumeModel *)resume;

@end

NS_ASSUME_NONNULL_END
