//
//  SViewerThreeContainer.m
//  Skilld
//
//  Created by Speed on 2022/12/5.
//

#import "SViewerThreeContainer.h"

@interface SViewerThreeContainer ()
@property (nonatomic, strong) SResumeModel *resume;
@end

@implementation SViewerThreeContainer

- (instancetype)initWithFrame:(CGRect)frame resume:(SResumeModel *)resume {
    
    if (self = [super initWithFrame:frame]) {
        
        self.resume = resume;
        
        [self initView];
    }
    return self;
}

- (void)initView {

    self.backgroundColor = [UIColor whiteColor];
    
    self.scrollView.frame = self.bounds;
    [self addSubview:self.scrollView];
    
    UIView *topView = [[UIView alloc] init];
    topView.backgroundColor = rgba(242, 244, 249, 1);
    [self.scrollView addSubview:topView];
    [topView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.mas_equalTo(0);
        make.width.mas_equalTo(self.width);
        make.height.mas_equalTo(S_ScaleWidth(60));
    }];
    
    UIView *nameBackView = [[UIView alloc] init];
    nameBackView.frame = CGRectMake(0, 0, S_ScaleWidth(218), S_ScaleWidth(43));
    nameBackView.layer.borderWidth = S_ScaleWidth(4);
    nameBackView.layer.borderColor = [UIColor whiteColor].CGColor;
    [self.scrollView addSubview:nameBackView];
    [nameBackView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_ScaleWidth(7));
        make.left.mas_equalTo(S_ScaleWidth(42));
        make.width.mas_equalTo(S_ScaleWidth(218));
        make.height.mas_equalTo(S_ScaleWidth(43));
    }];
    
    if (self.resume.basicInfo.firstName.length || self.resume.basicInfo.lastName.length) {
        self.userNameLabel.text = [NSString stringWithFormat:@"%@ %@", self.resume.basicInfo.firstName, self.resume.basicInfo.lastName];
        self.userNameLabel.font = HMFONTR(20);
        [nameBackView addSubview:self.userNameLabel];
        [self.userNameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.mas_equalTo(0);
        }];
    }
    
    UILabel *subTitleLabel = [[UILabel alloc] init];
    subTitleLabel.text = self.resume.goal.jobPosition;
    subTitleLabel.textColor = rgba(110, 116, 116, 1);
    subTitleLabel.font = FONTR(8);
    subTitleLabel.backgroundColor = rgba(255, 255, 255, 1);
    subTitleLabel.textAlignment = NSTextAlignmentCenter;
    [self.scrollView addSubview:subTitleLabel];
    [subTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(nameBackView).offset(S_ScaleWidth(36));
        make.centerX.equalTo(nameBackView);
        make.width.mas_equalTo(S_ScaleWidth(88));
        make.height.mas_equalTo(S_ScaleWidth(13));
    }];
        
    UIView *leftContainer = [[UIView alloc] init];
    leftContainer.backgroundColor = rgba(242, 244, 249, 1);
    leftContainer.layer.cornerRadius = S_ScaleWidth(4);
    leftContainer.clipsToBounds = YES;
    [self.scrollView addSubview:leftContainer];
    
    // Phone
    [self.scrollView addSubview:self.phoneImageView];
    [self.phoneImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_ScaleWidth(73));
        make.left.mas_equalTo(S_ScaleWidth(13));
        make.size.mas_equalTo(S_ScaleWidth(12));
    }];
    
    self.phoneLabel.text = self.resume.basicInfo.phone;
    [self.scrollView addSubview:self.phoneLabel];
    [self.phoneLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.phoneImageView.mas_right).offset(S_ScaleWidth(3));
        make.centerY.equalTo(self.phoneImageView);
    }];
    
    
    // Email
    [self.scrollView addSubview:self.emailImageView];
    [self.emailImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.phoneImageView.mas_bottom).offset(S_ScaleWidth(3));
        make.left.equalTo(self.phoneImageView);
        make.size.equalTo(self.phoneImageView);
    }];
    
    self.emailLabel.text = self.resume.basicInfo.email;
    [self.scrollView addSubview:self.emailLabel];
    [self.emailLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.emailImageView.mas_right).offset(S_ScaleWidth(3));
        make.centerY.equalTo(self.emailImageView);
    }];
    
    // Blog
    [self.scrollView addSubview:self.blogImageView];
    [self.blogImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.emailImageView.mas_bottom).offset(S_ScaleWidth(3));
        make.left.equalTo(self.emailImageView);
        make.size.equalTo(self.emailImageView);
    }];
    
    self.blogLabel.text = self.resume.basicInfo.blogs;
    [self.scrollView addSubview:self.blogLabel];
    [self.blogLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.blogImageView.mas_right).offset(S_ScaleWidth(3));
        make.centerY.equalTo(self.blogImageView);
    }];

    // Address
    [self.scrollView addSubview:self.addressImageView];
    [self.addressImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.blogImageView.mas_bottom).offset(S_ScaleWidth(3));
        make.left.equalTo(self.blogImageView);
        make.size.equalTo(self.blogImageView);
    }];
    
    self.addressLabel.text = self.resume.basicInfo.address;
    [self.scrollView addSubview:self.addressLabel];
    [self.addressLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.addressImageView.mas_right).offset(S_ScaleWidth(3));
        make.top.equalTo(self.addressImageView).offset(S_ScaleWidth(3));
        make.width.mas_equalTo(S_ScaleWidth(77));
    }];
    

    // Education
    self.educationTitleLabel.text = @"E d u c a t i o n";
    self.educationTitleLabel.font = HMFONTM(10);
    [self.scrollView addSubview:self.educationTitleLabel];
    [self.educationTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.addressLabel.mas_bottom).offset(S_ScaleWidth(11));
        make.left.mas_equalTo(S_ScaleWidth(15));
    }];
    
    UIView *educationLine = [[UIView alloc] init];
    educationLine.backgroundColor = rgba(193, 208, 237, 1);
    educationLine.layer.cornerRadius = 0.5;
    educationLine.clipsToBounds = YES;
    [self.scrollView addSubview:educationLine];
    [educationLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.educationTitleLabel.mas_bottom);
        make.left.equalTo(self.educationTitleLabel);
        make.width.mas_equalTo(S_ScaleWidth(93));
        make.height.mas_equalTo(1);
    }];

    
    UILabel *lastEducationLabel = self.educationTitleLabel;
    for (int i = 0; i < self.resume.educations.count; i++) {
        
        SResumeEducationModel *education = self.resume.educations[i];
        
        UILabel *schoolLabel = [[UILabel alloc] init];
        schoolLabel.text = education.school;
        schoolLabel.textColor = rgba(0, 0, 0, 1);
        schoolLabel.font = FONTB(8);
        [self.scrollView addSubview:schoolLabel];
        [schoolLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            if (i== 0) {
                make.top.equalTo(self.educationTitleLabel.mas_bottom).offset(S_ScaleWidth(5));

            } else {
                make.top.equalTo(lastEducationLabel.mas_bottom).offset(S_ScaleWidth(5));
            }
            make.left.equalTo(self.educationTitleLabel);
            make.width.mas_equalTo(S_ScaleWidth(93));
        }];
        
        UILabel *majorLabel = [[UILabel alloc] init];
        majorLabel.text = education.major;
        majorLabel.textColor = rgba(0, 0, 0, 1);
        majorLabel.font = FONTR(5);
        [self.scrollView addSubview:majorLabel];
        [majorLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(schoolLabel.mas_bottom).offset(S_ScaleWidth(4));
            make.left.width.equalTo(schoolLabel);
        }];
        
        UILabel *dateLabel = [[UILabel alloc] init];
        dateLabel.text = [NSString stringWithFormat:@"%@ - %@", education.startDate, education.endDate];
        dateLabel.textColor = rgba(0, 0, 0, 1);
        dateLabel.font = FONTR(5);
        [self.scrollView addSubview:dateLabel];
        [dateLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(majorLabel.mas_bottom).offset(S_ScaleWidth(4));
            make.left.width.equalTo(majorLabel);
        }];
        
        lastEducationLabel = dateLabel;
    }
        
    // Skills
    self.skillTitleLabel.text = @"S k i l l s";
    self.skillTitleLabel.font = HMFONTM(10);
    [self.scrollView addSubview:self.skillTitleLabel];
    [self.skillTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(lastEducationLabel.mas_bottom).offset(S_ScaleWidth(15));
        make.left.equalTo(lastEducationLabel);
    }];
    
    UIView *skillsLine = [[UIView alloc] init];
    skillsLine.backgroundColor = rgba(193, 208, 237, 1);
    skillsLine.layer.cornerRadius = 0.5;
    skillsLine.clipsToBounds = YES;
    [self.scrollView addSubview:skillsLine];
    [skillsLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.skillTitleLabel.mas_bottom);
        make.left.equalTo(self.skillTitleLabel);
        make.width.mas_equalTo(S_ScaleWidth(93));
        make.height.mas_equalTo(1);
    }];
    
    UILabel *lastSkillLabel = self.skillTitleLabel;
    for (int i = 0; i < self.resume.skills.count; i++) {
        
        SResumeSkillsModel *skill = self.resume.skills[i];
        
        UILabel *skillLabel = [[UILabel alloc] init];
        skillLabel.text = skill.skill;
        skillLabel.textColor = rgba(0, 0, 0, 1);
        skillLabel.font = FONTB(9);
        [self.scrollView addSubview:skillLabel];
        [skillLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            if (i== 0) {
                make.top.equalTo(self.skillTitleLabel.mas_bottom).offset(S_ScaleWidth(4));

            } else {
                make.top.equalTo(lastSkillLabel.mas_bottom).offset(S_ScaleWidth(4));
            }
            make.left.equalTo(self.skillTitleLabel).offset(S_ScaleWidth(4));
            make.width.mas_equalTo(S_ScaleWidth(75));
        }];
        lastSkillLabel = skillLabel;
        
        UIView *pointView = [[UIView alloc] init];
        pointView.backgroundColor = rgba(197, 210, 219, 1);
        pointView.layer.cornerRadius = 1;
        pointView.clipsToBounds = YES;
        [self.scrollView addSubview:pointView];
        [pointView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(skillLabel.mas_left).offset(-S_ScaleWidth(3));
            make.centerY.equalTo(skillLabel);
            make.size.mas_equalTo(2);
        }];
    }
    
    
    // Goal
    self.goalTitleLabel.text = @"G o a l";
    self.goalTitleLabel.font = HMFONTM(10);
    [self.scrollView addSubview:self.goalTitleLabel];
    [self.goalTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(lastSkillLabel.mas_bottom).offset(S_ScaleWidth(8));
        make.left.equalTo(self.skillTitleLabel);
    }];
    
    UIView *goalLine = [[UIView alloc] init];
    goalLine.backgroundColor = rgba(193, 208, 237, 1);
    goalLine.layer.cornerRadius = 0.5;
    goalLine.clipsToBounds = YES;
    [self.scrollView addSubview:goalLine];
    [goalLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.goalTitleLabel.mas_bottom);
        make.left.equalTo(self.goalTitleLabel);
        make.width.mas_equalTo(S_ScaleWidth(93));
        make.height.mas_equalTo(1);
    }];
    
    self.goalJobLabel.text = self.resume.goal.jobPosition;
    [self.scrollView addSubview:self.goalJobLabel];
    [self.goalJobLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.goalTitleLabel.mas_bottom).offset(S_ScaleWidth(5));
        make.left.equalTo(self.goalTitleLabel);
        make.width.mas_equalTo(S_ScaleWidth(93));
    }];

    self.goalContentLabel.text = self.resume.goal.content;
    [self.scrollView addSubview:self.goalContentLabel];
    [self.goalContentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.goalJobLabel.mas_bottom).offset(S_ScaleWidth(5));
        make.left.equalTo(self.goalTitleLabel);
        make.width.mas_equalTo(S_ScaleWidth(95));
    }];
    
    [leftContainer mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_ScaleWidth(60));
        make.left.mas_equalTo(S_ScaleWidth(10));
        make.width.mas_equalTo(S_ScaleWidth(103));
        make.bottom.equalTo(self.goalContentLabel.mas_bottom).offset(S_ScaleWidth(13));
    }];
    
    
    // Work Experience
    self.workTitleLabel.text = @"W o r k  E x p e r i e n c e";
    self.workTitleLabel.font = HMFONTM(10);
    [self.scrollView addSubview:self.workTitleLabel];
    [self.workTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(topView.mas_bottom).offset(S_ScaleWidth(8));
        make.left.equalTo(leftContainer.mas_right).offset(S_ScaleWidth(9));
    }];
    
    UIView *workLine = [[UIView alloc] init];
    workLine.backgroundColor = rgba(193, 208, 237, 1);
    workLine.layer.cornerRadius = 0.5;
    workLine.clipsToBounds = YES;
    [self.scrollView addSubview:workLine];
    [workLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.workTitleLabel.mas_bottom);
        make.left.equalTo(self.workTitleLabel);
        make.width.mas_equalTo(S_ScaleWidth(169));
        make.height.mas_equalTo(1);
    }];

    UILabel *lastWorkLabel = self.workTitleLabel;
    for (int i = 0 ; i < self.resume.works.count; i++) {
        
        SResumeExperienceModel *experience = self.resume.works[i];
        
        UILabel *dateLabel = [[UILabel alloc] init];
        dateLabel.text = [NSString stringWithFormat:@"%@ - %@", experience.startDate, experience.endDate];
        dateLabel.textColor = rgba(0, 0, 0, 1);
        dateLabel.font = FONTR(5);
        dateLabel.textAlignment = NSTextAlignmentCenter;
        dateLabel.backgroundColor = rgba(242, 244, 249, 1);
        dateLabel.layer.cornerRadius = S_ScaleWidth(4);
        dateLabel.clipsToBounds = YES;
        [self.scrollView addSubview:dateLabel];
        [dateLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            
            if (i== 0) {
                make.top.equalTo(self.workTitleLabel.mas_bottom).offset(S_ScaleWidth(4));

            } else {
                make.top.equalTo(lastWorkLabel.mas_bottom).offset(S_ScaleWidth(9));
            }
            make.left.equalTo(self.workTitleLabel);
            make.width.mas_equalTo(S_ScaleWidth(49));
            make.height.mas_equalTo(S_ScaleWidth(8));
        }];
        
        UILabel *employLabel = [[UILabel alloc] init];
        employLabel.text = experience.employ;
        employLabel.textColor = rgba(0, 0, 0, 1);
        employLabel.font = HMFONTM(8);
        [self.scrollView addSubview:employLabel];
        [employLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(dateLabel.mas_bottom).offset(S_ScaleWidth(2));
            make.left.equalTo(dateLabel).offset(S_ScaleWidth(5));
            make.width.mas_equalTo(S_ScaleWidth(156));
        }];
        
        UILabel *jobTitleLabel = [[UILabel alloc] init];
        jobTitleLabel.text = experience.jobTitle;
        jobTitleLabel.textColor = rgba(0, 0, 0, 1);
        jobTitleLabel.font = FONTM(5);
        [self.scrollView addSubview:jobTitleLabel];
        [jobTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(employLabel.mas_bottom).offset(S_ScaleWidth(2));
            make.left.width.equalTo(employLabel);
        }];
        
        UILabel *cityLabel = [[UILabel alloc] init];
        cityLabel.text = experience.city;
        cityLabel.textColor = rgba(0, 0, 0, 1);
        cityLabel.font = FONTM(5);
        [self.scrollView addSubview:cityLabel];
        [cityLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(jobTitleLabel.mas_bottom).offset(S_ScaleWidth(2));
            make.left.width.equalTo(jobTitleLabel);
        }];
        
        UILabel *descLabel = [[UILabel alloc] init];
        descLabel.text = experience.jobDesc;
        descLabel.textColor = rgba(0, 0, 0, 1);
        descLabel.font = FONTR(5);
        descLabel.numberOfLines = 0;
        [self.scrollView addSubview:descLabel];
        [descLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(cityLabel.mas_bottom).offset(S_ScaleWidth(3));
            make.left.equalTo(cityLabel);
            make.width.mas_equalTo(S_ScaleWidth(167));
        }];
        
        lastWorkLabel = descLabel;
    }
    
    
    // Summary
    self.summaryTitleLabel.text = @"S u m m a r y";
    self.summaryTitleLabel.font = HMFONTM(10);
    [self.scrollView addSubview:self.summaryTitleLabel];
    [self.summaryTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(lastWorkLabel.mas_bottom).offset(S_ScaleWidth(15));
        make.left.equalTo(leftContainer.mas_right).offset(S_ScaleWidth(9));
    }];
    
    UIView *summaryLine = [[UIView alloc] init];
    summaryLine.backgroundColor = rgba(193, 208, 237, 1);
    summaryLine.layer.cornerRadius = 0.5;
    summaryLine.clipsToBounds = YES;
    [self.scrollView addSubview:summaryLine];
    [summaryLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.summaryTitleLabel.mas_bottom).offset(S_ScaleWidth(1));
        make.left.equalTo(self.summaryTitleLabel);
        make.width.mas_equalTo(S_ScaleWidth(169));
        make.height.mas_equalTo(1);
    }];
    
    self.summaryDescLabel.text = self.resume.summary.summary;
    [self.scrollView addSubview:self.summaryDescLabel];
    [self.summaryDescLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.summaryTitleLabel.mas_bottom).offset(S_ScaleWidth(5));
        make.left.equalTo(self.summaryTitleLabel);
        make.width.mas_equalTo(S_ScaleWidth(173));
    }];
    
    [leftContainer.superview layoutIfNeeded];
    
    [self.summaryDescLabel.superview layoutIfNeeded];
    
    if (leftContainer.bottom < self.summaryDescLabel.bottom) {
        
        if (self.summaryDescLabel.bottom > self.scrollView.bottom) {
            self.scrollView.contentSize = CGSizeMake(self.width, self.summaryDescLabel.bottom + S_ScaleWidth(12));
        }else {
            self.scrollView.contentSize = self.scrollView.bounds.size;
        }
    }else {
        if (leftContainer.bottom > self.scrollView.bottom) {
            self.scrollView.contentSize = CGSizeMake(self.width, leftContainer.bottom + S_ScaleWidth(12));
        }else {
            self.scrollView.contentSize = self.scrollView.bounds.size;
        }
    }
}

@end
