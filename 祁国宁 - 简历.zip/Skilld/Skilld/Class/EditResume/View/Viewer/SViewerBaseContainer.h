//
//  SViewerBaseContainer.h
//  Skilld
//
//  Created by Speed on 2022/11/24.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SViewerBaseContainer : UIView

@property (nonatomic, strong) UIScrollView *scrollView;

/// Basic Info

@property (nonatomic, strong) UILabel *userNameLabel;

@property (nonatomic, strong) UIImageView *phoneImageView;

@property (nonatomic, strong) UILabel *phoneLabel;

@property (nonatomic, strong) UIImageView *emailImageView;

@property (nonatomic, strong) UILabel *emailLabel;

@property (nonatomic, strong) UIImageView *blogImageView;

@property (nonatomic, strong) UILabel *blogLabel;

@property (nonatomic, strong) UIImageView *addressImageView;

@property (nonatomic, strong) UILabel *addressLabel;


/// Goal

@property (nonatomic, strong) UILabel *goalTitleLabel;

@property (nonatomic, strong) UILabel *goalJobLabel;

@property (nonatomic, strong) UILabel *goalContentLabel;


/// Work

@property (nonatomic, strong) UILabel *workTitleLabel;

@property (nonatomic, strong) UILabel *skillTitleLabel;

/// Education

@property (nonatomic, strong) UILabel *educationTitleLabel;


/// Summary

@property (nonatomic, strong) UILabel *summaryTitleLabel;

@property (nonatomic, strong) UILabel *summaryDescLabel;

@end

NS_ASSUME_NONNULL_END
