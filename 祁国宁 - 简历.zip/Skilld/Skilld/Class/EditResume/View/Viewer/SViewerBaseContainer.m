//
//  SViewerBaseContainer.m
//  Skilld
//
//  Created by Speed on 2022/11/24.
//

#import "SViewerBaseContainer.h"

@implementation SViewerBaseContainer

- (UIScrollView *)scrollView {
    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc] init];
        [_scrollView contentInsetScrollView];
    }
    return _scrollView;
}

- (UILabel *)userNameLabel {
    if (!_userNameLabel) {
        _userNameLabel = [[UILabel alloc] init];
        _userNameLabel.textColor = rgba(0, 0, 0, 1);
        _userNameLabel.numberOfLines = 0;
    }
    return _userNameLabel;
}

- (UIImageView *)phoneImageView {
    if (!_phoneImageView) {
        _phoneImageView = [[UIImageView alloc] init];
        _phoneImageView.image = [UIImage imageNamed:@"viewer_phone"];
    }
    return _phoneImageView;
}

- (UILabel *)phoneLabel {
    if (!_phoneLabel) {
        _phoneLabel = [[UILabel alloc] init];
        _phoneLabel.textColor = rgba(79, 83, 83, 1);
        _phoneLabel.font = FONTR(5);
    }
    return _phoneLabel;
}

- (UIImageView *)emailImageView {
    if (!_emailImageView) {
        _emailImageView = [[UIImageView alloc] init];
        _emailImageView.image = [UIImage imageNamed:@"viewer_email"];
    }
    return _emailImageView;
}

- (UILabel *)emailLabel {
    if (!_emailLabel) {
        _emailLabel = [[UILabel alloc] init];
        _emailLabel.textColor = rgba(79, 83, 83, 1);
        _emailLabel.font = FONTR(5);
    }
    return _emailLabel;
}

- (UIImageView *)blogImageView {
    if (!_blogImageView) {
        _blogImageView = [[UIImageView alloc] init];
        _blogImageView.image = [UIImage imageNamed:@"viewer_blogs"];
    }
    return _blogImageView;
}

- (UILabel *)blogLabel {
    if (!_blogLabel) {
        _blogLabel = [[UILabel alloc] init];
        _blogLabel.textColor = rgba(79, 83, 83, 1);
        _blogLabel.font = FONTR(5);
    }
    return _blogLabel;
}

- (UIImageView *)addressImageView {
    if (!_addressImageView) {
        _addressImageView = [[UIImageView alloc] init];
        _addressImageView.image = [UIImage imageNamed:@"viewer_address"];
    }
    return _addressImageView;
}

- (UILabel *)addressLabel {
    if (!_addressLabel) {
        _addressLabel = [[UILabel alloc] init];
        _addressLabel.textColor = rgba(79, 83, 83, 1);
        _addressLabel.font = FONTR(5);
        _addressLabel.numberOfLines = 0;
    }
    return _addressLabel;
}

- (UILabel *)goalTitleLabel {
    if (!_goalTitleLabel) {
        _goalTitleLabel = [[UILabel alloc] init];
        _goalTitleLabel.text = @"Goal";
        _goalTitleLabel.textColor = rgba(0, 0, 0, 1);
        _goalTitleLabel.font = HMFONTBLACK(10);
    }
    return _goalTitleLabel;
}

- (UILabel *)goalJobLabel {
    if (!_goalJobLabel) {
        _goalJobLabel = [[UILabel alloc] init];
        _goalJobLabel.textColor = rgba(0, 0, 0, 1);
        _goalJobLabel.font = FONTB(8);
    }
    return _goalJobLabel;
}

- (UILabel *)goalContentLabel {
    if (!_goalContentLabel) {
        _goalContentLabel = [[UILabel alloc] init];
        _goalContentLabel.textColor = rgba(79, 83, 83, 1);
        _goalContentLabel.font = FONTR(5);
        _goalContentLabel.numberOfLines = 0;
    }
    return _goalContentLabel;
}

- (UILabel *)workTitleLabel {
    if (!_workTitleLabel) {
        _workTitleLabel = [[UILabel alloc] init];
        _workTitleLabel.text = @"Work experience";
        _workTitleLabel.textColor = rgba(0, 0, 0, 1);
        _workTitleLabel.font = HMFONTBLACK(10);
    }
    return _workTitleLabel;
}

- (UILabel *)skillTitleLabel {
    if (!_skillTitleLabel) {
        _skillTitleLabel = [[UILabel alloc] init];
        _skillTitleLabel.text = @"Skills";
        _skillTitleLabel.textColor = rgba(0, 0, 0, 1);
        _skillTitleLabel.font = HMFONTBLACK(10);
    }
    return _skillTitleLabel;
}

- (UILabel *)educationTitleLabel {
    if (!_educationTitleLabel) {
        _educationTitleLabel = [[UILabel alloc] init];
        _educationTitleLabel.text = @"Education";
        _educationTitleLabel.textColor = rgba(0, 0, 0, 1);
        _educationTitleLabel.font = HMFONTBLACK(10);
    }
    return _educationTitleLabel;
}

- (UILabel *)summaryTitleLabel {
    if (!_summaryTitleLabel) {
        _summaryTitleLabel = [[UILabel alloc] init];
        _summaryTitleLabel.text = @"Summary";
        _summaryTitleLabel.textColor = rgba(0, 0, 0, 1);
        _summaryTitleLabel.font = HMFONTBLACK(10);
    }
    return _summaryTitleLabel;
}

- (UILabel *)summaryDescLabel {
    if (!_summaryDescLabel) {
        _summaryDescLabel = [[UILabel alloc] init];
        _summaryDescLabel.textColor = rgba(79, 83, 83, 1);
        _summaryDescLabel.font = FONTR(5);
        _summaryDescLabel.numberOfLines = 0;
    }
    return _summaryDescLabel;
}

@end
