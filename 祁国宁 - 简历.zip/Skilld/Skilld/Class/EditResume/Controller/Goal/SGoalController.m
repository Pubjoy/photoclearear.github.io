//
//  SGoalController.m
//  Skilld
//
//  Created by Speed on 2022/11/19.
//

#import "SGoalController.h"

@interface SGoalController () <UITextViewDelegate>

@property (nonatomic, weak) SResumeField *jobField;
@property (nonatomic, weak) UIView *shadowContainer;
@property (nonatomic, weak) CMTextView *textView;

@end

@implementation SGoalController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    if (!self.resumeModel.goal) {
        SResumeGoalModel *goal = [[SResumeGoalModel alloc] init];
        self.resumeModel.goal = goal;
    }
    
    [self initView];
}

- (void)initView {
    
    CGFloat margin_20 = S_ScaleWidth(20);
    CGFloat margin_12 = S_ScaleWidth(12);
        
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    [scrollView contentInsetScrollView];
    
    [self.view addSubview:scrollView];

    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.text = @"Your target job";
    titleLabel.textColor = rgba(20, 23, 34, 1);
    titleLabel.font = HMFONTB(18);
    [scrollView addSubview:titleLabel];
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.mas_equalTo(margin_20);
    }];
    
    CGFloat fieldWidth = S_ScaleWidth(335);
    CGFloat fieldHeight = S_ScaleWidth(48);
    
    SResumeField *jobField = [[SResumeField alloc] initWithFrame:CGRectMake(margin_20, S_ScaleWidth(65), fieldWidth, fieldHeight)];
    self.jobField = jobField;
    jobField.text = self.resumeModel.goal.jobPosition;
    jobField.placeholder = @"Your target position";
    jobField.delegate = self;
    jobField.maxTextLength = 20;
    [scrollView addSubview:jobField];
    
    UIView *shadowContainer = [[UIView alloc] initWithFrame:CGRectMake(margin_20, jobField.bottom + margin_12, jobField.width, S_ScaleWidth(120))];
    self.shadowContainer = shadowContainer;
    shadowContainer.backgroundColor = rgba(239, 245, 249, 1);
    shadowContainer.layer.borderColor = [UIColor clearColor].CGColor;
    shadowContainer.layer.borderWidth = 0.5;
    shadowContainer.layer.cornerRadius = S_ScaleWidth(10);
    shadowContainer.layer.shadowColor = [UIColor clearColor].CGColor;
    shadowContainer.layer.shadowOffset = CGSizeMake(0, 2);
    shadowContainer.layer.shadowRadius = 3;
    shadowContainer.layer.shadowOpacity = 1;
    [scrollView addSubview:shadowContainer];

    CMTextView *textView = [CMTextView textView];
    self.textView = textView;
    textView.text = self.resumeModel.goal.content;
    textView.frame = CGRectMake(margin_20, jobField.bottom + margin_12, jobField.width, S_ScaleWidth(120));
    textView.backgroundColor = [UIColor clearColor];
    textView.placeholder = @"Content";
    textView.font = FONTR(15);
    textView.textColor = rgba(20, 23, 34, 1);
    textView.delegate = self;
    textView.maxLength = 500;
    textView.enablesReturnKeyAutomatically = YES;
    [scrollView addSubview:textView];

    scrollView.contentSize = CGSizeMake(S_Screen_W, textView.bottom + margin_20 + S_SafeAreaBottomHeight);
    
    SResumeGoalModel *goal = [[SResumeGoalModel alloc] init];
    
    self.resumeModel.goal = goal;
    
    __weak typeof(self) weakSelf = self;

    [jobField setCmTextFieldEndEditBlock:^(CMTextField * _Nonnull tf) {
        weakSelf.resumeModel.goal.jobPosition = tf.text;
    }];
    
    [textView addTextDidChangeHandler:^(CMTextView * _Nonnull textView) {
            
        weakSelf.resumeModel.goal.content = textView.text;
    }];
}


#pragma mark - <UITextViewDelegate>
- (void)textViewDidBeginEditing:(CMTextView *)textView {
    self.shadowContainer.layer.borderColor = rgba(219, 226, 255, 1).CGColor;
    self.shadowContainer.layer.shadowColor = rgba(56, 94, 239, 0.30).CGColor;
}

- (void)textViewDidEndEditing:(CMTextView *)textView {
    self.shadowContainer.layer.borderColor = [UIColor clearColor].CGColor;
    self.shadowContainer.layer.shadowColor = [UIColor clearColor].CGColor;

}

@end
