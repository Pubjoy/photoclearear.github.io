//
//  SWorkExperienceController.h
//  Skilld
//
//  Created by Speed on 2022/11/19.
//

#import "SResumeEditBaseController.h"

NS_ASSUME_NONNULL_BEGIN

@interface SWorkExperienceController : SResumeEditBaseController

@property (nonatomic, strong) SResumeExperienceModel *experience;

@property (nonatomic, copy) void(^addWorkExperienceBlock)(SResumeExperienceModel *experience);


@end

NS_ASSUME_NONNULL_END
