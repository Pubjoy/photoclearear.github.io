//
//  SWorkExperienceController.m
//  Skilld
//
//  Created by Speed on 2022/11/19.
//

#import "SWorkExperienceController.h"

#define backViewHeight (S_ScaleWidth(527) + S_SafeAreaBottomHeight)
@interface SWorkExperienceController () <UITextViewDelegate>
@property (nonatomic, weak) UIView *backView;
@property (nonatomic, weak) SResumeField *employField;
@property (nonatomic, weak) SResumeField *jobTitleField;
@property (nonatomic, weak) SResumeField *cityField;
@property (nonatomic, weak) SResumeField *startDateField;
@property (nonatomic, weak) SResumeField *endDateField;
@property (nonatomic, weak) UIView *shadowContainer;
@property (nonatomic, weak) CMTextView *textView;

@end

@implementation SWorkExperienceController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self initView];
}

- (void)initView {
    
    self.view.backgroundColor = rgba(0, 0, 0, 0.70);
    [self.view cornerByRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight cornerRadius:0];

        
    CGFloat margin_20 = S_ScaleWidth(20);
    CGFloat margin_12 = S_ScaleWidth(12);
    CGFloat fieldWidth = S_ScaleWidth(335);
    CGFloat fieldHeight = S_ScaleWidth(48);
    
    UIView *dismissView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, S_Screen_W, self.view.height - backViewHeight)];
    dismissView.backgroundColor = [UIColor clearColor];
    [dismissView addTouchUpInsideTarget:self action:@selector(dismissAnimation)];
    [self.view addSubview:dismissView];
        
    UIView *backView = [[UIView alloc] initWithFrame:CGRectMake(0, self.view.height, S_Screen_W, backViewHeight)];
    self.backView = backView;
    [backView cornerByRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight cornerRadius:S_ScaleWidth(20)];
    backView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:backView];

    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:backView.bounds];
    [scrollView contentInsetScrollView];
    [backView addSubview:scrollView];

    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(margin_20, S_ScaleWidth(38), self.view.width - margin_20 * 2, S_ScaleWidth(24))];
    titleLabel.text = @"Experience";
    titleLabel.textColor = rgba(20, 23, 34, 1);
    titleLabel.font = HMFONTB(18);
    [titleLabel sizeToFit];
    [scrollView addSubview:titleLabel];
    
    
    SResumeField *employField = [[SResumeField alloc] initWithFrame:CGRectMake(margin_20, S_ScaleWidth(65), fieldWidth, fieldHeight)];
    self.employField = employField;
    employField.placeholder = @"Employ";
    employField.delegate = self;
    employField.maxTextLength = 20;
    employField.text = self.experience.employ;
    [scrollView addSubview:employField];
    
    SResumeField *jobTitleField = [[SResumeField alloc] initWithFrame:CGRectMake(margin_20, employField.bottom + margin_12, fieldWidth, fieldHeight)];
    self.jobTitleField = jobTitleField;
    jobTitleField.placeholder = @"Job Title";
    jobTitleField.delegate = self;
    jobTitleField.maxTextLength = 20;
    jobTitleField.text = self.experience.jobTitle;
    [scrollView addSubview:jobTitleField];

    SResumeField *cityField = [[SResumeField alloc] initWithFrame:CGRectMake(margin_20, jobTitleField.bottom + margin_12, fieldWidth, fieldHeight)];
    self.cityField = cityField;
    cityField.placeholder = @"City";
    cityField.delegate = self;
    cityField.maxTextLength = 20;
    cityField.text = self.experience.city;
    [scrollView addSubview:cityField];
    
    __weak typeof(self) weakSelf = self;
    SDatePickerContainer *startDatePicker = [[SDatePickerContainer alloc] initWithFrame:CGRectMake(0, 0, S_Screen_W, S_ScaleWidth(180) + S_SafeAreaBottomHeight) chooseBlock:^(NSString * _Nonnull dateStr) {
        weakSelf.startDateField.text = dateStr;
    }];
    
    SResumeField *startDateField = [[SResumeField alloc] initWithFrame:CGRectMake(margin_20, cityField.bottom + margin_12, fieldWidth, fieldHeight)];
    self.startDateField = startDateField;
    startDateField.placeholder = @"Start Date";
    startDateField.delegate = self;
    startDateField.text = self.experience.startDate;
    startDateField.inputView = startDatePicker;
    [scrollView addSubview:startDateField];
    
    SDatePickerContainer *endDatePicker = [[SDatePickerContainer alloc] initWithFrame:CGRectMake(0, 0, S_Screen_W, S_ScaleWidth(180) + S_SafeAreaBottomHeight) chooseBlock:^(NSString * _Nonnull dateStr) {
        weakSelf.endDateField.text = dateStr;
    }];
    
    SResumeField *endDateField = [[SResumeField alloc] initWithFrame:CGRectMake(margin_20, startDateField.bottom + margin_12, fieldWidth, fieldHeight)];
    self.endDateField = endDateField;
    endDateField.placeholder = @"End Date";
    endDateField.delegate = self;
    endDateField.text = self.experience.endDate;
    endDateField.inputView = endDatePicker;
    [scrollView addSubview:endDateField];
    
    UIView *shadowContainer = [[UIView alloc] initWithFrame:CGRectMake(margin_20, endDateField.bottom + margin_12, fieldWidth, S_ScaleWidth(80))];
    self.shadowContainer = shadowContainer;
    shadowContainer.backgroundColor = rgba(239, 245, 249, 1);
    shadowContainer.layer.borderColor = [UIColor clearColor].CGColor;
    shadowContainer.layer.borderWidth = 0.5;
    shadowContainer.layer.cornerRadius = S_ScaleWidth(10);
    shadowContainer.layer.shadowColor = [UIColor clearColor].CGColor;
    shadowContainer.layer.shadowOffset = CGSizeMake(0, 2);
    shadowContainer.layer.shadowRadius = 3;
    shadowContainer.layer.shadowOpacity = 1;
    [scrollView addSubview:shadowContainer];

    CMTextView *textView = [CMTextView textView];
    self.textView = textView;
    textView.frame = shadowContainer.bounds;
    textView.backgroundColor = [UIColor clearColor];
    textView.placeholder = @"Job descriptionchool";
    textView.font = FONTR(15);
    textView.textColor = rgba(20, 23, 34, 1);
    textView.delegate = self;
    textView.enablesReturnKeyAutomatically = YES;
    textView.maxLength = 500;
    textView.text = self.experience.jobDesc;
    [shadowContainer addSubview:textView];
    
    UIButton *saveBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    saveBtn.frame = CGRectMake(margin_20, shadowContainer.bottom + margin_20, fieldWidth, fieldHeight);
    [saveBtn setTitle:@"Save" forState:UIControlStateNormal];
    [saveBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [saveBtn setBackgroundColor:rgba(56, 94, 239, 1)];
    saveBtn.layer.cornerRadius = S_ScaleWidth(24);
    [saveBtn addTarget:self action:@selector(saveClick) forControlEvents:UIControlEventTouchUpInside];
    [scrollView addSubview:saveBtn];
    
    scrollView.contentSize = CGSizeMake(S_Screen_W, saveBtn.bottom + margin_20 + S_SafeAreaBottomHeight);
    
    [self showAnimatoin];

}

- (void)showAnimatoin {
    
    [UIView animateWithDuration:0.3 animations:^{
        self.backView.frame = CGRectMake(0, self.view.height - backViewHeight, S_Screen_W, backViewHeight);
    }];
}

- (void)dismissAnimation {
    
    [self.view endEditing:YES];
    
    [UIView animateWithDuration:0.25 animations:^{
        self.backView.frame = CGRectMake(0, self.view.height, S_Screen_W, backViewHeight);
        self.view.backgroundColor = rgba(0, 0, 0, 0);
    } completion:^(BOOL finished) {
        [self dismissViewControllerAnimated:NO completion:nil];
    }];
}

- (void)saveClick {
    
    SResumeExperienceModel *experience = [SResumeExperienceModel new];
    experience.employ = self.employField.text;
    experience.jobTitle = self.jobTitleField.text;
    experience.city = self.cityField.text;
    experience.startDate = self.startDateField.text;
    experience.endDate = self.endDateField.text;
    experience.jobDesc = self.textView.text;
        
    if (self.addWorkExperienceBlock) {
        self.addWorkExperienceBlock(experience);
    }
    
    [self dismissAnimation];
}

#pragma mark - <UITextViewDelegate>
- (void)textViewDidBeginEditing:(CMTextView *)textView {
    self.shadowContainer.layer.borderColor = rgba(219, 226, 255, 1).CGColor;
    self.shadowContainer.layer.shadowColor = rgba(56, 94, 239, 0.30).CGColor;
}

- (void)textViewDidEndEditing:(CMTextView *)textView {
    self.shadowContainer.layer.borderColor = [UIColor clearColor].CGColor;
    self.shadowContainer.layer.shadowColor = [UIColor clearColor].CGColor;
}

@end
