//
//  SWorkController.m
//  Skilld
//
//  Created by Speed on 2022/11/19.
//

#import "SWorkController.h"
#import "SWorkExperienceCell.h"
#import "SWorkExperienceController.h"
#import "SResumeDeleteContainer.h"

@interface SWorkController () <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, weak) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *works;

@end

@implementation SWorkController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    if (self.resumeModel.works) {
        [self.works addObjectsFromArray:self.resumeModel.works];
    }
    
    [self initView];
}

- (void)initView {
    
    
    CGFloat margin_20 = S_ScaleWidth(20);
    
    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.text = @"Your work experience";
    titleLabel.textColor = rgba(20, 23, 34, 1);
    titleLabel.font = HMFONTB(18);
    [self.view addSubview:titleLabel];
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.mas_equalTo(margin_20);
    }];
    

    UIView *tableFooterView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, S_Screen_W, S_ScaleWidth(88))];
    
    UIButton *addWorkBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [addWorkBtn setImage:[UIImage imageNamed:@"add"] forState:UIControlStateNormal];
    [addWorkBtn addTarget:self action:@selector(addWorkExperience) forControlEvents:UIControlEventTouchUpInside];
    [tableFooterView addSubview:addWorkBtn];
    [addWorkBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_ScaleWidth(20));
        make.centerX.mas_equalTo(0);
        make.width.mas_equalTo(S_ScaleWidth(150));
        make.height.mas_equalTo(S_ScaleWidth(48));
    }];
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    self.tableView = tableView;
    [tableView contentInsetScrollView];
    tableView.backgroundColor = [UIColor clearColor];
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.showsVerticalScrollIndicator = NO;
    tableView.showsHorizontalScrollIndicator = NO;
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    tableView.tableFooterView = tableFooterView;
    [tableView registerClass:[SWorkExperienceCell class] forCellReuseIdentifier:NSStringFromClass([SWorkExperienceCell class])];
    [self.view addSubview:tableView];
    [tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_ScaleWidth(65));
        make.left.right.bottom.mas_equalTo(0);
    }];
    
}

#pragma mark - <UITableViewDelegate, UITableViewDataSource>
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.works.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    SWorkExperienceCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([SWorkExperienceCell class]) forIndexPath:indexPath];
    
    cell.index = indexPath.row + 1;
    
    cell.experience = self.works[indexPath.row];
    
    
    __weak typeof(self) weakSelf = self;
    [cell setDeleteBlock:^{
        [weakSelf deleteWorkExperienceAtIndex:indexPath.row];
    }];
    
    [cell setEditBlock:^{
        [weakSelf editWorkExperienceAtIndex:indexPath.row];
    }];
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    SResumeExperienceModel *model = self.works[indexPath.row];
    return model.cellHeight;
}

- (void)deleteWorkExperienceAtIndex:(NSInteger)index {
    
    SResumeDeleteContainer *container = [[SResumeDeleteContainer alloc] initWithFrame:CGRectMake(0, 0, S_ScaleWidth(290), S_ScaleWidth(160)) title:@"Delete prompt" message:@"Are you sure delete it?"];

    LSTPopView *popView = [LSTPopView initWithCustomView:container parentView:[SRoute getCurrentVC].view popStyle:LSTPopStyleFade dismissStyle:LSTDismissStyleFade];
        
    __weak typeof(popView) weakPopView = popView;

    [container setDismissBlock:^{
        [weakPopView dismiss];
    }];
    
    __weak typeof(self) weakSelf = self;
    [container setDeleteBlock:^{
        [weakSelf.works removeObjectAtIndex:index];
        weakSelf.resumeModel.works = weakSelf.works;
        [weakSelf.tableView reloadData];
        [weakPopView dismiss];
    }];
    
    popView.hemStyle = LSTHemStyleCenter;
    popView.bgAlpha = 0.5;
    popView.popDuration = 0.3;
    popView.dismissDuration = 0.25;
    [popView pop];
}

- (void)editWorkExperienceAtIndex:(NSInteger)index {
    
    SWorkExperienceController *vc = [[SWorkExperienceController alloc] init];
    vc.experience = self.works[index];
    vc.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    [self presentViewController:vc animated:NO completion:nil];
    
    __weak typeof(self) weakSelf = self;
    [vc setAddWorkExperienceBlock:^(SResumeExperienceModel * _Nonnull experience) {
        [weakSelf.works replaceObjectAtIndex:index withObject:experience];
        weakSelf.resumeModel.works = weakSelf.works;
        [weakSelf.tableView reloadData];
    }];
}


- (void)addWorkExperience {
    
    SWorkExperienceController *vc = [[SWorkExperienceController alloc] init];
    vc.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    [self presentViewController:vc animated:NO completion:nil];

    __weak typeof(self) weakSelf = self;
    [vc setAddWorkExperienceBlock:^(SResumeExperienceModel * _Nonnull experience) {
        [weakSelf.works addObject:experience];
        weakSelf.resumeModel.works = weakSelf.works;
        [weakSelf.tableView reloadData];
    }];
}

- (NSMutableArray *)works {
    if (!_works) {
        _works = [[NSMutableArray alloc] init];
    }
    return _works;
}


@end
