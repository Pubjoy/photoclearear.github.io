//
//  SAddSkillController.m
//  Skilld
//
//  Created by Speed on 2022/11/20.
//

#import "SAddSkillController.h"

#define backViewHeight (S_ScaleWidth(357) + S_SafeAreaBottomHeight)

@interface SAddSkillController ()
@property (nonatomic, weak) UIView *backView;
@property (nonatomic, weak) SResumeField *skillField;
@end

@implementation SAddSkillController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self initView];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showKeyboard:) name:UIKeyboardWillShowNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(hideKeyboard:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)showKeyboard:(NSNotification *)notification {
    
    NSTimeInterval duration = [notification.userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    //键盘弹出的动画效果
    UIViewAnimationOptions option = [notification.userInfo[UIKeyboardAnimationCurveUserInfoKey] intValue];
    //键盘弹出后的位置
    CGRect endFrame = [notification.userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    
    [UIView animateWithDuration:duration delay:0 options:option animations:^{
        
        self.backView.top = endFrame.origin.y - (self.skillField.bottom + S_ScaleWidth(10));

    } completion:^(BOOL finished) {
    }];
}

- (void)hideKeyboard:(NSNotification *)notification {

    [UIView animateWithDuration:0.2 animations:^{
        self.backView.bottom = self.view.bottom;
    }];
}

- (void)initView {
    
    self.view.backgroundColor = rgba(0, 0, 0, 0.70);
    [self.view cornerByRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight cornerRadius:0];
        
    CGFloat margin_20 = S_ScaleWidth(20);
    CGFloat fieldWidth = S_ScaleWidth(335);
    CGFloat fieldHeight = S_ScaleWidth(48);
        
    UIView *dismissView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, S_Screen_W, self.view.height - backViewHeight)];
    dismissView.backgroundColor = [UIColor clearColor];
    [dismissView addTouchUpInsideTarget:self action:@selector(dismissAnimation)];
    [self.view addSubview:dismissView];
    
    UIView *backView = [[UIView alloc] initWithFrame:CGRectMake(0, self.view.height, S_Screen_W, backViewHeight)];
    self.backView = backView;
    [backView cornerByRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight cornerRadius:S_ScaleWidth(20)];
    backView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:backView];
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(margin_20, S_ScaleWidth(38), self.view.width - margin_20 * 2, S_ScaleWidth(24))];
    titleLabel.text = @"Skill";
    titleLabel.textColor = rgba(20, 23, 34, 1);
    titleLabel.font = FONTB(16);
    [titleLabel sizeToFit];
    [backView addSubview:titleLabel];
    
    SResumeField *skillField = [[SResumeField alloc] initWithFrame:CGRectMake(margin_20, S_ScaleWidth(65), fieldWidth, fieldHeight)];
    self.skillField = skillField;
    skillField.placeholder = @"Employ";
    skillField.delegate = self;
    skillField.maxTextLength = 50;
    skillField.text = self.skill.skill;
    [backView addSubview:skillField];
    
    UIButton *saveBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    saveBtn.frame = CGRectMake(margin_20, skillField.bottom + S_ScaleWidth(182), fieldWidth, fieldHeight);
    [saveBtn setTitle:@"Save" forState:UIControlStateNormal];
    [saveBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [saveBtn setBackgroundColor:rgba(56, 94, 239, 1)];
    saveBtn.layer.cornerRadius = S_ScaleWidth(24);
    [saveBtn addTarget:self action:@selector(saveClick) forControlEvents:UIControlEventTouchUpInside];
    [backView addSubview:saveBtn];
    
    [self showAnimatoin];
}

- (void)showAnimatoin {
    
    [UIView animateWithDuration:0.3 animations:^{
        self.backView.frame = CGRectMake(0, self.view.height - backViewHeight, S_Screen_W, backViewHeight);
    }];
}

- (void)dismissAnimation {
    
    [self.skillField resignFirstResponder];
    
    [UIView animateWithDuration:0.25 animations:^{
        self.backView.frame = CGRectMake(0, self.view.height, S_Screen_W, backViewHeight);
        self.view.backgroundColor = rgba(0, 0, 0, 0);
    } completion:^(BOOL finished) {
        [self dismissViewControllerAnimated:NO completion:nil];
    }];
}

- (void)saveClick {
    
    SResumeSkillsModel *skill = [SResumeSkillsModel new];
    skill.skill = self.skillField.text;
    
    if (self.addSkillBlock) {
        self.addSkillBlock(skill);
    }
    
    [self dismissAnimation];
}


@end
