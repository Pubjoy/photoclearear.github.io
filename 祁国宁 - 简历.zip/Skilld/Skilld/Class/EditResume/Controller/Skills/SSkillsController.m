//
//  SSkillsController.m
//  Skilld
//
//  Created by Speed on 2022/11/19.
//

#import "SSkillsController.h"
#import "SSkillsCell.h"
#import "SAddSkillController.h"
#import "SResumeDeleteContainer.h"

@interface SSkillsController () <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, weak) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *skills;

@end

@implementation SSkillsController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    if (self.resumeModel.works) {
        [self.skills addObjectsFromArray:self.resumeModel.skills];
    }
    
    [self initView];
}

- (void)initView {
    
    CGFloat margin_20 = S_ScaleWidth(20);
        
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    [scrollView contentInsetScrollView];
    
    [self.view addSubview:scrollView];

    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.text = @"What other skills do you have?";
    titleLabel.textColor = rgba(20, 23, 34, 1);
    titleLabel.font = HMFONTB(18);
    [scrollView addSubview:titleLabel];
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.mas_equalTo(margin_20);
    }];
    
    UIView *tableFooterView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, S_Screen_W, S_ScaleWidth(88))];
    
    UIButton *addSkillBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [addSkillBtn setImage:[UIImage imageNamed:@"add"] forState:UIControlStateNormal];
    [addSkillBtn addTarget:self action:@selector(addSkill) forControlEvents:UIControlEventTouchUpInside];
    [tableFooterView addSubview:addSkillBtn];
    [addSkillBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_ScaleWidth(20));
        make.centerX.mas_equalTo(0);
        make.width.mas_equalTo(S_ScaleWidth(150));
        make.height.mas_equalTo(S_ScaleWidth(48));
    }];
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    self.tableView = tableView;
    [tableView contentInsetScrollView];
    tableView.backgroundColor = [UIColor clearColor];
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.showsVerticalScrollIndicator = NO;
    tableView.showsHorizontalScrollIndicator = NO;
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    tableView.tableFooterView = tableFooterView;
    [tableView registerClass:[SSkillsCell class] forCellReuseIdentifier:NSStringFromClass([SSkillsCell class])];
    [self.view addSubview:tableView];
    [tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_ScaleWidth(50));
        make.left.right.bottom.mas_equalTo(0);
    }];
}

#pragma mark - <UITableViewDelegate, UITableViewDataSource>
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.skills.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    SSkillsCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([SSkillsCell class]) forIndexPath:indexPath];
    
    cell.index = indexPath.row + 1;
    
    cell.skill = self.skills[indexPath.row];
    
    __weak typeof(self) weakSelf = self;
    [cell setDeleteBlock:^{
        [weakSelf deleteSkillAtIndex:indexPath.row];
    }];
    
    [cell setEditBlock:^{
        [weakSelf editSkillAtIndex:indexPath.row];
    }];

    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return S_ScaleWidth(118);
}

- (void)deleteSkillAtIndex:(NSInteger)index {
    
    SResumeDeleteContainer *container = [[SResumeDeleteContainer alloc] initWithFrame:CGRectMake(0, 0, S_ScaleWidth(290), S_ScaleWidth(160)) title:@"Delete prompt" message:@"Are you sure delete it?"];
    
    LSTPopView *popView = [LSTPopView initWithCustomView:container parentView:[SRoute getCurrentVC].view popStyle:LSTPopStyleFade dismissStyle:LSTDismissStyleFade];
        
    __weak typeof(popView) weakPopView = popView;

    [container setDismissBlock:^{
        [weakPopView dismiss];
    }];
    
    __weak typeof(self) weakSelf = self;
    [container setDeleteBlock:^{
        [weakSelf.skills removeObjectAtIndex:index];
        weakSelf.resumeModel.skills = weakSelf.skills;
        [weakSelf.tableView reloadData];
        [weakPopView dismiss];
    }];
    
    popView.hemStyle = LSTHemStyleCenter;
    popView.bgAlpha = 0.5;
    popView.popDuration = 0.3;
    popView.dismissDuration = 0.25;
    [popView pop];
}

- (void)editSkillAtIndex:(NSInteger)index {
    
    SAddSkillController *vc = [[SAddSkillController alloc] init];
    vc.skill = self.skills[index];
    vc.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    [self presentViewController:vc animated:NO completion:nil];
    
    __weak typeof(self) weakSelf = self;
    [vc setAddSkillBlock:^(SResumeSkillsModel * _Nonnull skill) {
        [weakSelf.skills replaceObjectAtIndex:index withObject:skill];
        weakSelf.resumeModel.skills = weakSelf.skills;
        [weakSelf.tableView reloadData];
    }];
}


- (void)addSkill {
    
    SAddSkillController *vc = [[SAddSkillController alloc] init];
    vc.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    [self presentViewController:vc animated:NO completion:nil];

    __weak typeof(self) weakSelf = self;
    [vc setAddSkillBlock:^(SResumeSkillsModel * _Nonnull skill) {
        [weakSelf.skills addObject:skill];
        weakSelf.resumeModel.skills = weakSelf.skills;
        [weakSelf.tableView reloadData];
    }];

}

- (NSMutableArray *)skills {
    if (!_skills) {
        _skills = [[NSMutableArray alloc] init];
    }
    return _skills;
}

@end
