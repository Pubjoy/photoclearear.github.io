//
//  SAddSkillController.h
//  Skilld
//
//  Created by Speed on 2022/11/20.
//

#import "SResumeEditBaseController.h"

NS_ASSUME_NONNULL_BEGIN

@interface SAddSkillController : SResumeEditBaseController
@property (nonatomic, strong) SResumeSkillsModel *skill;

@property (nonatomic, copy) void(^addSkillBlock)(SResumeSkillsModel *skill);
@end

NS_ASSUME_NONNULL_END
