//
//  SEducationController.h
//  Skilld
//
//  Created by Speed on 2022/11/21.
//

#import "SResumeEditBaseController.h"

NS_ASSUME_NONNULL_BEGIN

@interface SEducationController : SResumeEditBaseController

@end

NS_ASSUME_NONNULL_END
