//
//  SAddEducationController.h
//  Skilld
//
//  Created by Speed on 2022/11/21.
//

#import "SResumeEditBaseController.h"

NS_ASSUME_NONNULL_BEGIN

@interface SAddEducationController : SResumeEditBaseController

@property (nonatomic, strong) SResumeEducationModel *education;

@property (nonatomic, copy) void(^addEducationBlock)(SResumeEducationModel *education);

@end

NS_ASSUME_NONNULL_END
