//
//  SAddEducationController.m
//  Skilld
//
//  Created by Speed on 2022/11/21.
//

#import "SAddEducationController.h"

#define backViewHeight (S_ScaleWidth(527) + S_SafeAreaBottomHeight)

@interface SAddEducationController ()
@property (nonatomic, weak) UIView *backView;
@property (nonatomic, weak) SResumeField *schoolField;
@property (nonatomic, weak) SResumeField *majorField;
@property (nonatomic, weak) SResumeField *startDateField;
@property (nonatomic, weak) SResumeField *endDateField;
@property (nonatomic, weak) UISwitch *stillSwitch;

@end

@implementation SAddEducationController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self initView];
}

- (void)initView {
    
    self.view.backgroundColor = rgba(0, 0, 0, 0.70);
    [self.view cornerByRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight cornerRadius:0];

    CGFloat margin_20 = S_ScaleWidth(20);
    CGFloat margin_12 = S_ScaleWidth(12);
    CGFloat fieldWidth = S_ScaleWidth(335);
    CGFloat fieldHeight = S_ScaleWidth(48);
    
    UIView *dismissView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, S_Screen_W, self.view.height - backViewHeight)];
    dismissView.backgroundColor = [UIColor clearColor];
    [dismissView addTouchUpInsideTarget:self action:@selector(dismissAnimation)];
    [self.view addSubview:dismissView];
        
    UIView *backView = [[UIView alloc] initWithFrame:CGRectMake(0, self.view.height, S_Screen_W, backViewHeight)];
    self.backView = backView;
    [backView cornerByRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight cornerRadius:S_ScaleWidth(20)];
    backView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:backView];

    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:backView.bounds];
    [scrollView contentInsetScrollView];
    [backView addSubview:scrollView];

    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(margin_20, S_ScaleWidth(38), self.view.width - margin_20 * 2, S_ScaleWidth(24))];
    titleLabel.text = @"Education experience";
    titleLabel.textColor = rgba(20, 23, 34, 1);
    titleLabel.font = FONTB(16);
    [titleLabel sizeToFit];
    [scrollView addSubview:titleLabel];
    
    
    SResumeField *schoolField = [[SResumeField alloc] initWithFrame:CGRectMake(margin_20, S_ScaleWidth(65), fieldWidth, fieldHeight)];
    self.schoolField = schoolField;
    schoolField.placeholder = @"School";
    schoolField.delegate = self;
    schoolField.maxTextLength = 50;
    schoolField.text = self.education.school;
    [scrollView addSubview:schoolField];
    
    SResumeField *majorField = [[SResumeField alloc] initWithFrame:CGRectMake(margin_20, schoolField.bottom + margin_12, fieldWidth, fieldHeight)];
    self.majorField = majorField;
    majorField.placeholder = @"Your major/degree";
    majorField.delegate = self;
    majorField.maxTextLength = 50;
    majorField.text = self.education.major;
    [scrollView addSubview:majorField];
    
    __weak typeof(self) weakSelf = self;
    SDatePickerContainer *startDatePicker = [[SDatePickerContainer alloc] initWithFrame:CGRectMake(0, 0, S_Screen_W, S_ScaleWidth(180) + S_SafeAreaBottomHeight) chooseBlock:^(NSString * _Nonnull dateStr) {
        weakSelf.startDateField.text = dateStr;
    }];
    
    SResumeField *startDateField = [[SResumeField alloc] initWithFrame:CGRectMake(margin_20, majorField.bottom + margin_12, fieldWidth, fieldHeight)];
    self.startDateField = startDateField;
    startDateField.placeholder = @"Start time";
    startDateField.delegate = self;
    startDateField.text = self.education.startDate;
    startDateField.inputView = startDatePicker;
    [scrollView addSubview:startDateField];
    
    UILabel *stillLabel = [[UILabel alloc] initWithFrame:CGRectMake(margin_20, startDateField.bottom + S_ScaleWidth(23), self.view.width - margin_20 * 2, S_ScaleWidth(20))];
    stillLabel.text = @"Are you still studying here?";
    stillLabel.textColor = rgba(20, 23, 34, 1);
    stillLabel.font = FONTR(14);
    [stillLabel sizeToFit];
    [scrollView addSubview:stillLabel];
    
    UISwitch *stillSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(self.view.width - margin_20 - S_ScaleWidth(42), startDateField.bottom + S_ScaleWidth(20), S_ScaleWidth(42), S_ScaleWidth(24))];
    self.stillSwitch = stillSwitch;
    stillSwitch.transform = CGAffineTransformMakeScale(0.7, 0.7);
    [stillSwitch setTintColor:rgba(239, 245, 249, 1)];
    [stillSwitch setOnTintColor:rgba(239, 245, 249, 1)];
    [stillSwitch setThumbTintColor:rgba(56, 94, 239, 1)];
    stillSwitch.layer.cornerRadius = S_ScaleWidth(12);
    stillSwitch.clipsToBounds = YES;
    [stillSwitch setOn:NO animated:NO];
    [stillSwitch addTarget:self action:@selector(switchAction:) forControlEvents:UIControlEventValueChanged];
    [scrollView addSubview:stillSwitch];
        
    SDatePickerContainer *endDatePicker = [[SDatePickerContainer alloc] initWithFrame:CGRectMake(0, 0, S_Screen_W, S_ScaleWidth(180) + S_SafeAreaBottomHeight) chooseBlock:^(NSString * _Nonnull dateStr) {
        weakSelf.endDateField.text = dateStr;
    }];
    
    SResumeField *endDateField = [[SResumeField alloc] initWithFrame:CGRectMake(margin_20, startDateField.bottom + S_ScaleWidth(64), fieldWidth, fieldHeight)];
    self.endDateField = endDateField;
    endDateField.placeholder = @"What year did you graduate";
    endDateField.delegate = self;
    endDateField.text = self.education.endDate;
    endDateField.inputView = endDatePicker;
    [scrollView addSubview:endDateField];
    
    UIButton *saveBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    saveBtn.frame = CGRectMake(margin_20, endDateField.bottom + S_ScaleWidth(120), fieldWidth, fieldHeight);
    [saveBtn setTitle:@"Save" forState:UIControlStateNormal];
    [saveBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [saveBtn setBackgroundColor:rgba(56, 94, 239, 1)];
    saveBtn.layer.cornerRadius = S_ScaleWidth(24);
    [saveBtn addTarget:self action:@selector(saveClick) forControlEvents:UIControlEventTouchUpInside];
    [scrollView addSubview:saveBtn];
    
    scrollView.contentSize = CGSizeMake(S_Screen_W, saveBtn.bottom + margin_20 + S_SafeAreaBottomHeight);
    
    [self showAnimatoin];
}

- (void)showAnimatoin {
    
    [UIView animateWithDuration:0.3 animations:^{
        self.backView.frame = CGRectMake(0, self.view.height - backViewHeight, S_Screen_W, backViewHeight);
    }];
}

- (void)dismissAnimation {
    [UIView animateWithDuration:0.25 animations:^{
        self.backView.frame = CGRectMake(0, self.view.height, S_Screen_W, backViewHeight);
    } completion:^(BOOL finished) {
        [self dismissViewControllerAnimated:NO completion:nil];
    }];
}

- (void)switchAction:(UISwitch *)sender {
    
    if (sender.on) {
        [self.endDateField resignFirstResponder];
        self.endDateField.hidden = YES;
    }else {
        self.endDateField.hidden = NO;
    }
}

- (void)saveClick {
    
    SResumeEducationModel *education = [SResumeEducationModel new];
    education.school = self.schoolField.text;
    education.major = self.majorField.text;
    education.startDate = self.startDateField.text;
    
    if (self.stillSwitch.on) {
        education.isStill = YES;
        education.endDate = @"So far";
    }else {
        education.isStill = NO;
        education.endDate = self.endDateField.text;
    }
    
    if (self.addEducationBlock) {
        self.addEducationBlock(education);
    }
    
    [self dismissAnimation];
}


@end
