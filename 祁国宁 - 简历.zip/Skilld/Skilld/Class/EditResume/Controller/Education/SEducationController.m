//
//  SEducationController.m
//  Skilld
//
//  Created by Speed on 2022/11/21.
//

#import "SEducationController.h"
#import "SEducationExperienceCell.h"
#import "SAddEducationController.h"
#import "SResumeDeleteContainer.h"

@interface SEducationController () <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, weak) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *educations;

@end

@implementation SEducationController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    if (self.resumeModel.educations) {
        [self.educations addObjectsFromArray:self.resumeModel.educations];
    }

    [self initView];
}

- (void)initView {
    
    CGFloat margin_20 = S_ScaleWidth(20);
        
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    [scrollView contentInsetScrollView];
    
    [self.view addSubview:scrollView];

    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.text = @"Your education";
    titleLabel.textColor = rgba(20, 23, 34, 1);
    titleLabel.font = HMFONTB(18);
    [scrollView addSubview:titleLabel];
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.mas_equalTo(margin_20);
    }];
    
    UIView *tableFooterView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, S_Screen_W, S_ScaleWidth(88))];
    
    UIButton *addEducationBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [addEducationBtn setImage:[UIImage imageNamed:@"add"] forState:UIControlStateNormal];
    [addEducationBtn addTarget:self action:@selector(addEducation) forControlEvents:UIControlEventTouchUpInside];
    [tableFooterView addSubview:addEducationBtn];
    [addEducationBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_ScaleWidth(20));
        make.centerX.mas_equalTo(0);
        make.width.mas_equalTo(S_ScaleWidth(150));
        make.height.mas_equalTo(S_ScaleWidth(48));
    }];
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    self.tableView = tableView;
    [tableView contentInsetScrollView];
    tableView.backgroundColor = [UIColor clearColor];
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.showsVerticalScrollIndicator = NO;
    tableView.showsHorizontalScrollIndicator = NO;
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    tableView.tableFooterView = tableFooterView;
    [tableView registerClass:[SEducationExperienceCell class] forCellReuseIdentifier:NSStringFromClass([SEducationExperienceCell class])];
    [self.view addSubview:tableView];
    [tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_ScaleWidth(65));
        make.left.right.bottom.mas_equalTo(0);
    }];

}

#pragma mark - <UITableViewDelegate, UITableViewDataSource>
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.educations.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    SEducationExperienceCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([SEducationExperienceCell class]) forIndexPath:indexPath];
    
    cell.index = indexPath.row + 1;
    
    cell.education = self.educations[indexPath.row];
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return S_ScaleWidth(186);
}

- (void)deleteEducationAtIndex:(NSInteger)index {
    
    SResumeDeleteContainer *container = [[SResumeDeleteContainer alloc] initWithFrame:CGRectMake(0, 0, S_ScaleWidth(290), S_ScaleWidth(160)) title:@"Delete prompt" message:@"Are you sure delete it?"];

    LSTPopView *popView = [LSTPopView initWithCustomView:container parentView:[SRoute getCurrentVC].view popStyle:LSTPopStyleFade dismissStyle:LSTDismissStyleFade];
        
    __weak typeof(popView) weakPopView = popView;

    [container setDismissBlock:^{
        [weakPopView dismiss];
    }];
    
    __weak typeof(self) weakSelf = self;
    [container setDeleteBlock:^{
        [weakSelf.educations removeObjectAtIndex:index];
        weakSelf.resumeModel.educations = weakSelf.educations;
        [weakSelf.tableView reloadData];
        [weakPopView dismiss];
    }];
    
    popView.hemStyle = LSTHemStyleCenter;
    popView.bgAlpha = 0.5;
    popView.popDuration = 0.3;
    popView.dismissDuration = 0.25;
    [popView pop];
}

- (void)editEducationAtIndex:(NSInteger)index {
    
    SAddEducationController *vc = [[SAddEducationController alloc] init];
    vc.education = self.educations[index];
    vc.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    [self presentViewController:vc animated:NO completion:nil];
    
    __weak typeof(self) weakSelf = self;
    [vc setAddEducationBlock:^(SResumeEducationModel * _Nonnull education) {
        [weakSelf.educations replaceObjectAtIndex:index withObject:education];
        weakSelf.resumeModel.educations = weakSelf.educations;
        [weakSelf.tableView reloadData];
    }];
}


- (void)addEducation {
    
    SAddEducationController *vc = [[SAddEducationController alloc] init];
    vc.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    [self presentViewController:vc animated:NO completion:nil];
    
    __weak typeof(self) weakSelf = self;
    [vc setAddEducationBlock:^(SResumeEducationModel * _Nonnull education) {
        [weakSelf.educations addObject:education];
        weakSelf.resumeModel.educations = weakSelf.educations;
        [weakSelf.tableView reloadData];
    }];
}

- (NSMutableArray *)educations {
    if (!_educations) {
        _educations = [[NSMutableArray alloc] init];
    }
    return _educations;
}


@end
