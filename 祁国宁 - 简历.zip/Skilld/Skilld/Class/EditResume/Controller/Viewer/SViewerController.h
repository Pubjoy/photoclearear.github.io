//
//  SViewerController.h
//  Skilld
//
//  Created by Speed on 2022/11/23.
//

#import "SBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface SViewerController : SBaseViewController
@property (nonatomic, strong) SResumeModel *resumeModel;
@property (nonatomic, strong) SResumeViewerModel *viewerModel;
@property (nonatomic, assign) BOOL canEdit;
@property (nonatomic, copy) void(^dismissBlock)(void);

@end

NS_ASSUME_NONNULL_END
