//
//  SViewerController.m
//  Skilld
//
//  Created by Speed on 2022/11/23.
//

#import "SViewerController.h"

#import "SViewerFirstContainer.h"
#import "SViewerTwoContainer.h"
#import "SViewerThreeContainer.h"
#import "SViewerFourContainer.h"
#import "SViewerFiveContainer.h"
#import "SViewerSixContainer.h"
#import "SViewerSevenContainer.h"
#import "SViewerEightContainer.h"

#import "SEditResumeController.h"
#import "SExportFormatContainer.h"

@interface SViewerController ()
@property (nonatomic, weak) SViewerBaseContainer *container;

@end

@implementation SViewerController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    if (self.viewerModel) {
        self.resumeModel = self.viewerModel.resume;
    }
    
    [self initNavigationView];
    
    [self initView];
}

- (void)initNavigationView {

    UIView *navigationView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, S_Screen_W, S_NavigationBarHeight)];
    navigationView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:navigationView];

    UIButton *cancelBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    cancelBtn.frame = CGRectMake(0, S_AdaptNaviHeight, 64, S_NoStatusBarNavigationBarHeight);
    [cancelBtn setImage:[UIImage imageNamed:@"back_icon"] forState:UIControlStateNormal];
    cancelBtn.showsTouchWhenHighlighted = NO;
    [cancelBtn addTarget:self action:@selector(cancelClick) forControlEvents:UIControlEventTouchUpInside];
    [navigationView addSubview:cancelBtn];
    
    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.text = @"Viewer";
    titleLabel.font = HMFONTB(20);
    titleLabel.textColor = rgba(20, 23, 34, 1);
    [navigationView addSubview:titleLabel];
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(0);
        make.top.mas_equalTo(S_AdaptNaviHeight);
        make.height.mas_equalTo(S_NoStatusBarNavigationBarHeight);
    }];
    
    if (self.canEdit) {
        
        UIButton *editBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        editBtn.frame = CGRectMake(self.view.width - 66, S_AdaptNaviHeight, 66, S_NoStatusBarNavigationBarHeight);
        [editBtn setTitle:@"Edit" forState:UIControlStateNormal];
        [editBtn setTitleColor:rgba(20, 23, 34, 1) forState:UIControlStateNormal];
        editBtn.titleLabel.font = HMFONTM(14);
        editBtn.showsTouchWhenHighlighted = NO;
        [editBtn addTarget:self action:@selector(editClick) forControlEvents:UIControlEventTouchUpInside];
        [navigationView addSubview:editBtn];
    }
}

- (void)initView {
        
    [self initViewer:self.resumeModel.style];
    
    UIButton *exportBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [exportBtn setBackgroundColor:rgba(56, 94, 239, 1)];
    if (self.canEdit) {
        [exportBtn setTitle:@"Share" forState:UIControlStateNormal];
    }else {
        [exportBtn setTitle:@"Export" forState:UIControlStateNormal];
    }
    [exportBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    exportBtn.showsTouchWhenHighlighted = NO;
    exportBtn.titleLabel.font = HMFONTB(16);
    exportBtn.layer.cornerRadius = S_ScaleWidth(24);
    [exportBtn addTarget:self action:@selector(exportClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:exportBtn];
    [exportBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(0);
        make.width.mas_equalTo(S_ScaleWidth(335));
        make.height.mas_equalTo(S_ScaleWidth(48));
        make.bottom.mas_equalTo(-S_SafeAreaBottomHeight - S_ScaleWidth(50));
    }];
}

- (void)initViewer:(NSInteger)type {
    
    if (type == 0) {
        SViewerFirstContainer *container = [[SViewerFirstContainer alloc] initWithFrame:CGRectMake(S_ScaleWidth(38), S_NavigationBarHeight + S_ScaleWidth(50), S_ScaleWidth(300), S_ScaleWidth(438)) resume:self.resumeModel];
        self.container = container;
        [self.view addSubview:container];

    }else if (type == 1) {
        SViewerTwoContainer *container = [[SViewerTwoContainer alloc] initWithFrame:CGRectMake(S_ScaleWidth(38), S_NavigationBarHeight + S_ScaleWidth(50), S_ScaleWidth(300), S_ScaleWidth(438)) resume:self.resumeModel];
        self.container = container;
        [self.view addSubview:container];
    }else if (type == 2) {
        SViewerThreeContainer *container = [[SViewerThreeContainer alloc] initWithFrame:CGRectMake(S_ScaleWidth(38), S_NavigationBarHeight + S_ScaleWidth(50), S_ScaleWidth(300), S_ScaleWidth(438)) resume:self.resumeModel];
        self.container = container;
        [self.view addSubview:container];
    }else if (type == 3) {
        SViewerFourContainer *container = [[SViewerFourContainer alloc] initWithFrame:CGRectMake(S_ScaleWidth(38), S_NavigationBarHeight + S_ScaleWidth(50), S_ScaleWidth(300), S_ScaleWidth(438)) resume:self.resumeModel];
        self.container = container;
        [self.view addSubview:container];
    }else if (type == 4) {
        SViewerFiveContainer *container = [[SViewerFiveContainer alloc] initWithFrame:CGRectMake(S_ScaleWidth(38), S_NavigationBarHeight + S_ScaleWidth(50), S_ScaleWidth(300), S_ScaleWidth(438)) resume:self.resumeModel];
        self.container = container;
        [self.view addSubview:container];
    }else if (type == 5) {
        SViewerSixContainer *container = [[SViewerSixContainer alloc] initWithFrame:CGRectMake(S_ScaleWidth(38), S_NavigationBarHeight + S_ScaleWidth(50), S_ScaleWidth(300), S_ScaleWidth(438)) resume:self.resumeModel];
        self.container = container;
        [self.view addSubview:container];
    }else if (type == 6) {
        SViewerSevenContainer *container = [[SViewerSevenContainer alloc] initWithFrame:CGRectMake(S_ScaleWidth(38), S_NavigationBarHeight + S_ScaleWidth(50), S_ScaleWidth(300), S_ScaleWidth(438)) resume:self.resumeModel];
        self.container = container;
        [self.view addSubview:container];
    }else if (type == 7) {
        SViewerEightContainer *container = [[SViewerEightContainer alloc] initWithFrame:CGRectMake(S_ScaleWidth(38), S_NavigationBarHeight + S_ScaleWidth(50), S_ScaleWidth(300), S_ScaleWidth(438)) resume:self.resumeModel];
        self.container = container;
        [self.view addSubview:container];
    }
}

- (void)cancelClick {
    
    [self.navigationController popViewControllerAnimated:YES];
    
//    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)editClick {
    
    SEditResumeController *editVC = [[SEditResumeController alloc] init];
    editVC.viewerModel = self.viewerModel;
    [self.navigationController pushViewController:editVC animated:YES];
//    editVC.modalPresentationStyle = UIModalPresentationOverCurrentContext;
//    [self presentViewController:editVC animated:YES completion:nil];
}

- (void)exportClick {
    
    if (self.canEdit) {
        
        if (self.viewerModel.format == 0) {
            [SRoute shareWithImage:self.viewerModel.resumeImage target:self complete:^(BOOL isSuccess, UIActivityType  _Nonnull type) {
                
            }];
        }else {
            [SRoute sharePDFWithFilePath:self.viewerModel.resumePath target:self complete:^(BOOL isSuccess, UIActivityType  _Nonnull type) {
                
            }];
        }
    }else {
        SLog(@"show Exported");
        [self showExportFormatContainer];
    }
}

- (void)showExportFormatContainer {
    
    SExportFormatContainer *container = [[SExportFormatContainer alloc] initWithFrame:CGRectMake(0, 0, self.view.width, S_ScaleWidth(345) + S_SafeAreaBottomHeight)];
    
    
    LSTPopView *popView = [LSTPopView initWithCustomView:container parentView:[SRoute getCurrentVC].view popStyle:LSTPopStyleSmoothFromBottom dismissStyle:LSTDismissStyleSmoothToBottom];
    
    __weak typeof(popView)weakPopView = popView;
    
    __weak typeof(self)weakSelf = self;
    [container setFormatBlock:^(NSInteger format) {
            
        [weakSelf save:format];
        
        [weakPopView dismiss];
    }];
    
    popView.isClickBgDismiss = YES;
    popView.hemStyle = LSTHemStyleBottom;
    popView.bgAlpha = 0.5;
    popView.popDuration = 0.3;
    popView.dismissDuration = 0.25;
    [popView pop];
}

- (void)save:(NSInteger)format {

    UIImage *resumeImage = [SRoute snapshotWithScrollView:self.container.scrollView];

    NSString *resumePath = [SRoute creatPdfPathWithScrollView:self.container.scrollView];
    
    if (self.viewerModel) {
        self.viewerModel.resume = self.resumeModel;
        self.viewerModel.resumePath = resumePath;
        self.viewerModel.resumeImage = resumeImage;
        self.viewerModel.format = format;
        self.viewerModel.bg_tableName = Resume_Tablename;
        [self.viewerModel bg_saveOrUpdate];
    }else {
        SResumeViewerModel *viewerModel = [[SResumeViewerModel alloc] init];
        viewerModel.resume = self.resumeModel;
        viewerModel.resumePath = resumePath;
        viewerModel.resumeImage = resumeImage;
        viewerModel.format = format;
        viewerModel.bg_tableName = Resume_Tablename;
        [viewerModel bg_saveOrUpdate];
    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:ResumeSaveSuccessNotification object:nil];
    
    if (self.dismissBlock) {
        self.dismissBlock();
    }

    [self.navigationController popToRootViewControllerAnimated:YES];

    
}


@end
