//
//  SEditResumeController.m
//  Skilld
//
//  Created by Speed on 2022/11/18.
//

#import "SEditResumeController.h"
#import "JXCategoryView.h"
#import "SBasicInfoController.h"
#import "SGoalController.h"
#import "SWorkController.h"
#import "SSkillsController.h"
#import "SEducationController.h"
#import "SSummaryController.h"
#import "STemplateController.h"
#import "SViewerController.h"

@interface SEditResumeController () <JXCategoryViewDelegate, JXCategoryListContainerViewDelegate>
/// <#Description#>
@property (nonatomic, strong) JXCategoryTitleImageView *categoryView;
/// <#Description#>
@property (nonatomic, strong) NSArray *imageNames;
/// <#Description#>
@property (nonatomic, strong) NSArray *selectedImageNames;
/// <#Description#>
@property (nonatomic, strong) NSArray *imageTypes;
/// <#Description#>
@property (nonatomic, strong) NSArray *titles;
/// <#Description#>
@property (nonatomic, strong) UIView *backView;
/// <#Description#>
@property (nonatomic, strong) SResumeModel *resumeModel;

@end

@implementation SEditResumeController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    if (self.viewerModel) {
        self.resumeModel = self.viewerModel.resume;
    }else {
        self.resumeModel = [[SResumeModel alloc] init];
    }
    
    [self initNavigationView];
    
    [self initView];
}

- (void)initNavigationView {

    UIView *navigationView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, S_Screen_W, S_NavigationBarHeight)];
    navigationView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:navigationView];

    UIButton *cancelBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [cancelBtn setTitle:@"Cancel" forState:UIControlStateNormal];
    [cancelBtn setTitleColor:rgba(20, 23, 34, 1) forState:UIControlStateNormal];
    cancelBtn.showsTouchWhenHighlighted = NO;
    cancelBtn.titleLabel.font = HMFONTR(14);
    cancelBtn.frame = CGRectMake(0, S_AdaptNaviHeight, 88, S_NoStatusBarNavigationBarHeight);
    [cancelBtn addTarget:self action:@selector(cancelClick) forControlEvents:UIControlEventTouchUpInside];
    [navigationView addSubview:cancelBtn];
    
    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.text = @"Edit";
    titleLabel.font = HMFONTB(20);
    titleLabel.textColor = rgba(20, 23, 34, 1);
    [navigationView addSubview:titleLabel];
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(0);
        make.top.mas_equalTo(S_AdaptNaviHeight);
        make.height.mas_equalTo(S_NoStatusBarNavigationBarHeight);
    }];
    
    UIButton *doneBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    doneBtn.frame = CGRectMake(S_Screen_W - S_ScaleWidth(80), S_AdaptNaviHeight + S_ScaleWidth(7), S_ScaleWidth(60), S_ScaleWidth(30));
    [doneBtn setBackgroundColor:rgba(56, 94, 239, 1)];
    [doneBtn setTitle:@"Done" forState:UIControlStateNormal];
    [doneBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    doneBtn.showsTouchWhenHighlighted = NO;
    doneBtn.titleLabel.font = HMFONTM(14);
    doneBtn.layer.cornerRadius = S_ScaleWidth(15);
    [doneBtn addTarget:self action:@selector(doneClick) forControlEvents:UIControlEventTouchUpInside];
    [navigationView addSubview:doneBtn];
}

- (void)initView {
    
    [self.view addSubview:self.categoryView];
    
    CGFloat Y = self.categoryView.bottom + S_ScaleWidth(10);
    
    JXCategoryListContainerView *listContainerView = [[JXCategoryListContainerView alloc] initWithType:JXCategoryListContainerType_ScrollView delegate:self];
    listContainerView.frame = CGRectMake(0, Y, S_Screen_W, S_Screen_H - Y);
    [self.view addSubview:listContainerView];
    self.categoryView.listContainer = listContainerView;
}

- (void)cancelClick {
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)doneClick {
    
    [self.view endEditing:YES];
    
    SViewerController *vc = [[SViewerController alloc] init];
    if (self.viewerModel) {
        vc.viewerModel = self.viewerModel;
    }else {
        vc.resumeModel = self.resumeModel;
    }
    
    [self.navigationController pushViewController:vc animated:YES];
}


#pragma mark - <SCategoryViewDelegate>
- (void)categoryDidSelectedIndex:(NSInteger)index {
    
}


#pragma mark - <JXCategoryListContainerViewDelegate>
- (NSInteger)numberOfListsInlistContainerView:(JXCategoryListContainerView *)listContainerView {
    return self.imageNames.count;
}

- (id<JXCategoryListContentViewDelegate>)listContainerView:(JXCategoryListContainerView *)listContainerView initListForIndex:(NSInteger)index {
    if (index == 0) {
        SBasicInfoController *vc = [[SBasicInfoController alloc] init];
        vc.resumeModel = self.resumeModel;
        return vc;
    }else if (index == 1) {
        SGoalController *vc = [[SGoalController alloc] init];
        vc.resumeModel = self.resumeModel;
        return vc;
    }else if (index == 2) {
        SWorkController *vc = [[SWorkController alloc] init];
        vc.resumeModel = self.resumeModel;
        return vc;
    }else if (index == 3) {
        SSkillsController *vc = [[SSkillsController alloc] init];
        vc.resumeModel = self.resumeModel;
        return vc;
    }else if (index == 4) {
        SEducationController *vc = [[SEducationController alloc] init];
        vc.resumeModel = self.resumeModel;
        return vc;
    }else if (index == 5) {
        SSummaryController *vc = [[SSummaryController alloc] init];
        vc.resumeModel = self.resumeModel;
        return vc;
    }else {
        STemplateController *vc = [[STemplateController alloc] init];
        vc.resumeModel = self.resumeModel;
        return vc;
    }
}


#pragma mark - Lazyload
- (JXCategoryTitleImageView *)categoryView {
    if (!_categoryView) {
        _categoryView = [[JXCategoryTitleImageView alloc] initWithFrame:CGRectMake(0, S_NavigationBarHeight, S_Screen_W, S_ScaleWidth(88))];
        _categoryView.backgroundColor = [UIColor whiteColor];
        _categoryView.delegate = self;
        _categoryView.titles = self.titles;
        _categoryView.imageNames = self.imageNames;
        _categoryView.selectedImageNames = self.selectedImageNames;
        _categoryView.imageTypes = self.imageTypes;
        _categoryView.imageSize = CGSizeMake(S_ScaleWidth(28), S_ScaleWidth(28));
        _categoryView.titleColor = rgba(138, 148, 160, 1);
        _categoryView.titleSelectedColor = rgba(20, 23, 34, 1);
        _categoryView.titleFont = FONTR(14);
        _categoryView.titleSelectedFont = FONTM(14);
        _categoryView.cellWidth = S_ScaleWidth(85);
        _categoryView.cellSpacing = 0;
        _categoryView.averageCellSpacingEnabled = NO;
        _categoryView.contentEdgeInsetLeft = S_ScaleWidth(10);
        _categoryView.contentEdgeInsetRight = S_ScaleWidth(10);
        
        JXCategoryIndicatorLineView *indicator = [[JXCategoryIndicatorLineView alloc] init];
        indicator.indicatorColor = rgba(56, 94, 239, 1);
        indicator.indicatorWidth = S_ScaleWidth(63);
        indicator.indicatorHeight = S_ScaleWidth(3);
        indicator.verticalMargin = S_ScaleWidth(10);
        _categoryView.indicators = @[indicator];
        
    }
    return _categoryView;
}

- (UIView *)backView {
    if (!_backView) {
        _backView = [[UIView alloc] initWithFrame:CGRectMake(0, self.categoryView.bottom + S_ScaleWidth(10), S_Screen_W, self.view.height - S_NavigationBarHeight - S_ScaleWidth(88))];
        [_backView cornerByRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight cornerRadius:S_ScaleWidth(20)];
        _backView.clipsToBounds = YES;
        _backView.backgroundColor = [UIColor whiteColor];
    }
    return _backView;
}

- (NSArray *)imageNames {
    
    if (!_imageNames) {
        _imageNames = @[@"basic_info_normal",
                     @"goal_normal",
                     @"work_normal",
                     @"skills_normal",
                     @"eudcation_normal",
                     @"summary_normal",
                     @"template_normal"];
    }
    return _imageNames;
}

- (NSArray *)selectedImageNames {
    if (!_selectedImageNames) {
        _selectedImageNames = @[@"basic_info_selected",
                                @"goal_selected",
                                @"work_selected",
                                @"skills_selected",
                                @"eudcation_selected",
                                @"summary_selected",
                                @"template_selected"];
    }
    return _selectedImageNames;
}

- (NSArray *)imageTypes {
    if (!_imageTypes) {
        _imageTypes = @[@0, @0, @0, @0, @0, @0, @0];
    }
    return _imageTypes;
}

- (NSArray *)titles {
    if (!_titles) {
        _titles = @[@"Basic info",
                    @"Goal",
                    @"Work",
                    @"Skills",
                    @"Eudcation",
                    @"Summary",
                    @"Template"];
    }
    return _titles;
}


@end
