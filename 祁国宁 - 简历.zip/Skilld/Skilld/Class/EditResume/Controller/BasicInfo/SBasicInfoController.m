//
//  SBasicInfoController.m
//  Skilld
//
//  Created by Speed on 2022/11/19.
//

#import "SBasicInfoController.h"

@interface SBasicInfoController ()
@property (nonatomic, weak) SResumeField *firstNameField;
@property (nonatomic, weak) SResumeField *lastNameField;
@property (nonatomic, weak) SResumeField *emailField;
@property (nonatomic, weak) SResumeField *phoneField;
@property (nonatomic, weak) SResumeField *blogsField;
@property (nonatomic, weak) SResumeField *addressField;

@end

@implementation SBasicInfoController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    if (!self.resumeModel.basicInfo) {
        SResumeBasicInfoModel *basicInfo = [[SResumeBasicInfoModel alloc] init];
        self.resumeModel.basicInfo = basicInfo;
    }
    
    [self initView];
}

- (void)initView {
    
    CGFloat margin_20 = S_ScaleWidth(20);
    CGFloat margin_12 = S_ScaleWidth(12);
        
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    [scrollView contentInsetScrollView];
    
    [self.view addSubview:scrollView];

    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.text = @"What’s your name?";
    titleLabel.textColor = rgba(20, 23, 34, 1);
    titleLabel.font = HMFONTB(18);
    [scrollView addSubview:titleLabel];
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.mas_equalTo(margin_20);
    }];
    
    CGFloat fieldWidth = S_ScaleWidth(335);
    CGFloat fieldHeight = S_ScaleWidth(48);
    
    SResumeField *firstNameField = [[SResumeField alloc] initWithFrame:CGRectMake(margin_20, S_ScaleWidth(65), fieldWidth, fieldHeight)];
    self.firstNameField = firstNameField;
    firstNameField.text = self.resumeModel.basicInfo.firstName;
    firstNameField.placeholder = @"First Name";
    firstNameField.delegate = self;
    firstNameField.maxTextLength = 20;
    [scrollView addSubview:firstNameField];
        
    SResumeField *lastNameField = [[SResumeField alloc] initWithFrame:CGRectMake(margin_20, firstNameField.bottom + margin_12, fieldWidth, fieldHeight)];
    self.lastNameField = lastNameField;
    lastNameField.text = self.resumeModel.basicInfo.lastName;
    lastNameField.placeholder = @"Last Name";
    lastNameField.delegate = self;
    lastNameField.maxTextLength = 20;
    [scrollView addSubview:lastNameField];
    
    UILabel *titleLabel1 = [[UILabel alloc] init];
    titleLabel1.text = @"How would you like a potential employer to contact you?";
    titleLabel1.textColor = rgba(20, 23, 34, 1);
    titleLabel1.font = FONTR(14);
    titleLabel1.numberOfLines = 2;
    [scrollView addSubview:titleLabel1];
    [titleLabel1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(lastNameField.mas_bottom).offset(margin_20);
        make.left.mas_equalTo(margin_20);
        make.width.mas_equalTo(S_ScaleWidth(335));
    }];
    
    
    SResumeField *emailField = [[SResumeField alloc] initWithFrame:CGRectMake(margin_20, lastNameField.bottom + S_ScaleWidth(78), fieldWidth, fieldHeight)];
    self.emailField = emailField;
    emailField.text = self.resumeModel.basicInfo.email;
    emailField.placeholder = @"example@gmail.com (Required)";
    emailField.delegate = self;
    emailField.maxTextLength = 50;
    [scrollView addSubview:emailField];

    SResumeField *phoneField = [[SResumeField alloc] initWithFrame:CGRectMake(margin_20, emailField.bottom + margin_12, fieldWidth, fieldHeight)];
    self.phoneField = phoneField;
    phoneField.text = self.resumeModel.basicInfo.phone;
    phoneField.placeholder = @"(666)4567890";
    phoneField.delegate = self;
    phoneField.isPhoneNumber = YES;
    phoneField.maxTextLength = 20;
    [scrollView addSubview:phoneField];
    
    SResumeField *blogsField = [[SResumeField alloc] initWithFrame:CGRectMake(margin_20, phoneField.bottom + margin_12, fieldWidth, fieldHeight)];
    self.blogsField = blogsField;
    self.blogsField.text = self.resumeModel.basicInfo.blogs;
    blogsField.placeholder = @"www.example.com";
    blogsField.delegate = self;
    blogsField.maxTextLength = 50;
    [scrollView addSubview:blogsField];
    
    SResumeField *addressField = [[SResumeField alloc] initWithFrame:CGRectMake(margin_20, blogsField.bottom + margin_12, fieldWidth, fieldHeight)];
    self.addressField = addressField;
    addressField.text = self.resumeModel.basicInfo.address;
    addressField.placeholder = @"123 Main Street,New Y…";
    addressField.delegate = self;
    addressField.maxTextLength = 100;
    [scrollView addSubview:addressField];

    scrollView.contentSize = CGSizeMake(S_Screen_W, addressField.bottom + margin_20 + S_SafeAreaBottomHeight);

        
    __weak typeof(self) weakSelf = self;
    
    [firstNameField setCmTextFieldTextChangedBlock:^(CMTextField * _Nonnull tf) {
        weakSelf.resumeModel.basicInfo.firstName = tf.text;
    }];
    
    [lastNameField setCmTextFieldTextChangedBlock:^(CMTextField * _Nonnull tf) {
        weakSelf.resumeModel.basicInfo.lastName = tf.text;
    }];
    
    [emailField setCmTextFieldTextChangedBlock:^(CMTextField * _Nonnull tf) {
        weakSelf.resumeModel.basicInfo.email = tf.text;
    }];
    
    [phoneField setCmTextFieldTextChangedBlock:^(CMTextField * _Nonnull tf) {
        weakSelf.resumeModel.basicInfo.phone = tf.text;
    }];

    [blogsField setCmTextFieldTextChangedBlock:^(CMTextField * _Nonnull tf) {
        weakSelf.resumeModel.basicInfo.blogs = tf.text;
    }];
    
    [addressField setCmTextFieldTextChangedBlock:^(CMTextField * _Nonnull tf) {
        weakSelf.resumeModel.basicInfo.address = tf.text;
    }];
}


@end
