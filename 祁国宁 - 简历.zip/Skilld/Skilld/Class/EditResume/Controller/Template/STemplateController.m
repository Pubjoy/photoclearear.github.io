//
//  STemplateController.m
//  Skilld
//
//  Created by Speed on 2022/11/19.
//

#import "STemplateController.h"
#import "STemplateCell.h"

@interface STemplateController () <UICollectionViewDelegate, UICollectionViewDataSource>
/// <#Description#>
@property (nonatomic, weak) UIImageView *imageView;
@end

@implementation STemplateController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self initView];
}

- (void)initView {
    
    CGFloat margin_20 = S_ScaleWidth(20);
        
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    [scrollView contentInsetScrollView];
    
    [self.view addSubview:scrollView];

    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.text = @"Please choose a template below";
    titleLabel.textColor = rgba(20, 23, 34, 1);
    titleLabel.font = HMFONTB(18);
    [scrollView addSubview:titleLabel];
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.mas_equalTo(margin_20);
    }];
    
    UIImageView *imageView = [[UIImageView alloc] init];
    self.imageView = imageView;
    imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"resume_style_%ld", self.resumeModel.style]];
    [scrollView addSubview:imageView];
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_ScaleWidth(75));
        make.left.mas_equalTo(S_ScaleWidth(68));
        make.width.mas_equalTo(S_ScaleWidth(240));
        make.height.mas_equalTo(S_ScaleWidth(339));
    }];
    
    
    CGFloat itemWidth = S_ScaleWidth(90);
    CGFloat itemHeight = S_ScaleWidth(128);
    CGFloat minimumLineSpacing = S_ScaleWidth(10);
    CGFloat minimumInteritemSpacing = S_ScaleWidth(10);
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.minimumLineSpacing = minimumLineSpacing;
    layout.minimumInteritemSpacing = minimumInteritemSpacing;
    layout.itemSize = CGSizeMake(itemWidth, itemHeight);
    layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    
    UICollectionView *collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
    collectionView.backgroundColor = [UIColor clearColor];
    collectionView.delegate = self;
    collectionView.dataSource = self;
    collectionView.contentInset = UIEdgeInsetsMake(0, S_ScaleWidth(20), 0, S_ScaleWidth(20));
    collectionView.showsVerticalScrollIndicator = NO;
    collectionView.showsHorizontalScrollIndicator = NO;
    [collectionView registerClass:[STemplateCell class] forCellWithReuseIdentifier:NSStringFromClass([STemplateCell class])];
    [scrollView addSubview:collectionView];
    [collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(imageView.mas_bottom).offset(S_ScaleWidth(30));
        make.left.mas_equalTo(0);
        make.width.mas_equalTo(S_Screen_W);
        make.height.mas_equalTo(itemHeight);
    }];
}

#pragma mark - <UICollectionViewDelegate, UICollectionViewDataSource>
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    return 8;
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    STemplateCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([STemplateCell class]) forIndexPath:indexPath];
    cell.style = indexPath.item;
    cell.isCheck = self.resumeModel.style == indexPath.item;
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
        
    self.resumeModel.style = indexPath.item;
    
    self.imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"resume_style_%ld", indexPath.item]];
    
    [collectionView reloadData];
}


@end
