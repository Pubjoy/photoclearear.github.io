//
//  STemplateController.h
//  Skilld
//
//  Created by Speed on 2022/11/19.
//

#import "SResumeEditBaseController.h"

NS_ASSUME_NONNULL_BEGIN

@interface STemplateController : SResumeEditBaseController

@end

NS_ASSUME_NONNULL_END
