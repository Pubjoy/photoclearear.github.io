//
//  SSummaryController.m
//  Skilld
//
//  Created by Speed on 2022/11/19.
//

#import "SSummaryController.h"

@interface SSummaryController () <UITextViewDelegate>
/// <#Description#>
@property (nonatomic, weak) UIView *shadowContainer;

/// <#Description#>
@property (nonatomic, weak) CMTextView *textView;

@end

@implementation SSummaryController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    if (!self.resumeModel.summary) {
        SResumeSummaryModel *summary = [[SResumeSummaryModel alloc] init];
        self.resumeModel.summary = summary;
    }
    
    [self initView];
}

- (void)initView {
    
    CGFloat margin_20 = S_ScaleWidth(20);
        
    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.text = @"Write a shote summary about youself";
    titleLabel.textColor = rgba(20, 23, 34, 1);
    titleLabel.font = HMFONTB(18);
    [self.view addSubview:titleLabel];
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.mas_equalTo(margin_20);
    }];
    
    UIView *shadowContainer = [[UIView alloc] initWithFrame:CGRectMake(margin_20, S_ScaleWidth(65), S_ScaleWidth(335), S_ScaleWidth(120))];
    self.shadowContainer = shadowContainer;
    shadowContainer.backgroundColor = rgba(239, 245, 249, 1);
    shadowContainer.layer.borderColor = [UIColor clearColor].CGColor;
    shadowContainer.layer.borderWidth = 0.5;
    shadowContainer.layer.cornerRadius = S_ScaleWidth(10);
    shadowContainer.layer.shadowColor = [UIColor clearColor].CGColor;
    shadowContainer.layer.shadowOffset = CGSizeMake(0, 2);
    shadowContainer.layer.shadowRadius = 3;
    shadowContainer.layer.shadowOpacity = 1;
    [self.view addSubview:shadowContainer];

    CMTextView *textView = [CMTextView textView];
    self.textView = textView;
    textView.text = self.resumeModel.summary.summary;
    textView.frame = shadowContainer.bounds;
    textView.backgroundColor = [UIColor clearColor];
    textView.placeholder = @"s……";
    textView.font = FONTR(15);
    textView.textColor = rgba(20, 23, 34, 1);
    textView.delegate = self;
    textView.enablesReturnKeyAutomatically = YES;
    textView.maxLength = 500;
    [shadowContainer addSubview:textView];

    SResumeSummaryModel *summary = [[SResumeSummaryModel alloc] init];
    
    self.resumeModel.summary = summary;
    
    __weak typeof(self) weakSelf = self;

    [textView addTextDidChangeHandler:^(CMTextView * _Nonnull textView) {
        weakSelf.resumeModel.summary.summary = textView.text;
    }];
}

#pragma mark - <UITextViewDelegate>
- (void)textViewDidBeginEditing:(CMTextView *)textView {
    self.shadowContainer.layer.borderColor = rgba(219, 226, 255, 1).CGColor;
    self.shadowContainer.layer.shadowColor = rgba(56, 94, 239, 0.30).CGColor;
}

- (void)textViewDidEndEditing:(CMTextView *)textView {
    self.shadowContainer.layer.borderColor = [UIColor clearColor].CGColor;
    self.shadowContainer.layer.shadowColor = [UIColor clearColor].CGColor;
}

@end
