//
//  SCYLPlusButton.m
//  Skilld
//
//  Created by Speed on 2022/11/18.
//

#import "SCYLPlusButton.h"
#import "SEditResumeController.h"

@interface SCYLPlusButton ()

@end

@implementation SCYLPlusButton

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        self.adjustsImageWhenHighlighted = NO;
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];

    CGFloat const imageViewEdgeWidth   = self.bounds.size.width * 1.0;
    CGFloat const imageViewEdgeHeight  = imageViewEdgeWidth;

    CGFloat const centerOfView    = self.bounds.size.width * 0.5;
    CGFloat const labelLineHeight = self.titleLabel.font.lineHeight;
    CGFloat const verticalMargin  = (self.bounds.size.height - labelLineHeight - imageViewEdgeHeight) * 0.5;

    CGFloat const centerOfImageView  = verticalMargin + imageViewEdgeHeight * 0.5;
    CGFloat const centerOfTitleLabel = imageViewEdgeHeight  + verticalMargin * 2 + labelLineHeight * 0.5 - 1;

    self.imageView.bounds = CGRectMake(0, 0, imageViewEdgeWidth, imageViewEdgeHeight);
    self.imageView.center = CGPointMake(centerOfView, centerOfImageView);

    self.titleLabel.bounds = CGRectMake(0, 0, self.bounds.size.width, labelLineHeight);
    self.titleLabel.center = CGPointMake(centerOfView, centerOfTitleLabel);
}

#pragma mark - IBActions

- (void)clickPublish {
    
    SEditResumeController *vc = [[SEditResumeController alloc] init];
    [[SRoute getCurrentVC].navigationController pushViewController:vc animated:YES];
}

#pragma mark - CYLPlusButtonSubclassing

+ (id)plusButton {
    SCYLPlusButton *button = [SCYLPlusButton buttonWithType:UIButtonTypeCustom];
    UIImage *normalButtonImage = [UIImage imageNamed:@"creat_resume"];
    UIImage *hlightButtonImage = [UIImage imageNamed:@"creat_resume"];
    [button setImage:normalButtonImage forState:UIControlStateNormal];
    [button setImage:hlightButtonImage forState:UIControlStateHighlighted];
    [button setImage:hlightButtonImage forState:UIControlStateSelected];
    button.frame = CGRectMake(0.0, 0.0, 70, 70);
    [button addTarget:button action:@selector(clickPublish) forControlEvents:UIControlEventTouchUpInside];
    return button;
}

+ (NSUInteger)indexOfPlusButtonInTabBar {
    return 1;
}

//+ (UIViewController *)plusChildViewController {
//
//    SEditResumeController *vc = [[SEditResumeController alloc] init];
//    return vc;
//}

+ (CGFloat)multiplierOfTabBarHeight:(CGFloat)tabBarHeight {
    return  0.3;
}

+ (CGFloat)constantOfPlusButtonCenterYOffsetForTabBarHeight:(CGFloat)tabBarHeight {
    return (CYL_IS_IPHONE_X ? - 6 : 4);
}

@end
