//
//  SCYLPlusButton.h
//  Skilld
//
//  Created by Speed on 2022/11/18.
//

#import <CYLTabBarController/CYLTabBarController.h>

NS_ASSUME_NONNULL_BEGIN

@interface SCYLPlusButton : CYLPlusButton <CYLPlusButtonSubclassing>

@end

NS_ASSUME_NONNULL_END
