//
//  SResumeModel.m
//  Skilld
//
//  Created by Speed on 2022/11/18.
//

#import "SResumeModel.h"

@implementation SResumeBasicInfoModel

@end

@implementation SResumeGoalModel

@end

@implementation SResumeExperienceModel

- (NSInteger)cellHeight {
    
    CGFloat topMargin = S_ScaleWidth(46);
    CGFloat margin_12 = S_ScaleWidth(12);
    CGFloat margin_20 = S_ScaleWidth(20);
    CGFloat maxWidth = S_ScaleWidth(310);
    
    CGFloat contentHeight = 0.f;
    if (self.employ.length != 0) {
        contentHeight += S_ScaleWidth(22) + margin_12;
    }else {
        contentHeight += margin_12;
    }
    
    if (self.jobTitle.length != 0) {
        contentHeight += S_ScaleWidth(22) + margin_12;
    }else {
        contentHeight += margin_12;
    }
    
    if (self.city.length != 0) {
        contentHeight += S_ScaleWidth(22) + margin_12;
    }else {
        contentHeight += margin_12;
    }

    if (self.startDate.length != 0 || self.endDate.length != 0) {
        contentHeight += S_ScaleWidth(22) + margin_12;
    }else {
        contentHeight += margin_12;
    }
    
    if (self.jobDesc.length != 0) {
        contentHeight += [self.jobDesc sizeWithFont:FONTR(15) maxW:maxWidth].height + 1;
    }
    
    if (contentHeight != 0) {
        return topMargin + margin_20 + contentHeight + margin_20 + S_ScaleWidth(10);
    }else {
        return contentHeight;
    }
}

@end

@implementation SResumeSkillsModel

@end

@implementation SResumeEducationModel

@end

@implementation SResumeSummaryModel

@end

@implementation SResumeModel

+ (NSDictionary *)mj_objectClassInArray {
    return @{@"works" : @"",
             @"skills" : @"",
             @"educations" : @"SResumeEducationModel"};
}

@end

@implementation SResumeViewerModel

@end
