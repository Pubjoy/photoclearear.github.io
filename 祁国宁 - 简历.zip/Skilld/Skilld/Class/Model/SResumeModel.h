//
//  SResumeModel.h
//  Skilld
//
//  Created by Speed on 2022/11/18.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SResumeBasicInfoModel : NSObject
@property (nonatomic, copy) NSString *firstName;
@property (nonatomic, copy) NSString *lastName;

@property (nonatomic, copy) NSString *email;
@property (nonatomic, copy) NSString *phone;
@property (nonatomic, copy) NSString *blogs;
@property (nonatomic, copy) NSString *address;
@end

@interface SResumeGoalModel : NSObject
@property (nonatomic, copy) NSString *jobPosition;
@property (nonatomic, copy) NSString *content;

@end

@interface SResumeExperienceModel : NSObject
@property (nonatomic, copy) NSString *employ;
@property (nonatomic, copy) NSString *jobTitle;
@property (nonatomic, copy) NSString *city;
@property (nonatomic, copy) NSString *startDate;
@property (nonatomic, copy) NSString *endDate;
@property (nonatomic, copy) NSString *jobDesc;
@property (nonatomic, assign) NSInteger cellHeight;

@end

@interface SResumeSkillsModel : NSObject
@property (nonatomic, copy) NSString *skill;
@end

@interface SResumeEducationModel : NSObject
@property (nonatomic, copy) NSString *school;
@property (nonatomic, copy) NSString *major;
@property (nonatomic, copy) NSString *startDate;
@property (nonatomic, copy) NSString *endDate;
@property (nonatomic, assign) BOOL isStill;
@end

@interface SResumeSummaryModel : NSObject
@property (nonatomic, copy) NSString *summary;
@end


@interface SResumeModel : NSObject
@property (nonatomic, strong) SResumeBasicInfoModel *basicInfo;
@property (nonatomic, strong) SResumeGoalModel *goal;
@property (nonatomic, strong) NSArray<SResumeExperienceModel *> *works;
@property (nonatomic, strong) NSArray<SResumeSkillsModel *> *skills;
@property (nonatomic, strong) NSArray<SResumeEducationModel *> *educations;
@property (nonatomic, strong) SResumeSummaryModel *summary;
@property (nonatomic, assign) NSInteger style;
@end


@interface SResumeViewerModel : NSObject
@property (nonatomic, strong) SResumeModel *resume;
@property (nonatomic, copy) NSString *resumePath;
@property (nonatomic, strong) UIImage *resumeImage;
@property (nonatomic, assign) NSInteger format;

@end

NS_ASSUME_NONNULL_END
