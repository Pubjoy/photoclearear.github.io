//
//  SMeViewController.m
//  Skilld
//
//  Created by Speed on 2022/11/18.
//

#import "SMeViewController.h"

@interface SMeViewController ()

@end

@implementation SMeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self initView];
}

- (void)initView {
    
    UIView *navigationView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, S_Screen_W, S_NavigationBarHeight)];
    navigationView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:navigationView];
    
    UIScrollView *scrollView = [[UIScrollView alloc] init];
    [scrollView contentInsetScrollView];
    [self.view addSubview:scrollView];
    [scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_NavigationBarHeight);
        make.left.right.mas_equalTo(0);
        make.bottom.mas_equalTo(0);
    }];
    
    UIView *topContainer = [[UIView alloc] initWithFrame:CGRectMake(0, 0, S_Screen_W, S_ScaleWidth(181))];
    topContainer.backgroundColor = [UIColor whiteColor];
    [topContainer cornerByRoundingCorners:UIRectCornerBottomLeft | UIRectCornerTopRight cornerRadius:S_ScaleWidth(10)];
    [scrollView addSubview:topContainer];
    
    UIImageView *iconView = [[UIImageView alloc] init];
    iconView.image = [UIImage imageNamed:@"user_icon"];
    iconView.layer.cornerRadius = S_ScaleWidth(50);
    iconView.clipsToBounds = YES;
    [topContainer addSubview:iconView];
    [iconView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(0);
        make.top.mas_equalTo(S_ScaleWidth(20));
        make.width.height.mas_equalTo(S_ScaleWidth(100));
    }];
    
    UILabel *nameLabel = [[UILabel alloc] init];
    nameLabel.text = [NSString stringWithFormat:@"ID：%@", @"288393999"];
    nameLabel.textColor = rgba(56, 58, 70, 1);
    nameLabel.font = HMFONTM(14);
    [nameLabel sizeToFit];
    [topContainer addSubview:nameLabel];
    [nameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(0);
        make.bottom.mas_equalTo(-S_ScaleWidth(20));
    }];
    
    
    UIView *vipContainer = [[UIView alloc] initWithFrame:CGRectMake(S_ScaleWidth(20), topContainer.bottom + S_ScaleWidth(20), S_ScaleWidth(335), S_ScaleWidth(191))];
    vipContainer.backgroundColor = [UIColor whiteColor];
    vipContainer.layer.cornerRadius = S_ScaleWidth(10);
    vipContainer.clipsToBounds = YES;
    [scrollView addSubview:vipContainer];

    UILabel *proLabel = [[UILabel alloc] init];
    proLabel.text = @"Upgrade Pro";
    proLabel.textColor = rgba(0, 0, 0, 1);
    proLabel.font = HMFONTB(18);
    [vipContainer addSubview:proLabel];
    [proLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_ScaleWidth(20));
        make.centerX.mas_equalTo(0);
    }];
    
    UILabel *descLabel = [[UILabel alloc] init];
    descLabel.text = @"Upgrade to pro version to convert unlimited video to audio";
    descLabel.textColor = rgba(138, 148, 160, 1);
    descLabel.font = HMFONTM(14);
    descLabel.numberOfLines = 2;
    descLabel.textAlignment = NSTextAlignmentCenter;
    [vipContainer addSubview:descLabel];
    [descLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_ScaleWidth(65));
        make.centerX.mas_equalTo(0);
        make.width.mas_equalTo(290);
    }];
    
    UIButton *goBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [goBtn setTitle:@"Go" forState:UIControlStateNormal];
    [goBtn setTitleColor:rgba(255, 255, 255, 1) forState:UIControlStateNormal];
    goBtn.backgroundColor = rgba(56, 94, 239, 1);
    goBtn.titleLabel.font = HMFONTB(18);
    goBtn.layer.cornerRadius = S_ScaleWidth(24);
    [goBtn addTarget:self action:@selector(goAction) forControlEvents:UIControlEventTouchUpInside];
    [vipContainer addSubview:goBtn];
    [goBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_ScaleWidth(123));
        make.centerX.mas_equalTo(0);
        make.width.mas_equalTo(S_ScaleWidth(150));
        make.height.mas_equalTo(S_ScaleWidth(48));
    }];
    
    NSArray *icons = @[@"about me", @"pricacy agreement", @"service agreement", @"share with friends"];
    NSArray *titles = @[@"About me", @"Pricacy agreement", @"Service agreement", @"Share with friends"];

    CGFloat itemHeight = S_ScaleWidth(48);
    
    UIView *toolContainer = [[UIView alloc] initWithFrame:CGRectMake(S_ScaleWidth(20), vipContainer.bottom + S_ScaleWidth(20), S_ScaleWidth(335), itemHeight * icons.count)];
    toolContainer.backgroundColor = [UIColor whiteColor];
    toolContainer.layer.cornerRadius = S_ScaleWidth(10);
    toolContainer.clipsToBounds = YES;
    [scrollView addSubview:toolContainer];
    
    for (int i = 0; i < icons.count; i++) {
        
        UIButton *toolButton = [UIButton buttonWithType:UIButtonTypeCustom];
        toolButton.frame = CGRectMake(0, itemHeight * i, toolContainer.width, itemHeight);
        toolButton.tag = i;
        toolButton.showsTouchWhenHighlighted = NO;
        [toolButton addTarget:self action:@selector(toolAction:) forControlEvents:UIControlEventTouchUpInside];
        [toolContainer addSubview:toolButton];
        
        UIImageView *iconView = [[UIImageView alloc] init];
        iconView.image = [UIImage imageNamed:icons[i]];
        [toolButton addSubview:iconView];
        [iconView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(0);
            make.left.mas_equalTo(S_ScaleWidth(10));
            make.size.mas_equalTo(S_ScaleWidth(24));
        }];
        
        UILabel *titleLabel = [[UILabel alloc] init];
        titleLabel.text = titles[i];
        titleLabel.textColor = rgba(20, 23, 34, 1);
        titleLabel.font = FONTR(15);
        [titleLabel sizeToFit];
        [toolButton addSubview:titleLabel];
        [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(0);
            make.left.equalTo(iconView.mas_right).offset(S_ScaleWidth(10));
        }];
    }
        
    [scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(toolContainer.mas_bottom).offset(S_ScaleWidth(20));
    }];
}

- (void)toolAction:(UIButton *)sender {
    
    if (sender.tag == 0) {
        
        [SRoute aboutMe];
        
    }else if (sender.tag == 1) {
        
        [SRoute pricacyAgreement];
        
    }else if (sender.tag == 2) {
        
        [SRoute serviceAgreement];
        
    }else if (sender.tag == 3) {
        
        [SRoute share];
    }
    
}

- (void)goAction {
    [SRoute vip];
}

@end
