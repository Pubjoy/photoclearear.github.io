//
//  SResumeField.h
//  Skilld
//
//  Created by Speed on 2022/11/19.
//

#import "CMTextField.h"

NS_ASSUME_NONNULL_BEGIN

@interface SResumeField : CMTextField

- (void)updateFieldShaowStauts:(BOOL)status;

@end

NS_ASSUME_NONNULL_END
