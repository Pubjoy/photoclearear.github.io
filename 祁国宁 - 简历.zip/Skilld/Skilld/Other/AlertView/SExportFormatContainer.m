//
//  SExportFormatContainer.m
//  Skilld
//
//  Created by Speed on 2022/12/7.
//

#import "SExportFormatContainer.h"

@interface SExportFormatContainer ()

@property (nonatomic, weak) UIButton *pngButton;

@property (nonatomic, weak) UIButton *pdfButton;

@end

@implementation SExportFormatContainer

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    return self;
}

- (void)initView {
    
    self.backgroundColor = [UIColor whiteColor];
    [self cornerByRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight cornerRadius:S_ScaleWidth(20)];
    
    UIView *lineView = [[UIView alloc] init];
    lineView.backgroundColor = rgba(138, 148, 160, 1);
    lineView.layer.cornerRadius = S_ScaleWidth(3);
    lineView.clipsToBounds = YES;
    [self addSubview:lineView];
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(0);
        make.top.mas_equalTo(S_ScaleWidth(10));
        make.width.mas_equalTo(S_ScaleWidth(60));
        make.height.mas_equalTo(S_ScaleWidth(6));
    }];
    
    
    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.text = @"Format";
    titleLabel.textColor = rgba(20, 23, 34, 1);
    titleLabel.font = HMFONTB(16);
    [titleLabel sizeToFit];
    [self addSubview:titleLabel];
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_ScaleWidth(36));
        make.left.mas_equalTo(S_ScaleWidth(20));
    }];
    
    UIButton *pngButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.pngButton = pngButton;
    [pngButton setTitle:@"PNG" forState:UIControlStateNormal];
    [pngButton setTitleColor:rgba(20, 23, 34, 1) forState:UIControlStateNormal];
    [pngButton setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    [pngButton setBackgroundColor:rgba(56, 94, 239, 1)];
    pngButton.layer.cornerRadius = S_ScaleWidth(35) * 0.5;
    pngButton.layer.borderColor = rgba(56, 94, 239, 1).CGColor;
    pngButton.layer.borderWidth = 1;
    pngButton.titleLabel.font = HMFONTM(14);
    [pngButton addTarget:self action:@selector(formatClick:) forControlEvents:UIControlEventTouchUpInside];
    pngButton.selected = YES;
    [self addSubview:pngButton];
    [pngButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_ScaleWidth(79));
        make.left.mas_equalTo(S_ScaleWidth(20));
        make.width.mas_equalTo(S_ScaleWidth(157));
        make.height.mas_equalTo(S_ScaleWidth(35));
    }];
    
    UIButton *pdfButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.pdfButton = pdfButton;
    [pdfButton setTitle:@"PDF" forState:UIControlStateNormal];
    [pdfButton setTitleColor:rgba(20, 23, 34, 1) forState:UIControlStateNormal];
    [pdfButton setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    [pdfButton setBackgroundColor:[UIColor whiteColor]];
    pdfButton.layer.cornerRadius = S_ScaleWidth(35) * 0.5;
    pdfButton.layer.borderColor = rgba(56, 94, 239, 1).CGColor;
    pdfButton.layer.borderWidth = 1;
    pdfButton.titleLabel.font = HMFONTM(14);
    [pdfButton addTarget:self action:@selector(formatClick:) forControlEvents:UIControlEventTouchUpInside];
    pdfButton.selected = NO;
    [self addSubview:pdfButton];
    [pdfButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_ScaleWidth(79));
        make.right.mas_equalTo(-S_ScaleWidth(20));
        make.width.mas_equalTo(S_ScaleWidth(157));
        make.height.mas_equalTo(S_ScaleWidth(35));
    }];
    
    UIButton *saveButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [saveButton setTitle:@"Save Pro" forState:UIControlStateNormal];
    [saveButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [saveButton setBackgroundColor:rgba(56, 94, 239, 1)];
    saveButton.layer.cornerRadius = S_ScaleWidth(24);
    saveButton.titleLabel.font = HMFONTB(16);
    [saveButton addTarget:self action:@selector(saveClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:saveButton];
    [saveButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(0);
        make.bottom.mas_equalTo(-S_ScaleWidth(50) - S_SafeAreaBottomHeight);
        make.width.mas_equalTo(S_ScaleWidth(335));
        make.height.mas_equalTo(S_ScaleWidth(48));
    }];
}

- (void)formatClick:(UIButton *)sender {
    
    if (sender == self.pngButton) {
        self.pngButton.selected = YES;
        [self.pngButton setBackgroundColor:rgba(56, 94, 239, 1)];
        self.pdfButton.selected = NO;
        [self.pdfButton setBackgroundColor:[UIColor whiteColor]];
    }else {
        self.pngButton.selected = NO;
        [self.pngButton setBackgroundColor:[UIColor whiteColor]];
        self.pdfButton.selected = YES;
        [self.pdfButton setBackgroundColor:rgba(56, 94, 239, 1)];
    }
}

- (void)saveClick {
    
    if ([[NSUserDefaults standardUserDefaults] boolForKey:k_purchase_status]) {
        if (self.formatBlock) {
            if (self.pngButton.selected) {
                self.formatBlock(0);
            }else {
                self.formatBlock(1);
            }
        }
    }else {
        
        [SRoute vip];
    }
}


@end
