//
//  SResumeDeleteContainer.h
//  Skilld
//
//  Created by Speed on 2022/11/21.
//

#import "LSTBaseAlertView.h"

NS_ASSUME_NONNULL_BEGIN

@interface SResumeDeleteContainer : LSTBaseAlertView

@property (nonatomic, copy) void(^deleteBlock)(void);

- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title message:(NSString *)message;

@end

NS_ASSUME_NONNULL_END
