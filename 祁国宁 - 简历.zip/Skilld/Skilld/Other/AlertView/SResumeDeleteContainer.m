//
//  SResumeDeleteContainer.m
//  Skilld
//
//  Created by Speed on 2022/11/21.
//

#import "SResumeDeleteContainer.h"

@interface SResumeDeleteContainer ()
@property (nonatomic, weak) UILabel *titleLabel;
@property (nonatomic, weak) UILabel *messageLabel;
@end

@implementation SResumeDeleteContainer

- (instancetype)initWithFrame:(CGRect)frame title:(nonnull NSString *)title message:(nonnull NSString *)message {
    if (self = [super initWithFrame:frame]) {
        
        [self initView];
        
        self.titleLabel.text = title;
        self.messageLabel.text = message;
    }
    return self;
}

- (void)initView {
    
    self.backgroundColor = [UIColor whiteColor];
    self.layer.cornerRadius = S_ScaleWidth(10);
    self.clipsToBounds = YES;
    
    UILabel *titleLabel = [[UILabel alloc] init];
    self.titleLabel = titleLabel;
    titleLabel.textColor = rgba(20, 23, 34, 1);
    titleLabel.font = FONTM(16);
    [titleLabel sizeToFit];
    [self addSubview:titleLabel];
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_ScaleWidth(20));
        make.centerX.mas_equalTo(0);
    }];
    
    UILabel *messageLabel = [[UILabel alloc] init];
    self.messageLabel = messageLabel;
    messageLabel.textColor = rgba(20, 23, 34, 1);
    messageLabel.font = FONTR(14);
    [messageLabel sizeToFit];
    [self addSubview:messageLabel];
    [messageLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_ScaleWidth(53));
        make.centerX.mas_equalTo(0);
    }];
    
    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftButton setTitle:@"Cancel" forState:UIControlStateNormal];
    [leftButton setTitleColor:rgba(20, 23, 34, 1) forState:UIControlStateNormal];
    leftButton.titleLabel.font = FONTR(14);
    [leftButton addTarget:self action:@selector(cacnelClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:leftButton];
    [leftButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.bottom.mas_equalTo(0);
        make.width.mas_equalTo(self.width * 0.5);
        make.height.mas_equalTo(S_ScaleWidth(58));
    }];
    
    UIButton *rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [rightButton setBackgroundColor:rgba(56, 94, 239, 1)];
    [rightButton setTitle:@"Delete" forState:UIControlStateNormal];
    [rightButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    rightButton.titleLabel.font = FONTR(14);
    [rightButton addTarget:self action:@selector(deleteClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:rightButton];
    [rightButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.bottom.mas_equalTo(0);
        make.width.mas_equalTo(self.width * 0.5);
        make.height.mas_equalTo(S_ScaleWidth(58));
    }];
    
    UIView *lineView = [[UIView alloc] init];
    lineView.backgroundColor = rgba(221, 224, 236, 1);
    [self addSubview:lineView];
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(leftButton.mas_top);
        make.left.right.mas_equalTo(0);
        make.height.mas_equalTo(0.5);
    }];
}

- (void)cacnelClick {
    
    [self dismiss];
}

- (void)deleteClick {
 
    if (self.deleteBlock) {
        self.deleteBlock();
    }
}


@end
