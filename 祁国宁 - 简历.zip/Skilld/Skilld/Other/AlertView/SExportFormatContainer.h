//
//  SExportFormatContainer.h
//  Skilld
//
//  Created by Speed on 2022/12/7.
//

#import "LSTBaseAlertView.h"

NS_ASSUME_NONNULL_BEGIN

@interface SExportFormatContainer : LSTBaseAlertView

@property (nonatomic, copy) void(^formatBlock)(NSInteger format);

@end

NS_ASSUME_NONNULL_END
