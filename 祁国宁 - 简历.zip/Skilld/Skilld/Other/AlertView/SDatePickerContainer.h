//
//  SDatePickerContainer.h
//  Skilld
//
//  Created by Speed on 2022/12/7.
//

#import "LSTBaseAlertView.h"

NS_ASSUME_NONNULL_BEGIN

typedef void(^ChooseDateBlock)(NSString *dateStr);

@interface SDatePickerContainer : LSTBaseAlertView

- (instancetype)initWithFrame:(CGRect)frame chooseBlock:(ChooseDateBlock)chooseBlock;

@property (nonatomic,copy) NSString *miniDate;


@end

NS_ASSUME_NONNULL_END
