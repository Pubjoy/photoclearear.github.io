//
//  LSTBaseAlertView.m
//  Skilld
//
//  Created by Speed on 2022/11/19.
//

#import "LSTBaseAlertView.h"

@implementation LSTBaseAlertView

- (void)dismiss {
    if (self.dismissBlock) {
        self.dismissBlock();
    }
}

#pragma mark - <UITextFieldDelegate>
- (void)textFieldDidBeginEditing:(SResumeField *)textField {
    
    [textField updateFieldShaowStauts:YES];
}

- (void)textFieldDidEndEditing:(SResumeField *)textField {
    [textField updateFieldShaowStauts:NO];
}

@end
