//
//  SDatePickerContainer.m
//  Skilld
//
//  Created by Speed on 2022/12/7.
//

#import "SDatePickerContainer.h"

@interface SDatePickerContainer ()
@property (nonatomic, weak) UIDatePicker *datePicker;
@property (nonatomic, copy) NSString *dateStr;
@property (nonatomic, copy) ChooseDateBlock chooseBlock;
@end

@implementation SDatePickerContainer

- (instancetype)initWithFrame:(CGRect)frame chooseBlock:(ChooseDateBlock)chooseBlock {
    if (self = [super initWithFrame:frame]) {
            
        self.chooseBlock = chooseBlock;
        
        [self initView];
        
    }
    return self;
}

- (void)initView{
    
    self.backgroundColor = [UIColor whiteColor];
    
//    UIView *topView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.width, 44)];
//    [self addSubview:topView];
//
//    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
//    [backButton setTitle:@"Cancel" forState:0];
//    [backButton setTitleColor:rgba(56, 94, 239, 1) forState:0];
//    backButton.titleLabel.font = FONTR(15);
//    [backButton addTarget:self action:@selector(dismiss) forControlEvents:UIControlEventTouchUpInside];
//    [topView addSubview:backButton];
//    [backButton mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.size.mas_equalTo(CGSizeMake(88, 44));
//        make.left.mas_equalTo(0);
//        make.bottom.mas_equalTo(0);
//    }];
//
//    UIButton *determineButton = [UIButton buttonWithType:UIButtonTypeCustom];
//    [determineButton setTitle:@"Done" forState:0];
//    [determineButton setTitleColor:rgba(56, 94, 239, 1) forState:0];
//    determineButton.titleLabel.font = FONTR(15);
//    [determineButton addTarget:self action:@selector(determineAction) forControlEvents:UIControlEventTouchUpInside];
//    [topView addSubview:determineButton];
//    [determineButton mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.size.mas_equalTo(CGSizeMake(88, 44));
//        make.right.mas_equalTo(0);
//        make.bottom.mas_equalTo(0);
//    }];
    
    
    NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
    [fmt setDateFormat:@"MM-yyyy"];
    
    UIDatePicker *datePicker = [[UIDatePicker alloc] init];
    datePicker.frame = CGRectMake(S_ScaleWidth(30), 0, S_ScaleWidth(270), self.height);
    [datePicker setMaximumDate:[NSDate date]];
    self.dateStr = [fmt stringFromDate:datePicker.date];
    datePicker.datePickerMode = UIDatePickerModeDate;
    if (@available(iOS 13.4, *)) {
        datePicker.preferredDatePickerStyle = UIDatePickerStyleWheels;
    }
 
    [datePicker addTarget:self action:@selector(dateChange:) forControlEvents:UIControlEventValueChanged];
    [self addSubview:datePicker];
    self.datePicker = datePicker;
    
}

- (void)determineAction{
    
    if (self.chooseBlock) {
        self.chooseBlock(self.dateStr);
    }
    
    [self dismiss];
}

- (void)dateChange:(UIDatePicker *)datePicker {
    
    NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
    [fmt setDateFormat:@"MM-yyyy"];
    
    NSString *dateStr = [fmt stringFromDate:datePicker.date];
    
    self.dateStr = dateStr;
    
    if (self.chooseBlock) {
        self.chooseBlock(self.dateStr);
    }
}

@end
