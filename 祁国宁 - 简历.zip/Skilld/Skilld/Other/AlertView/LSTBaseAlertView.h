//
//  LSTBaseAlertView.h
//  Skilld
//
//  Created by Speed on 2022/11/19.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LSTBaseAlertView : UIView <UITextFieldDelegate>

@property (nonatomic,copy) void (^dismissBlock)(void);

- (void)dismiss;

@end

NS_ASSUME_NONNULL_END
