//
//  KTLoadingAnimationTool.m
//  KnowTA
//
//  Created by Second on 2022/8/13.
//

#import "KTLoadingAnimationTool.h"
#import "KTLoadingAnimationView.h"

@interface KTLoadingAnimationTool ()

@property (nonatomic,weak) KTLoadingAnimationView *loadingAnimationView;

@end

@implementation KTLoadingAnimationTool

+ (instancetype)sharedInstance{
    
    static id _loadingAnimationTool = nil;
    
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        
        _loadingAnimationTool = [[KTLoadingAnimationTool alloc] init];
        
    });
    
    return _loadingAnimationTool;
}

- (void)startLodingAnimation{
    
    dispatch_async(dispatch_get_main_queue(), ^{
    
        if (!self.loadingAnimationView) {
            KTLoadingAnimationView *loadingAnimationView = [[KTLoadingAnimationView alloc] initWithFrame:CGRectMake(0, 0, S_Screen_W, S_Screen_H)];
            self.loadingAnimationView = loadingAnimationView;
            [[AppDelegate getAppDelegate].window addSubview:loadingAnimationView];
            [self performSelector:@selector(stopLodingAnimation) withObject:nil afterDelay:15];
        }else{
            
            [[AppDelegate getAppDelegate].window bringSubviewToFront:self.loadingAnimationView];
            
            [self.loadingAnimationView startAnimation];
            
            self.loadingAnimationView.hidden = NO;
            
            [NSObject cancelPreviousPerformRequestsWithTarget:self];
            [self performSelector:@selector(stopLodingAnimation) withObject:nil afterDelay:15];
        }
    });
    
}


- (void)stopLodingAnimation{
    
    dispatch_async(dispatch_get_main_queue(), ^{

        
        if (self.loadingAnimationView) {
            
            self.loadingAnimationView.hidden = YES;
            
            [self.loadingAnimationView stopAnimation];
        }
    
        [NSObject cancelPreviousPerformRequestsWithTarget:self];
    });
}

@end
