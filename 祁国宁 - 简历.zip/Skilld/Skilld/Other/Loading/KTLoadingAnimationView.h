//
//  KTLoadingAnimationView.h
//  KnowTA
//
//  Created by Second on 2022/8/13.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface KTLoadingAnimationView : UIView


- (void)startAnimation;


- (void)stopAnimation;

@end

NS_ASSUME_NONNULL_END
