//
//  KTLoadingAnimationTool.h
//  KnowTA
//
//  Created by Second on 2022/8/13.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface KTLoadingAnimationTool : NSObject

+ (instancetype)sharedInstance;

- (void)startLodingAnimation;

- (void)stopLodingAnimation;

@end

NS_ASSUME_NONNULL_END
