//
//  KTLoadingAnimationView.m
//  KnowTA
//
//  Created by Second on 2022/8/13.
//

#import "KTLoadingAnimationView.h"
#import "MBProgressHUD.h"

@interface KTLoadingAnimationView ()

@end

@implementation KTLoadingAnimationView

- (instancetype)initWithFrame:(CGRect)frame{
    
    if (self = [super initWithFrame:frame]) {
        
        [self initView];
    }
    
    return self;
}

- (void)initView{
    
    [self startAnimation];
  
}

- (void)startAnimation{
    
    [self stopAnimation];
    

    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self animated:YES];
    hud.mode = MBProgressHUDModeIndeterminate;
    hud.contentColor = [UIColor whiteColor];
    hud.offset = CGPointMake(0, S_ScaleWidth(-50));
    hud.removeFromSuperViewOnHide = YES;
    hud.detailsLabel.textColor = [UIColor whiteColor];
    hud.bezelView.style = MBProgressHUDBackgroundStyleSolidColor;
    hud.bezelView.color = [[UIColor blackColor] colorWithAlphaComponent:0.75];
}

- (void)stopAnimation{
    
    [MBProgressHUD hideHUDForView:self animated:YES];
    
}

- (void)dealloc{
    
    [MBProgressHUD hideHUDForView:self animated:YES];    
}

@end
