//
//  CMTextView.h
//  Skilld
//
//  Created by Speed on 2022/11/18.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class CMTextView;

typedef void(^CMTextViewHandler)(CMTextView *textView);


IB_DESIGNABLE

@interface CMTextView : UITextView

+ (instancetype)textView;

- (void)addTextDidChangeHandler:(CMTextViewHandler)eventHandler;

- (void)addTextLengthDidMaxHandler:(CMTextViewHandler)maxHandler;

@property (nonatomic, assign) IBInspectable NSUInteger maxLength;

@property (nonatomic, assign) IBInspectable CGFloat cornerRadius;

@property (nonatomic, assign) IBInspectable CGFloat borderWidth;

@property (nonatomic, strong) IBInspectable UIColor *borderColor;

@property (nonatomic, copy)   IBInspectable NSString *placeholder;

@property (nonatomic, strong) IBInspectable UIColor *placeholderColor;

@property (nonatomic, strong) UIFont *placeholderFont;

@property (nonatomic, assign, getter=isCanPerformAction) BOOL canPerformAction;

@property (nonatomic, readonly) NSString *formatText;

@end

NS_ASSUME_NONNULL_END
