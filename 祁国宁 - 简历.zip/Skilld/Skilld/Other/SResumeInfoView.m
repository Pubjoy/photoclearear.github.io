//
//  SResumeInfoView.m
//  Skilld
//
//  Created by Speed on 2022/11/19.
//

#import "SResumeInfoView.h"

@interface SResumeInfoView ()
/// <#Description#>
@property (nonatomic, weak) UILabel *contentLabel;

@end

@implementation SResumeInfoView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    return self;
}

- (void)setContent:(NSString *)content {
    _content = content;
    self.contentLabel.text = content;
}

- (void)initView {
    
    self.backgroundColor = rgba(239, 245, 249, 1);
    self.layer.cornerRadius = S_ScaleWidth(10);
    self.clipsToBounds = YES;

    UILabel *contentLabel = [[UILabel alloc] init];
    self.contentLabel = contentLabel;
    contentLabel.textColor = rgba(20, 23, 34, 1);
    contentLabel.font = FONTR(15);
    contentLabel.numberOfLines = 0;
    [contentLabel sizeToFit];
    [self addSubview:contentLabel];
    [contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(S_ScaleWidth(13));
        make.left.mas_equalTo(S_ScaleWidth(10));
        make.right.mas_equalTo(-S_ScaleWidth(15));
    }];
}

@end
