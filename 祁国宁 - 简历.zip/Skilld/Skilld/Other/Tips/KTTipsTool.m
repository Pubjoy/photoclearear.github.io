//
//  KTTipsTool.m
//
//  Created by Mac on 2022/8/12.
//

#import "KTTipsTool.h"
#import "MBProgressHUD.h"

@implementation KTTipsTool

+ (void)showTipsString:(NSString *)text{
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        [KTTipsTool showTipsTextString:text durationTime:2 withView:[AppDelegate getAppDelegate].window enableClick:YES contentY:0];
        
    });
    
}

+ (void)showTipsString:(NSString *)text enableClick:(BOOL)enableClick{
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        CGFloat time = 2;
        
        if (!enableClick) {
            time = 1;
        }
        
        [KTTipsTool showTipsTextString:text durationTime:time withView:[AppDelegate getAppDelegate].window enableClick:enableClick contentY:0];
        
    });
}

+ (void)showTipsString:(NSString *)text durationTime:(CGFloat)durationTime{
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        [KTTipsTool showTipsTextString:text durationTime:durationTime withView:[AppDelegate getAppDelegate].window enableClick:YES contentY:0];
        
    });
}

+ (void)showTipsString:(NSString *)text durationTime:(CGFloat)durationTime enableClick:(BOOL)enableClick{
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        [KTTipsTool showTipsTextString:text durationTime:durationTime withView:[AppDelegate getAppDelegate].window enableClick:enableClick contentY:0];
        
    });
    
}

+ (void)showTipsString:(NSString *)text durationTime:(CGFloat)durationTime contentY:(CGFloat)contentY{
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        [KTTipsTool showTipsTextString:text durationTime:durationTime withView:[AppDelegate getAppDelegate].window enableClick:YES contentY:contentY];
        
    });
}

+ (void)hideTips{
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideHUDForView:[AppDelegate getAppDelegate].window animated:YES];
    });
    
}



+ (void)showTipsTextString:(NSString *)text durationTime:(CGFloat)durationTime withView:(UIView *)view enableClick:(BOOL)enableClick contentY:(CGFloat)conetntY{
    
    if (text.length == 0) {
        return;
    }
    
    [MBProgressHUD hideHUDForView:view animated:YES];
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    hud.mode = MBProgressHUDModeText;
    hud.detailsLabel.text= text;
    hud.detailsLabel.font = FONTM(15);
    hud.contentColor = [UIColor whiteColor];
    hud.margin = S_ScaleWidth(16);
    if (conetntY > 0) {
        hud.offset = CGPointMake(0, conetntY);
    }else{
        hud.offset = CGPointMake(0, S_ScaleWidth(-50));
    }
    hud.removeFromSuperViewOnHide = YES;
    hud.bezelView.style = MBProgressHUDBackgroundStyleSolidColor;
    hud.bezelView.color = [[UIColor blackColor] colorWithAlphaComponent:0.75];
    [hud hideAnimated:YES afterDelay:durationTime];
    if (enableClick) {
        hud.userInteractionEnabled = NO;
    }else{
        hud.userInteractionEnabled = YES;
    }
}

+ (void)showActivityTipsString:(NSString *)text{
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self showActivityTipsString:text durationTime:0 withView:[AppDelegate getAppDelegate].window enableClick:NO contentY:0];
    });
}

+ (void)showActivityTipsString:(NSString *)text durationTime:(CGFloat)durationTime{
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self showActivityTipsString:text durationTime:durationTime withView:[AppDelegate getAppDelegate].window enableClick:NO contentY:0];
    });
}

+ (void)showActivityTipsString:(NSString *)text durationTime:(CGFloat)durationTime withView:(UIView *)view enableClick:(BOOL)enableClick contentY:(CGFloat)conetntY{
    
    if (text.length == 0) {
        return;
    }
    
    [MBProgressHUD hideHUDForView:view animated:YES];
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    hud.mode = MBProgressHUDModeIndeterminate;
    hud.detailsLabel.text= text;
    hud.detailsLabel.font = FONTR(15);
    hud.contentColor = [UIColor whiteColor];
    hud.margin = 10.f;
    hud.removeFromSuperViewOnHide = YES;
    hud.detailsLabel.textColor = [UIColor whiteColor];
    hud.bezelView.style = MBProgressHUDBackgroundStyleSolidColor;
    hud.bezelView.color =[[UIColor blackColor] colorWithAlphaComponent:0.75];
    if (durationTime > 0.f) {
        [hud hideAnimated:YES afterDelay:durationTime];
    }
}

@end
