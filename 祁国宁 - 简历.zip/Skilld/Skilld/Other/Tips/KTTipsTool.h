//
//  KTTipsTool.h
//
//  Created by Mac on 2022/8/12.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface KTTipsTool : NSObject

+ (void)showTipsString:(NSString *)text;

+ (void)showTipsString:(NSString *)text enableClick:(BOOL)enableClick;

+ (void)showTipsString:(NSString *)text durationTime:(CGFloat)durationTime;

+ (void)showTipsString:(NSString *)text durationTime:(CGFloat)durationTime enableClick:(BOOL)enableClick;

+ (void)showTipsString:(NSString *)text durationTime:(CGFloat)durationTime contentY:(CGFloat)contentY;

+ (void)showActivityTipsString:(NSString *)text;

+ (void)showActivityTipsString:(NSString *)text durationTime:(CGFloat)durationTime;

+ (void)hideTips;

@end

NS_ASSUME_NONNULL_END
