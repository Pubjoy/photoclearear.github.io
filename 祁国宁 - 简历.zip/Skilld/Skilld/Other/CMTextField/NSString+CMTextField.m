//
//  NSString+CMTextField.m
//  Skilld
//
//  Created by Speed on 2022/11/18.
//

#import "NSString+CMTextField.h"

@implementation NSString (CMTextField)

- (BOOL)cm_is:(CMTextFieldStringType)stringType {
    return [self matchRegularWith:stringType];
}

- (BOOL)cm_isSpecialLetter {
    if ([self cm_is:CMTextFieldStringTypeNumber] || [self cm_is:CMTextFieldStringTypeLetter] || [self cm_is:CMTextFieldStringTypeChinese]) {
        return NO;
    }
    return YES;
}

- (BOOL)matchRegularWith:(CMTextFieldStringType)type {
    
    NSString *regularStr = @"";
    
    switch (type) {
        case CMTextFieldStringTypeNumber:
            regularStr = @"^[0-9]*$";
            break;
        case CMTextFieldStringTypeLetter:
            regularStr = @"^[A-Za-z]+$";
            break;
        case CMTextFieldStringTypeChinese:
            regularStr = @"^[\u4e00-\u9fa5]{0,}$";
            break;
        default:
            break;
    }
    NSPredicate *regextestA = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regularStr];
    
    if ([regextestA evaluateWithObject:self] == YES){
        return YES;
    }
    return NO;
}

- (int)cm_getStrLengthWithCh2En1 {
    int strLength = 0;
    char* p = (char*)[self cStringUsingEncoding:NSUnicodeStringEncoding];
    for (int i=0 ; i<[self lengthOfBytesUsingEncoding:NSUnicodeStringEncoding] ;i++) {
        if (*p) {
            p++;
            strLength++;
        }else {
            p++;
        }
    }
    return strLength;
}

- (NSString *)cm_removeSpecialLettersExceptLetters:(NSArray<NSString *> *)exceptLetters {
    if (self.length > 0) {
        NSMutableString *resultStr = [[NSMutableString alloc]init];
        for (int i = 0; i<self.length; i++) {
            NSString *indexStr = [self substringWithRange:NSMakeRange(i, 1)];
            
            if (![indexStr cm_isSpecialLetter] || (exceptLetters && [exceptLetters containsObject:indexStr])) {
                [resultStr appendString:indexStr];
            }
        }
        if (resultStr.length > 0) {
            return resultStr;
        }else {
            return @"";
        }
    }else {
        return @"";
    }
}


@end
