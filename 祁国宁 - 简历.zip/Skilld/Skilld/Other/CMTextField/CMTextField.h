//
//  CMTextField.h
//  Skilld
//
//  Created by Speed on 2022/11/18.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CMTextField : UITextField

@property(nonatomic,assign)BOOL isClearWhileEditing;
@property(nonatomic,assign)BOOL isSpecialCharacter;
@property(nonatomic,strong)NSArray<NSString *> *canInputCharacters;
@property(nonatomic,strong)NSArray<NSString *> *canotInputCharacters;
@property(nonatomic,assign)BOOL isOnlyNumber;
@property(nonatomic,assign)NSInteger maxNumberCount;
@property(nonatomic,assign)BOOL isPhoneNumber;

@property(nonatomic,assign)BOOL isPrice;
@property(nonatomic,assign)BOOL isPriceHeaderPoint;
@property(nonatomic,assign)BOOL isPassword;
@property(nonatomic,strong)NSArray<NSString *> *canInputPasswords;
@property(nonatomic,assign)NSInteger maxTextLength;
@property(nonatomic,assign)NSInteger maxCharactersLength;
@property(nonatomic,copy)void(^cmTextFieldTextChangedBlock)(CMTextField *tf);
@property(nonatomic,copy)void(^cmTextFieldEndEditBlock)(CMTextField *tf);
@property(nonatomic,copy)void(^cmTextFieldReturnTypeBlock)(CMTextField *tf);
@end

NS_ASSUME_NONNULL_END
