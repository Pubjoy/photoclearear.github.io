//
//  CMTextField.m
//  Skilld
//
//  Created by Speed on 2022/11/18.
//

#import "CMTextField.h"

#import "NSString+CMTextField.h"

#define kNumbersPeriod  @"0123456789."
#define kOnlyNumber  @"0123456789"
#define KOnlyCharacter @"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
#define KCharacterNumber @"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"

@implementation CMTextField

- (void)configurePPTextfield {
    self.delegate = (id<UITextFieldDelegate>)self;
    self.autocorrectionType = UITextAutocorrectionTypeNo;
    [self cm_addTargetEditingChanged];
    [self setupDefaultConfigure];
    
}


- (void)setupDefaultConfigure {
    _isOnlyNumber = NO;
    _isPriceHeaderPoint = NO;
    
    _isClearWhileEditing = NO;
    if (_isClearWhileEditing) {
        self.clearButtonMode = UITextFieldViewModeWhileEditing;
    }
    
    _isSpecialCharacter = YES;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self configurePPTextfield];
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    [self configurePPTextfield];
}

- (void)setIsClearWhileEditing:(BOOL)isClearWhileEditing {
    _isClearWhileEditing = isClearWhileEditing;
    if (isClearWhileEditing) {
        self.clearButtonMode = UITextFieldViewModeWhileEditing;
    }else{
        self.clearButtonMode = UITextFieldViewModeNever;
    }
}

- (void)setIsSpecialCharacter:(BOOL)isSpecialCharacter {
    _isSpecialCharacter = isSpecialCharacter;
}

- (void)setCanInputCharacters:(NSArray<NSString *> *)canInputCharacters {
    
    _canInputCharacters = canInputCharacters;
    [self setIsSpecialCharacter:NO];
    
}

- (void)setCanotInputCharacters:(NSArray<NSString *> *)canotInputCharacters {
    _canotInputCharacters = canotInputCharacters;
}

- (void)setIsOnlyNumber:(BOOL)isOnlyNumber {
    _isOnlyNumber = isOnlyNumber;
    _isSpecialCharacter = NO;
    if (_isOnlyNumber) {
        _isPrice = NO;
        self.keyboardType = UIKeyboardTypeNumberPad;
    }
}

- (void)setIsPrice:(BOOL)isPrice {
    _isPrice = isPrice;
    _isSpecialCharacter = NO;
    if (_canotInputCharacters) {
        _canotInputCharacters = [NSArray array];
    }

    if (_isPrice) {
        _isOnlyNumber = NO;
        self.keyboardType = UIKeyboardTypeDecimalPad;
    }
}

- (void)setIsPriceHeaderPoint:(BOOL)isPriceHeaderPoint {
    _isPriceHeaderPoint = isPriceHeaderPoint;
    [self setIsPrice:YES];
}

- (void)setMaxNumberCount:(NSInteger)maxNumberCount {
    _maxNumberCount = maxNumberCount;
    [self setIsOnlyNumber:YES];
}

- (void)setIsPhoneNumber:(BOOL)isPhoneNumber {
    _isPhoneNumber = isPhoneNumber;
    [self setIsOnlyNumber:YES];
    [self setMaxNumberCount:11];
}

- (void)setIsPassword:(BOOL)isPassword {
    _isPassword = isPassword;
    self.secureTextEntry = YES;
    _isSpecialCharacter = NO;
}

- (void)setCanInputPassword:(NSArray<NSString *> *)canInputPasswords {
    _canInputPasswords = canInputPasswords;
    [self setIsPassword:YES];
}

- (void)setMaxCharactersLength:(NSInteger)maxCharactersLength {
    _maxCharactersLength = maxCharactersLength;
    if (_maxCharactersLength > 0) {
        _maxTextLength = 0;
    }
}
-(void)setMaxTextLength:(NSInteger)maxTextLength {
    _maxTextLength = maxTextLength;
    if (_maxTextLength > 0) {
        _maxCharactersLength = 0;
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    if (self.cmTextFieldReturnTypeBlock) {
        self.cmTextFieldReturnTypeBlock(self);
    }
    return YES;
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField {
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    if (self.cmTextFieldEndEditBlock) {
        self.cmTextFieldEndEditBlock(self);
    }
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if (_isOnlyNumber) {

        if ([string cm_is:CMTextFieldStringTypeNumber]) {
            if ([self.canotInputCharacters containsObject:string]) {
                return NO;
            }else{
                return YES;
            }
        }else{
            return NO;
        }
    }
    
    if (_isPassword) {
        NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:KCharacterNumber] invertedSet];
        NSString *filtered = [[string componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""];
        BOOL canChange = [string isEqualToString:filtered];
        if (!canChange) {
            if ([self.canInputPasswords containsObject:string]) {
                return YES;
            }
            return NO;
        }else{
            return YES;
        }
    }

    if (_isPrice) {
        return [self limitPriceWithTextField:textField shouldChangeCharactersInRange:range replacementString:string];
    }

    if (!_isSpecialCharacter) {
        if ([self.canInputCharacters containsObject:string] ||[self.canInputPasswords containsObject:string]) {
            return YES;
        }else{
            if ([string cm_isSpecialLetter] || [self.canotInputCharacters containsObject:string]) {
                return NO;
            }
            return YES;
        }
    }
    return YES;
}

- (BOOL)limitPriceWithTextField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {

    if (textField.text.length > 10) {
        return range.location < 11;
    }else{
        BOOL isHaveDian = YES;
        if ([textField.text rangeOfString:@"."].location==NSNotFound) {
            isHaveDian=NO;
        }
        if ([string length] > 0){
            unichar single=[string characterAtIndex:0];
            
            if ((single >='0' && single<='9') || single=='.')
            {
                if (_isPriceHeaderPoint) {

                    if([textField.text length]==0){
                        if(single == '.'){
                            textField.text = @"0";
                            return YES;
                            
                        }
                    }
                }

                if([textField.text length]==0){
                    if(single == '.'){
                        [textField.text stringByReplacingCharactersInRange:range withString:@""];
                        return NO;
                        
                    }
                }
                if([textField.text length]==1 && [textField.text isEqualToString:@"0"]){
                    if(single != '.'){
                        textField.text = @"0.";
                        return YES;
                        
                    }
                }
                if (single=='.'){
                    if(!isHaveDian)
                    {
                        isHaveDian=YES;
                        return YES;
                    }else
                    {
                        [textField.text stringByReplacingCharactersInRange:range withString:@""];
                        return NO;
                    }
                }
                else
                {
                    if (isHaveDian)
                    {
                        NSRange ran=[textField.text rangeOfString:@"."];
                        NSInteger tt=range.location-ran.location;
                        if (tt <= 2){
                            return YES;
                        }else{
                            return NO;
                        }
                    }
                    else
                    {
                        return YES;
                    }
                }
            }else{
                [textField.text stringByReplacingCharactersInRange:range withString:@""];
                return NO;
            }
        }
        else
        {
            return YES;
        }
    }
}


- (void)cm_addTargetEditingChanged {
    [self addTarget:self action:@selector(textFieldTextEditingChanged:) forControlEvents:UIControlEventEditingChanged];
}

- (void)textFieldTextEditingChanged:(id)sender {
    
    bool isChinese;
    NSArray *currentar = [UITextInputMode activeInputModes];
    UITextInputMode *current = [currentar firstObject];

    if ([current.primaryLanguage isEqualToString: @"en-US"]) {
        isChinese = false;
    }else{
        isChinese = true;
    }
    
    if(sender == self) {
        NSString *toBeString = self.text;
        if (isChinese) {
            UITextRange *selectedRange = [self markedTextRange];

            UITextPosition *position = [self positionFromPosition:selectedRange.start offset:0];

            if (!position) {
                [self setupLimits:toBeString];
            }
        }else{
            [self setupLimits:toBeString];
        }
    }
    

    if (self.cmTextFieldTextChangedBlock) {
        self.cmTextFieldTextChangedBlock(self);
    }
}

- (void)setupLimits:(NSString *)toBeString {
    if (toBeString.length == 0) {
        return;
    }
    

    if (_isPrice) {
        self.text = toBeString;

        return;
    }
    

    if (!_isSpecialCharacter) {
        NSMutableArray *filterArrs = [NSMutableArray arrayWithArray:self.canInputCharacters];

        if (_isPassword && self.canInputPasswords.count > 0) {
            [filterArrs addObjectsFromArray:self.canInputPasswords];
        }

        self.text = [toBeString cm_removeSpecialLettersExceptLetters:filterArrs];


    }
    
    if (_isOnlyNumber) {
        if ([toBeString cm_is:CMTextFieldStringTypeNumber]) {
            if (_maxNumberCount > 0) {
                if (toBeString.length > _maxNumberCount) {
                    self.text = [toBeString substringToIndex:_maxNumberCount];
                }else{
                    self.text = toBeString;
                }
            }
        }
    }
    

    if (_maxCharactersLength > 0) {
        if (!_isPhoneNumber) {
            int totalCountAll = [toBeString cm_getStrLengthWithCh2En1];
            if (totalCountAll > _maxCharactersLength) {
                int totalCount = 0;
                for (int i = 0; i < toBeString.length; i++) {
                    NSString *str1 = [toBeString substringWithRange:NSMakeRange(i, 1)];
                    BOOL currentIsCN = [str1 cm_is:CMTextFieldStringTypeChinese];
                    if (currentIsCN) {
                        totalCount +=2;
                    }else{
                        totalCount +=1;
                    }
                    if (totalCount > _maxCharactersLength) {
                        self.text = [toBeString substringToIndex:i];
                        return;
                    }
                }
            }
        }
        
    }
    
    if (_maxTextLength > 0) {
        if (!_isPhoneNumber) {
            if (toBeString.length > _maxTextLength) {
                self.text = [toBeString substringToIndex:_maxTextLength];
            }
        }
        
    }
}


@end
