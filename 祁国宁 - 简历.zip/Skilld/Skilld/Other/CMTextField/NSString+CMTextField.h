//
//  NSString+CMTextField.h
//  Skilld
//
//  Created by Speed on 2022/11/18.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger,CMTextFieldStringType) {
    CMTextFieldStringTypeNumber,
    CMTextFieldStringTypeLetter,
    CMTextFieldStringTypeChinese
};


@interface NSString (CMTextField)

- (BOOL)cm_is:(CMTextFieldStringType)stringType;


- (BOOL)cm_isSpecialLetter;

- (int)cm_getStrLengthWithCh2En1;


- (NSString *)cm_removeSpecialLettersExceptLetters:(NSArray<NSString *> *)exceptLetters;


@end

NS_ASSUME_NONNULL_END
