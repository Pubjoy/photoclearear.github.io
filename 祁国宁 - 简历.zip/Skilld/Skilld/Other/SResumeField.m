//
//  SResumeField.m
//  Skilld
//
//  Created by Speed on 2022/11/19.
//

#import "SResumeField.h"

@implementation SResumeField

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        
        self.font = FONTR(15);
        self.textColor = rgba(20, 23, 34, 1);
        
        self.backgroundColor = rgba(239, 245, 249, 1);
        self.layer.borderWidth = 0.5;
        self.layer.borderColor = [UIColor clearColor].CGColor;
        self.layer.cornerRadius = S_ScaleWidth(10);

        self.layer.shadowColor = [UIColor clearColor].CGColor;
        self.layer.shadowOffset = CGSizeMake(0, 2);
        self.layer.shadowRadius = 3;
        self.layer.shadowOpacity = 1;

        UIView *leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, S_ScaleWidth(10), 0)];
        self.leftView = leftView;
        self.leftViewMode = UITextFieldViewModeAlways;
    }
    return self;
}

- (void)updateFieldShaowStauts:(BOOL)status {
    if (status) {
        self.layer.borderColor = rgba(219, 226, 255, 1).CGColor;
        self.layer.shadowColor = rgba(56, 94, 239, 0.30).CGColor;
    }else {
        self.layer.borderColor = [UIColor clearColor].CGColor;
        self.layer.shadowColor = [UIColor clearColor].CGColor;

    }
}

@end
