//
//  AppDelegate.h
//  Skilld
//
//  Created by SecondSpeed on 2022/11/18.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow * window;


+ (AppDelegate *)getAppDelegate;

@end

